var val_sldBackAlpha
var val_sldChWaitMsec, val_chkChDoWait, val_sldAutoLWaitMsec, val_sldAutoPWaitMsec
var val_sldChWaitMsec_Kidoku, val_chkChDoWait_Kidoku, val_sldAutoLWaitMsec_Kidoku, val_sldAutoPWaitMsec_Kidoku
var val_sldVolGlobal, val_sldVolBgm, val_sldVolSe, val_sldVolSys

lang = ''

function fncfmt_percent(nv) {return parseInt(nv*100) +' %'}
function fncfmt_msec(nv) {return nv +'  msec'}
function fncupd_sldBackAlpha(){
	$('#viewBackAlpha').css('opacity', $('#sldBackAlpha').slider('value'))
}

$(function(){
	switch (navigator.language) {
	case 'ja-JP':	lang = 'ja';	break
	case 'es-ES':	lang = 'es';	break
	case 'zh-CN':	lang = navigator.language;	break
	case 'en-US':
	default:		lang = 'en';	break
	}
	refresh_mes()

	$.each($('.cnf'), function() {
		var t = $(this), x = t.data('x'), y = t.data('y')
		if (x) t.css('left', x)
		if (y) t.css('top', y)
	})
	$.each($('.cnf_sld'), defSliderEvt)

	$('.switch label').click(function() {
		var t = $(this), id = t.parent().attr('id')
		window['val_'+ id] = (t.index() == 0)
//console.log(val_chkChDoWait)
		t.parent().find('label').removeClass('selected')
		t.addClass('selected')
	})
	$.each($('.switch'), function() {
		var id = $(this).attr('id')
		window['val_'+ id] = true
	})
})

function refresh() {
	$.each($('.cnf_sld'), function () {
		var t = $(this), id = t.attr('id')
		t.slider('value', window['val_'+ id])
		t.slider('option', 'slide')()
	})
	$.each($('.switch'), function() {
		var t = $(this), id = t.attr('id')
		var i = (String(window['val_'+ id]) == 'true') ?0 :1
		t.children('label').eq(i).click()
	})
}
function refresh_mes() {
	switch (lang) {
	case 'ja':
		$('body').css('background-image', "url(./_config.jpg)")
		$('#viewBackAlpha + .cnf').text('文字\n透過')
		$('#chkChDoWait span:eq(0)').text('待つ')
		$('#chkChDoWait span:eq(1)').text('待たない')
		$('#chkChDoWait_Kidoku span:eq(0)').text('待つ')
		$('#chkChDoWait_Kidoku span:eq(1)').text('待たない')
		break
	case 'es':
		$('body').css('background-image', "url(./_config@@es.jpg)")
		$('#viewBackAlpha + .cnf').text('Opac\nidad')
		$('#chkChDoWait span:eq(0)').text('esperar')
		$('#chkChDoWait span:eq(1)').text('no espere')
		$('#chkChDoWait_Kidoku span:eq(0)').text('esperar')
		$('#chkChDoWait_Kidoku span:eq(1)').text('no espere')
		break
	case 'zh-CN':
		$('body').css('background-image', "url(./_config@@cn.jpg)")
		$('#viewBackAlpha + .cnf').text('字符\n传输')
		$('#chkChDoWait span:eq(0)').text('等待')
		$('#chkChDoWait span:eq(1)').text('不要等待')
		$('#chkChDoWait_Kidoku span:eq(0)').text('等待')
		$('#chkChDoWait_Kidoku span:eq(1)').text('不要等待')
		break
	case 'en':
	default:
		$('body').css('background-image', "url(./_config@@en.jpg)")
		$('#viewBackAlpha + .cnf').text('Text\nBack')
		$('#chkChDoWait span:eq(0)').text('wait')
		$('#chkChDoWait span:eq(1)').text('no wait')
		$('#chkChDoWait_Kidoku span:eq(0)').text('wait')
		$('#chkChDoWait_Kidoku span:eq(1)').text('no wait')
	}
}

function defSliderEvt() {
	var t = $(this), o = {
		range: "min"
	,	min: t.data('min')
	,	max: t.data('max')
	,	step: t.data('step') || 1
	,	value: t.data('val')
	}
	var l = $('label[for="'+ t.attr('id') +'"]')
	if (l.length == 0) {t.slider(o); return}

	var fncupd = window[t.data('fncupd')] || function(){}
	var frm = window[l.data('format')] || function(nv){return nv}
	var key = 'val_'+ t.attr('id')
	o.slide = function() {
		var nv = t.slider('value')
		window[key] = nv
		l.text(frm(nv))
		fncupd()
	}
	o.change = function() {
		var nv = t.slider('value')
		window[key] = nv
		l.text(frm(nv))
		fncupd()
	}
	t.slider(o)
	o.slide()
}
