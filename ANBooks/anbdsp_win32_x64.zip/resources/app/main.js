const {crashReporter, app, BrowserWindow, Menu, shell}= require('electron')

crashReporter.start({
	productName	: 'ANBooks6',
	companyName	: 'famibee',
	submitURL	: 'http://famibee.blog38.fc2.com/',
	autoSubmit	: false,
})

let guiWin = null
const shouldQuit = app.makeSingleInstance(function(cmdLine, workDir) {
	// 起動済のインスタンスで実行させる処理か？
	if (guiWin) {
		if (guiWin.isMinimized()) guiWin.restore()
		guiWin.focus()

		guiWin.webContents.send('invoke', cmdLine.slice(1))
	}
})
// 全てのインスタンス起動時に実行させる処理か？
if (shouldQuit) { app.quit(); return }

// =====================================================
app.on('ready', function() {
	// メニューを付けないとコピペが出来ない
	const menu = Menu.buildFromTemplate(mnu_tmp)
	Menu.setApplicationMenu(menu)

	// メインウィンドウを作成
	guiWin = new BrowserWindow({
		id			: 'anbooks',
		width		: 520,
		height		: 800,
		min_width	: 300,
		min_height	: 300,
		acceptFirstMouse		: true,
		textAreasAreResizable	: false,
		webPreferences	: {
//			devTools	: false,
		},
	})
	const dirname = __dirname.replace(/\\/g, '/')
	guiWin.loadURL('file://'+ dirname +'/anbooks.htm')
	guiWin.webContents.on("did-finish-load", ()=>
		guiWin.webContents.send('invoke', process.argv.slice(1))
	)
	guiWin.on('closed', ()=> app.quit())
})
app.on('window-all-closed', ()=> app.quit())

function addLog(txt) {console.log(txt)}


let mnu_tmp = [
{
	label: 'Edit',
	submenu: [
	{role: 'undo'},
	{role: 'redo'},
	{type: 'separator'},
	{role: 'cut'},
	{role: 'copy'},
	{role: 'paste'},
	{role: 'delete'},
	{role: 'selectall'},
	]
},
{
	label: 'View',
	submenu: [
/**/{role: 'toggledevtools'},
/**/{type: 'separator'},
	{role: 'resetzoom'},
	{role: 'zoomin'},
	{role: 'zoomout'},
	{type: 'separator'},
	{role: 'togglefullscreen'},
	]
},
{
	role: 'window',
	submenu: [
	{role: 'minimize'},
	]
},
{
	role: 'help',
	submenu: [
	{
		label: '開発者向け情報',
		click () { shell.openExternal('http://famibee.web.fc2.com/tag_dev/dev.htm') }
	},
	{
		label: 'タグ リファレンス',
		click () { shell.openExternal('http://famibee.web.fc2.com/tag_dev/tags.htm') }
	},
	{
		label: '機能ギャラリー',
		click () { shell.openExternal('http://famibee.web.fc2.com/tag_dev/ext.htm') }
	},
	]
}]

if (process.platform === 'darwin') {
	mnu_tmp.unshift({
		label: app.getName(),
		submenu: [
		{role: 'about'},
		{type: 'separator'},
		{role: 'hide'},
		{role: 'hideothers'},
		{role: 'unhide'},
		{type: 'separator'},
		{role: 'quit'}
		]
	})
	// Edit menu.
	mnu_tmp[1].submenu.push(
		{type: 'separator'},
		{
			label: 'Speech',submenu: [
			{role: 'startspeaking'},
			{role: 'stopspeaking'}
			]
		}
	)
	// Window menu.
	mnu_tmp[3].submenu = [
	{
		label: 'Minimize',
		accelerator: 'CmdOrCtrl+M',
		role: 'minimize'
	},
	{
		label: 'Zoom',
		role: 'zoom'
	},
	{type: 'separator'},
	{
		label: 'Bring All to Front',
		role: 'front'
	}
	]
}
