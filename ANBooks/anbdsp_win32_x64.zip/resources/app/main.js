const me_el = require('electron')
me_el.crashReporter.start({
	productName: 'ANBooks',
	companyName: 'famibee',
	submitURL: 'http://famibee.blog38.fc2.com/',
	autoSubmit: false,
})

const me_app = me_el.app
var guiWin = null
const shouldQuit = me_app.makeSingleInstance(function(cmdLine, workDir) {
	// 起動済のインスタンスで実行させる処理か？
	if (guiWin) {
		if (guiWin.isMinimized()) guiWin.restore()
		guiWin.focus()

		guiWin.webContents.send('invoke', cmdLine.slice(1))
	}
})
// 全てのインスタンス起動時に実行させる処理か？
if (shouldQuit) { me_app.quit(); return }

// =====================================================
const me_shell = me_el.shell
const me_bw = me_el.BrowserWindow
const dirname = __dirname.replace(/\\/g, '/')

me_app.on('ready', function() {
	// メインウィンドウを作成します。
	guiWin = new me_bw({
		id			:'anbooks',
		width		: 520,
		height		: 800,
		min_width	: 300,
		min_height	: 300,
		acceptFirstMouse		: true,
		textAreasAreResizable	: false,
	})
	guiWin.loadURL('file://'+ dirname +'/anbooks.htm')
//	guiWin.openDevTools(true)
	guiWin.openDevTools(false)
	guiWin.webContents.on("did-finish-load", ()=>
		guiWin.webContents.send('invoke', process.argv.slice(1))
	)
	guiWin.on('closed', ()=> me_app.quit())
})
me_app.on('window-all-closed', ()=> me_app.quit())

function addLog(txt) {console.log(txt)}
