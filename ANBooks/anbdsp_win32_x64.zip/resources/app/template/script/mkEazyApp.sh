#!/bin/bash
export APP_STRDIR="$HOME/Library/Application Support/com.fc2.blog38.famibee.ANBooks/Local Store/"
export PRJ_DIR="${APP_STRDIR}unpack/$1/"

echo == 簡易アプリ生成（2015/3/10）
unzip -oq "${APP_STRDIR}template/nwjs_MAC.zip" -d "${PRJ_DIR}Work/easy_app/"

export EAW="${PRJ_DIR}Work/easy_app"
export WD=`find "${EAW}" -name "nwjs-v*"`
mv -f "$WD" "${EAW}/nwjs-v"
mv -f "${EAW}/nwjs-v/nwjs.app" "${EAW}/$1.app"
rm -rf "${EAW}/nwjs-v"

sed -e "s/string>nwjs/string>$1/g" "${EAW}/$1.app/Contents/Info.plist" > "${EAW}/$1.app/Contents/Info.plis"
sed -e "/<key>CFBundleExecutable</,/<key>/ s/string>$1</string>nwjs</g" "${EAW}/$1.app/Contents/Info.plis" > "${EAW}/$1.app/Contents/Info.plist"
rm -f "${EAW}/$1.app/Contents/Info.plis"


echo == 生成完了
open "${EAW}/$1.app"
