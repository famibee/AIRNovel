#!/bin/bash
export _JAVA_OPTIONS="-Dfile.encoding=UTF-8 -DXms768m -DXmx768m -DXX:NewSize=192m -DXX:SurvivorRatio=2"
export ANT_VER=apache-ant-1.10.0

export MAC_VER=`sw_vers -productVersion`
export MAC_VER_AB=${MAC_VER%.*}
export MAC_VER_A=${MAC_VER%%.*}
export MAC_VER_B=${MAC_VER%.*}
export MAC_VER_B=${MAC_VER_B#*.}
export MAC_VER_AB=$((MAC_VER_A*100 + MAC_VER_B))

echo == Java環境チェック（2015/6/11）
# 10.6 Snow Leopard以前ならJava6が入っているのでスルー
if ls /Library/Java/JavaVirtualMachines/jdk* > /dev/null 2>&1; then
	echo 　　：jdk ok

elif [ $MAC_VER_AB -ge 1007 ]; then
	echo 　　：dmgをダウンロードします。JDK（Java SE Development Kit）をインストールして下さい。インストール後に再びビルドして下さい。
	open http://www.oracle.com/technetwork/java/javase/downloads/index.html
	exit
fi
export JAVA_HOME=$(/usr/libexec/java_home)
#echo == JAVA_HOME ${JAVA_HOME}


echo == Ant環境チェック（2016/7/12）${ANT_VER}
export ANT_HOME_BASE=~/Documents/ANBooks
export ANT_HOME=${ANT_HOME_BASE}/${ANT_VER}
if [ -f /usr/bin/ant ]; then
	export ANT_HOME=/usr/share/ant

elif [ ! -f ${ANT_HOME}/bin/ant ]; then
	echo 　　：ダウンロードします
	rm /tmp/ant.tar.gz
#	curl https://156d93ca612e6deaae1e6a285098b979ac5feb64.googledrive.com/host/0B6pZS4YMqJ_sY045a1VNcm9uSEE/${ANT_VER}-bin.tar.gz -# -o /tmp/ant.tar.gz
	# OneDriveの直リンク、&とか!とかいやらしい文字が含まれてcurlでインターナルエラー500が起こる。goo.glで短縮し、リダイレクト許可（-L）を追加して対応
#	curl https://goo.gl/C2K85z -# -f -L -o /tmp/ant.tar.gz
	curl https://github.com/famibee/famibee.github.io/raw/master/ant_files/${ANT_VER}-bin.tar.gz -# -L -o /tmp/ant.tar.gz

	echo 　　：インストールします
	mkdir -p ${ANT_HOME_BASE}/apache-ant-0
	rm -rf ${ANT_HOME_BASE}/apache-ant-*
	tar xzf /tmp/ant.tar.gz -C ${ANT_HOME_BASE}

	echo 　　：インストールしました
fi


if [ $# -eq 0 ]; then
	echo "[usage] path/build.xml [terget]" 1>&2
	exit 1
fi
export PATH=$JAVA_HOME/bin:$ANT_HOME/bin:$PATH
if [ -z `which ant` ]; then
	echo "[error] antパスが通っていません。ふぁみべぇまでご連絡下さい"
fi

ant -f "$1" $2
#exit 0
