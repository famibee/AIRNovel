"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const m_fs = require("fs-extra");
const m_xml2js = require("xml2js");
const m_xregexp = require("xregexp");
const m_path = require("path");
const m_xmlbuilder = require("xmlbuilder");
const AnbMain_1 = require("./AnbMain");
const AnbData_1 = require("./AnbData");
const Config_1 = require("./Config");
const CriptRC4_1 = require("./CriptRC4");
const m_jszip = require('jszip');
;
;
;
class PrjBook {
    constructor(fn_, id_, anbdt) {
        this.fn_ = fn_;
        this.id_ = id_;
        this.anbdt = anbdt;
        this.path_nm = '';
        this.path_cfg = '';
        this.cfg_ = null;
        this.path_appxml = '';
        this.sAppxml = '';
        this.path_bld = '';
        this.sBld = '';
        this.bld_font_out = 'mat';
        this.bld_cnv_oggo = 'false';
        this.bld_code_key = 'pass';
        this.hCaedN2F = {
            'build.xml': p => { p.hide = true; },
            'cfg.properties': p => { p.hide = true; },
            'config.anprj': p => { p.hide = true; },
            'font/': p => { p.enabled = false; p.value = 'n'; },
            'icon/': p => { p.enabled = false; p.value = 'p'; },
            'icon.jpg': p => { p.enabled = false; p.value = 'a'; },
            'my_store.p12': p => { p.hide = true; },
            'path.txt': p => { p.hide = true; },
            'prj-app.xml': p => { p.hide = true; },
            'SDK/': p => { p.enabled = false; p.value = 'n'; },
            'Work/': p => { p.enabled = false; p.value = 'n'; },
            'Work_dust/': p => { p.enabled = false; p.value = 'n'; },
        };
        this.path_nm = AnbData_1.AnbData.path_unpack + fn_ + '/';
        this.path_cfg = this.path_nm + 'config.anprj';
        this.initCfg();
        this.path_appxml = this.path_nm + 'prj-app.xml';
        this.initAppxml();
        this.path_bld = this.path_nm + 'build.xml';
        this.initBld_and_upd_an();
    }
    get fn() { return this.fn_; }
    get cfg() { return this.cfg_; }
    get existsCfg() { return m_fs.existsSync(this.path_cfg); }
    get existsApp() { return m_fs.existsSync(this.path_appxml); }
    get existsBld() { return m_fs.existsSync(this.path_bld); }
    dataGet(key) {
        if (!(key in PrjBook.hKey4DateInit))
            throw 'dataGet ERR0 key:' + key + ': val:%s:';
        if (!(key in this))
            throw 'dataGet ERR1 key:' + key + ': val:%s:';
        return this[key];
    }
    get first_script_P_fn() { return this.cfg_.first_script.fn; }
    set first_script_P_fn(v) {
        if (this.cfg_.first_script.fn == v)
            return;
        this.cfg_.first_script.fn = v;
        this.replaceCfg();
    }
    get init_P_bg_color() { return this.cfg_.init.bg_color; }
    set init_P_bg_color(v) {
        if (this.cfg_.init.bg_color == v)
            return;
        this.cfg_.init.bg_color = v;
        this.replaceCfg();
    }
    get init_P_tagch_msecwait() { return this.cfg_.init.tagch_msecwait; }
    set init_P_tagch_msecwait(v) {
        if (this.cfg_.init.tagch_msecwait == v)
            return;
        this.cfg_.init.tagch_msecwait = v;
        this.replaceCfg();
    }
    get init_P_auto_msecpagewait() { return this.cfg_.init.auto_msecpagewait; }
    set init_P_auto_msecpagewait(v) {
        if (this.cfg_.init.auto_msecpagewait == v)
            return;
        this.cfg_.init.auto_msecpagewait = v;
        this.replaceCfg();
    }
    get window_P_width() { return this.cfg_.window.width; }
    set window_P_width(v) {
        if (this.cfg_.window.width == v)
            return;
        this.cfg_.window.width = v;
        this.replaceCfg();
    }
    get window_P_height() { return this.cfg_.window.height; }
    set window_P_height(v) {
        if (this.cfg_.window.height == v)
            return;
        this.cfg_.window.height = v;
        this.replaceCfg();
    }
    get title() { return this.cfg_.anbook.title; }
    set title(v) {
        if (this.cfg_.anbook.title == v)
            return;
        this.cfg_.anbook.title = v;
        this.replaceCfg();
        this.replaceAppxml();
        this.anbdt.setBook(this.id_, 'title', v);
    }
    get creator() { return this.cfg_.anbook.creator; }
    set creator(v) {
        if (this.cfg_.anbook.creator == v)
            return;
        this.cfg_.anbook.creator = v;
        this.replaceCfg();
        this.replaceAppxml();
        this.anbdt.setBook(this.id_, 'creator', v);
    }
    get cre_url() { return this.cfg_.anbook.cre_url; }
    set cre_url(v) {
        if (this.cfg_.anbook.cre_url == v)
            return;
        this.cfg_.anbook.cre_url = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'cre_url', v);
    }
    get publisher() { return this.cfg_.anbook.publisher; }
    set publisher(v) {
        if (this.cfg_.anbook.publisher == v)
            return;
        this.cfg_.anbook.publisher = v;
        this.replaceCfg();
        this.replaceAppxml();
        this.anbdt.setBook(this.id_, 'publisher', v);
    }
    get pub_url() { return this.cfg_.anbook.pub_url; }
    set pub_url(v) {
        if (this.cfg_.anbook.pub_url == v)
            return;
        this.cfg_.anbook.pub_url = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'pub_url', v);
    }
    get detail() { return this.cfg_.anbook.detail; }
    set detail(v) {
        if (this.cfg_.anbook.detail == v)
            return;
        this.cfg_.anbook.detail = v;
        this.replaceCfg();
        this.replaceAppxml();
        this.anbdt.setBook(this.id_, 'detail', v);
    }
    get upd_an() { return this.cfg_.anbook.upd_an; }
    set upd_an(v) {
        if (this.cfg_.anbook.upd_an == v)
            return;
        this.cfg_.anbook.upd_an = v;
        this.replaceCfg();
        this.replaceBld();
        this.anbdt.setBook(this.id_, 'upd_an', v);
    }
    get version() { return this.cfg_.anbook.version; }
    set version(v) {
        if (this.cfg_.anbook.version == v)
            return;
        this.cfg_.anbook.version = v;
        this.replaceCfg();
        this.replaceAppxml();
        this.anbdt.setBook(this.id_, 'version', v);
    }
    get prjtype() { return this.cfg_.anbook.prjtype; }
    set prjtype(v) {
        if (this.cfg_.anbook.prjtype == v)
            return;
        this.cfg_.anbook.prjtype = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'prjtype', v);
    }
    get nocode_reg() { return this.cfg_.anbook.nocode_reg; }
    set nocode_reg(v) {
        if (this.cfg_.anbook.nocode_reg == v)
            return;
        this.cfg_.anbook.nocode_reg = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'nocode_reg', v);
    }
    get nocode() { return this.cfg_.anbook.nocode; }
    set nocode(v) {
        if (this.cfg_.anbook.nocode == v)
            return;
        this.cfg_.anbook.nocode = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'nocode', v);
    }
    get pack_exc() { return this.cfg_.anbook.pack_exc; }
    set pack_exc(v) {
        if (this.cfg_.anbook.pack_exc == v)
            return;
        this.cfg_.anbook.pack_exc = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'pack_exc', v);
    }
    get rotate() { return this.cfg_.anbook.rotate; }
    set rotate(v) {
        if (this.cfg_.anbook.rotate == v)
            return;
        this.cfg_.anbook.rotate = v;
        this.replaceCfg();
        this.anbdt.setBook(this.id_, 'rotate', v);
    }
    get dl_url() { return this.cfg_.anbook.dl_url; }
    set dl_url(v) {
        if (this.cfg_.anbook.dl_url == v)
            return;
        this.cfg_.anbook.dl_url = v;
        this.replaceCfg();
    }
    initCfg() {
        if (!this.existsCfg)
            return;
        if (m_fs.statSync(this.path_cfg).isDirectory())
            throw 'nm:' + this.fn_ + ' [' + this.path_cfg + ']はフォルダです';
        const sCfg = m_fs.readFileSync(this.path_cfg, 'utf8');
        m_xml2js.parseString(sCfg, (err, res) => {
            if (err)
                throw 'nm:' + this.fn_ + ' Main: config.anprj ロード失敗(' + err + ')です';
            this.cfg_ = new Config_1.Config(res.config, this.path_nm);
            this.replaceCfg();
        });
    }
    replaceCfg() {
        if (!this.existsCfg)
            return;
        const dirs = [];
        const spD = this.cfg_.search;
        for (let dir in spD)
            dirs.push({ '@dir': dir });
        const incs = [];
        const spI = this.cfg_.anbook.inc_path;
        for (let inc in spI)
            incs.push({ '@path': inc });
        const o = { config: {
                first_script: { '@fn': this.first_script_P_fn },
                save_ns: {
                    '@name': this.cfg_.save_ns.name,
                    '@localpath': '/',
                },
                search: {
                    '@use_pathfile': this.cfg_.search_p_use_pathfile,
                    path: dirs,
                },
                coder: { '@len': '0x' + this.cfg_.coder.len.toString(16) },
                window: {
                    '@width': this.window_P_width,
                    '@height': this.window_P_height,
                },
                anbook: {
                    '@title': this.title,
                    '@creator': this.creator,
                    '@cre_url': this.cre_url,
                    '@publisher': this.publisher,
                    '@pub_url': this.pub_url,
                    '@detail': this.detail,
                    '@upd_an': this.upd_an,
                    '@version': this.version,
                    '@prjtype': this.prjtype,
                    '@nocode_reg': this.nocode_reg,
                    '@nocode': this.nocode,
                    '@pack_exc': this.pack_exc,
                    '@rotate': this.rotate,
                    inc: incs,
                },
                log: { '@max_len': this.cfg_.log.max_len },
                init: {
                    '@bg_color': this.init_P_bg_color,
                    '@tagch_msecwait': this.init_P_tagch_msecwait,
                    '@auto_msecpagewait': this.init_P_auto_msecpagewait,
                },
                debug: { '@devtool': this.cfg_.debug.devtool },
            } };
        if (o.config.search['@use_pathfile'] == false)
            delete o.config.search['@use_pathfile'];
        if (dirs.length === 0)
            delete o.config.search.path;
        if (Object.keys(o.config.search).length === 0)
            delete o.config.search;
        if (incs.length === 0)
            delete o.config.anbook.inc;
        if (o.config.log['@max_len'] == 1024)
            delete o.config.log['@max_len'];
        if (Object.keys(o.config.log).length === 0)
            delete o.config.log;
        if (o.config.init['@bg_color'] == 0x000000)
            delete o.config.init['@bg_color'];
        if (o.config.init['@tagch_msecwait'] == 10)
            delete o.config.init['@tagch_msecwait'];
        if (o.config.init['@auto_msecpagewait'] == 3500)
            delete o.config.init['@auto_msecpagewait'];
        if (Object.keys(o.config.init).length === 0)
            delete o.config.init;
        if (o.config.debug['@devtool'] == false)
            delete o.config.debug['@devtool'];
        if (Object.keys(o.config.debug).length === 0)
            delete o.config.debug;
        if (o.config.anbook['@title'] == '')
            delete o.config.anbook['@title'];
        if (o.config.anbook['@creator'] == '')
            delete o.config.anbook['@creator'];
        if (o.config.anbook['@cre_url'] == '')
            delete o.config.anbook['@cre_url'];
        if (o.config.anbook['@publisher'] == '')
            delete o.config.anbook['@publisher'];
        if (o.config.anbook['@pub_url'] == '')
            delete o.config.anbook['@pub_url'];
        if (o.config.anbook['@detail'] == '')
            delete o.config.anbook['@detail'];
        if (o.config.anbook['@upd_an'] == 'true')
            delete o.config.anbook['@upd_an'];
        if (o.config.anbook['@prjtype'] == '')
            delete o.config.anbook['@prjtype'];
        if (o.config.anbook['@nocode_reg'] == 'system/.+.(mp3|swf|xml)|m4a|config/.+')
            delete o.config.anbook['@nocode_reg'];
        if (o.config.anbook['@nocode'] == '')
            delete o.config.anbook['@nocode'];
        if (o.config.anbook['@pack_exc'] == '\.swf\.cache')
            delete o.config.anbook['@pack_exc'];
        if (o.config.anbook['@rotate'] == '')
            delete o.config.anbook['@rotate'];
        const xml = m_xmlbuilder.create(o, { encoding: 'utf-8' })
            .end({ pretty: true, indent: '\t' });
        AnbData_1.AnbData.replaceTxt(this.path_cfg, str => xml);
    }
    initAppxml() {
        if (!this.existsApp)
            return;
        if (m_fs.statSync(this.path_appxml).isDirectory())
            throw 'nm:' + this.fn_ + ' prj-app.xmlはフォルダです';
        this.sAppxml = m_fs.readFileSync(this.path_appxml, 'utf8');
        if (this.prjtype == 'IOS') {
            const tmp = this.sAppxml;
            this.sAppxml = this.sAppxml
                .replace('</requestedDisplayResolution>\n'
                + '\t</iPhone>', '</requestedDisplayResolution>\n'
                + '\t\t<Entitlements><![CDATA[\n'
                + '\t\t\t<key>get-task-allow</key><true/>\n'
                + '\t\t]]></Entitlements>\n'
                + '\t</iPhone>');
            if (tmp != this.sAppxml)
                m_fs.writeFile(this.path_appxml, this.sAppxml, { encoding: 'utf8' });
        }
        this.replaceAppxml();
    }
    replaceAppxml() {
        if (!this.existsApp)
            return;
        const tmp = this.sAppxml;
        this.sAppxml = this.sAppxml
            .replace(new RegExp('<versionNumber>.*<\/versionNumber>'), '<versionNumber>' + this.version + '</versionNumber>')
            .replace(new RegExp('<filename>.*<\/filename>'), '<filename>'
            + this.title.replace(new RegExp('[\*":><\?\\|]', 'g'), '_')
            + '</filename>')
            .replace(new RegExp('<name>.*<\/name>'), '<name>' + this.title + '</name>')
            .replace(new RegExp('<copyright>.*<\/copyright>'), '<copyright>' + (this.publisher || this.creator) + '</copyright>')
            .replace(new RegExp('<description>.*<\/description>'), '<description>' + this.detail + '</description>');
        if (tmp == this.sAppxml)
            return;
        m_fs.writeFile(this.path_appxml, this.sAppxml, { encoding: 'utf8' });
    }
    get bld_xml_font_out() { return this.bld_font_out; }
    set bld_xml_font_out(v) {
        if (this.bld_font_out == v)
            return;
        this.bld_font_out = v;
        this.replaceBld();
    }
    get bld_xml_cnv_oggo() { return this.bld_cnv_oggo; }
    set bld_xml_cnv_oggo(v) {
        if (this.bld_cnv_oggo == v)
            return;
        this.bld_cnv_oggo = v;
        this.replaceBld();
    }
    get bld_xml_code_key() { return this.bld_code_key; }
    set bld_xml_code_key(v) {
        if (this.bld_code_key == v)
            return;
        this.bld_code_key = v;
        this.replaceBld();
        PrjBook.set_cripter_as_code_key(this.path_nm, v);
    }
    static set_code_key(nm, v) {
        const path_nm = AnbData_1.AnbData.path_unpack + nm + '/';
        AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str.replace(/name="code_key" value=".+"/, 'name="code_key" value="' + v + '"'));
        PrjBook.set_cripter_as_code_key(path_nm, v);
    }
    static set_cripter_as_code_key(path_nm, v) {
        const path_cripter = path_nm
            + 'SDK/an_sdk/com/fc2/blog38/famibee/AIRNovel/cripter.as';
        if (!m_fs.existsSync(path_cripter))
            return;
        const s_cripter = m_fs.readFileSync(path_cripter, 'utf8')
            .replace(/_o:CriptRC4	= new CriptRC4\(".+"\);/, '_o:CriptRC4	= new CriptRC4("' + v + '");');
        m_fs.writeFile(path_cripter, s_cripter, { encoding: 'utf8' });
    }
    initBld_and_upd_an() {
        if (!this.existsBld)
            return;
        if (m_fs.statSync(this.path_bld).isDirectory())
            throw 'nm:' + this.fn_ + ' build.xmlはフォルダです';
        this.sBld = m_fs.readFileSync(this.path_bld, 'utf8');
        const a_0 = m_xregexp.exec(this.sBld, PrjBook.REG_FONT_OUT);
        if (a_0)
            this.bld_font_out = a_0['val'] || 'false';
        const a_1 = m_xregexp.exec(this.sBld, PrjBook.REG_UPD_AN_SDK);
        if (a_1)
            this.cfg_.anbook.upd_an = a_1['val'] || 'false';
        const a_2 = m_xregexp.exec(this.sBld, PrjBook.REG_CNV_OGGO);
        if (a_2)
            this.bld_cnv_oggo = a_2['val'] || 'false';
        const a_3 = m_xregexp.exec(this.sBld, PrjBook.REG_CODE_KEY);
        if (a_3)
            this.bld_code_key = a_3['val'] || 'false';
    }
    replaceBld() {
        if (!this.existsBld)
            return;
        if (m_fs.statSync(this.path_bld).isDirectory())
            throw 'nm:' + this.fn_ + ' build.xmlはフォルダです';
        const tmp = this.sBld;
        this.sBld = this.sBld
            .replace(/name="font_out" value=".+"/, 'name="font_out" value="' + this.bld_font_out + '"')
            .replace(/name="upd_an_sdk" value=".+"/, 'name="upd_an_sdk" value="' + this.cfg_.anbook.upd_an + '"')
            .replace(/name="cnv_oggo" value=".+"/, 'name="cnv_oggo" value="' + this.bld_cnv_oggo + '"')
            .replace(/name="code_key" value=".+"/, 'name="code_key" value="' + this.bld_code_key + '"');
        if (tmp == this.sBld)
            return;
        m_fs.writeFile(this.path_bld, this.sBld, { encoding: 'utf8' });
    }
    get prjFoldDB() {
        const ret = [];
        if (!this.existsCfg)
            return ret;
        let s_anc = '';
        const a = m_fs.readdirSync(this.path_nm).sort((a, b) => {
            a = a.toString().toLowerCase();
            b = b.toString().toLowerCase();
            if (a > b)
                return 1;
            if (a < b)
                return -1;
            return 0;
        });
        a.forEach(dir => {
            const stat = m_fs.statSync(this.path_nm + dir);
            if (dir.charAt(0) == '.')
                return;
            const ext = m_path.extname(this.path_nm + dir).slice(1);
            if (ext == 'cache')
                return;
            if (ext == 'air')
                return;
            if (ext == 'exe')
                return;
            if (ext == 'ipa')
                return;
            if (ext == 'apk')
                return;
            if (ext == 'swf')
                return;
            const pe = {
                fn: '',
                path: m_path.basename(this.path_nm + dir),
                value: 'n',
                n_enabled: true,
                p_enabled: true,
                a_enabled: true,
                hide: false,
            };
            if (pe.path in this.cfg.anbook.inc_path)
                pe.value = 'a';
            if (stat.isDirectory()) {
                pe.fn = pe.path + '/';
                if (pe.path in this.cfg.search)
                    pe.value = 'p';
            }
            else {
                pe.fn = pe.path;
                pe.p_enabled = false;
            }
            const fnc = this.hCaedN2F[pe.fn];
            if (fnc != null) {
                fnc(pe);
                if (pe.hide)
                    return;
            }
            if (!stat.isDirectory()) {
                ret.push(pe);
                return;
            }
            switch (dir) {
                case 'font':
                case 'icon':
                case 'SDK':
                case 'Work':
                case 'Work_dust':
                    ret.push(pe);
                    return;
            }
            s_anc += '\t\t<antcall target="anc2"><param name="dir_n" value="' + dir + '"/></antcall>\n';
            ret.push(pe);
        });
        if (this.existsBld) {
            const tmp = this.sBld;
            this.sBld = this.sBld
                .replace(/\t\t<antcall target="anc2">[\s\S]+?\/target>/m, s_anc + '\t</target>');
            if (tmp != this.sBld)
                m_fs.writeFile(this.path_bld, this.sBld, { encoding: 'utf8' });
        }
        const spD = this.cfg_.search;
        for (let dir in spD) {
            const path_dir = this.path_nm + dir + '/';
            if (!m_fs.existsSync(path_dir))
                delete spD[dir];
        }
        const aiD = this.cfg_.anbook.inc_path;
        for (let inc in aiD) {
            const path_inc = this.path_nm + inc + '/';
            if (!m_fs.existsSync(path_inc))
                delete spD[path_inc];
        }
        this.replaceCfg();
        return ret;
    }
    setPrjFoldDB(fld, val) {
        this.prjFoldDB.some(dir => {
            if (dir.path != fld)
                return false;
            delete this.cfg_.search[fld];
            delete this.cfg_.anbook.inc_path[fld];
            switch (val) {
                case "n": break;
                case "p":
                    this.cfg_.search[fld] = true;
                    break;
                case "a":
                    this.cfg_.anbook.inc_path[fld] = true;
                    break;
                default: throw 'error setPrjFoldDB:0';
            }
            dir.value = val;
            this.replaceCfg();
            return true;
        });
        if (!this.existsBld)
            return;
        let aPackDir = [];
        this.prjFoldDB.forEach(dir => {
            if (dir.value == 'p')
                aPackDir.push(dir.path);
        });
        aPackDir.sort();
        const tmp = this.sBld;
        this.sBld = this.sBld
            .replace(new RegExp('(\{app_name\}\.swf)( .+)?( config\.anprj).*?"', 'g'), '$1$2$3 ' + aPackDir.join(' ') + '"');
        if (tmp != this.sBld)
            m_fs.writeFile(this.path_bld, this.sBld, { encoding: 'utf8' });
    }
    get codeFoldDB() {
        const a = [];
        m_fs.readdirSync(this.path_nm).forEach(fld => {
            const stat = m_fs.statSync(this.path_nm + fld);
            if (!stat.isDirectory())
                return [];
            const oD = { nm: fld + '/', code: false, disabled: false };
            switch (fld) {
                case 'font':
                case 'icon':
                case 'SDK':
                case 'Work':
                case 'Work_dust':
                    oD.disabled = true;
                    break;
                default:
                    oD.code = m_fs.existsSync(this.path_nm + 'Work/before_anc/' + fld);
            }
            a.push(oD);
        });
        return a;
    }
    setCodeFoldDB(path, val) {
        if (!m_fs.existsSync(this.path_nm + path))
            return;
        const stat_w = m_fs.statSync(this.path_nm + path);
        if (!stat_w.isDirectory())
            return;
        const fAncDir = this.path_nm + 'Work/before_anc/' + path;
        const exist_AncDir = m_fs.existsSync(fAncDir);
        switch (val) {
            case 'n':
                if (!exist_AncDir)
                    break;
                m_fs.readdirSync(fAncDir).forEach(f => {
                    if (f.substr(-1) == '_')
                        return;
                    AnbMain_1.AnbMain.dropDust(this.path_nm + path + f + '_');
                });
                m_fs.readdirSync(fAncDir).forEach(f => {
                    m_fs.copySync(fAncDir + f, this.path_nm + path + f);
                });
                AnbMain_1.AnbMain.dropDust(fAncDir);
                break;
            case 'a':
                if (exist_AncDir)
                    break;
                const regNoAnc = new RegExp(this.nocode_reg);
                m_fs.readdirSync(this.path_nm + path).forEach(f => {
                    if (regNoAnc.test(path + f))
                        return;
                    if (f.substr(-1) == '_')
                        return;
                    m_fs.move(this.path_nm + path + f, fAncDir + f, { overwrite: true }, err => { if (err)
                        AnbMain_1.AnbMain.noticeErr(err); });
                });
                break;
        }
    }
    pack_anbook() {
        const path_tmp = AnbData_1.AnbData.path_app_str + 'tmp/';
        const path_desktop = AnbData_1.AnbData.path_desktop;
        m_fs.removeSync(path_tmp);
        const code = !(this.nocode == 'true');
        m_fs.mkdirsSync(path_tmp + this.fn);
        m_fs.readdirSync(this.path_nm).forEach(f => {
            const fDir = this.path_nm + f;
            if (m_fs.lstatSync(fDir).isDirectory()) {
                if (!(f in this.cfg.search) && (!(f in this.cfg.anbook.inc_path)))
                    return;
                const fTmpDir = path_tmp + this.fn + '/' + f + '/';
                m_fs.copySync(fDir, fTmpDir);
                const fAncDir = this.path_nm + 'Work/after_anc/' + f + '/';
                if (m_fs.existsSync(fAncDir)) {
                    m_fs.readdirSync(fTmpDir).forEach(f2 => {
                        if (f2.substr(-1) == '_')
                            AnbMain_1.AnbMain.dropDust(fTmpDir + f2);
                    });
                    m_fs.readdirSync(fAncDir).forEach(f2 => {
                        m_fs.copySync(fAncDir + f2, fTmpDir + f2);
                    });
                }
                if (code)
                    m_fs.readdirSync(fTmpDir).forEach(f2 => {
                        const fn2 = fTmpDir + f2;
                        const buf = m_fs.readFileSync(fn2);
                        m_fs.writeFileSync(fn2 + '_', PrjBook.crc4.rc4(buf, buf.length));
                        m_fs.removeSync(fn2);
                    });
                return;
            }
            if (f.charAt(0) == '.')
                return;
            if (f.substr(-6) == '\.cache')
                return;
            if (f.substr(-4) == '\.swf')
                return;
            m_fs.copySync(this.path_nm + f, path_tmp + this.fn + '/' + f);
        });
        const fn_anbook = path_desktop + this.fn + '.anbook';
        const zip = m_jszip();
        this.zip_dig(zip, path_tmp, this.fn);
        zip.generateAsync({ type: 'nodebuffer' }).then(content => {
            m_fs.writeFile(fn_anbook, content, err => {
                if (err)
                    throw '例外:' + err;
                m_fs.removeSync(path_tmp);
                AnbMain_1.AnbMain.notice('デスクトップに ' + this.fn + '.anbook を保存しました', 'success');
            });
        });
    }
    zip_full() {
        const id = this.id_;
        const fn_anbook = AnbData_1.AnbData.path_desktop + this.fn + '.anbzip';
        const zip = m_jszip();
        this.zip_dig(zip, AnbData_1.AnbData.path_unpack, this.fn);
        zip.generateAsync({ type: 'nodebuffer' }).then(content => {
            m_fs.writeFile(fn_anbook, content, err => {
                if (err)
                    throw '例外:' + err;
                AnbMain_1.AnbMain.notice('デスクトップに ' + this.fn + '.anbzip を保存しました', 'success');
            });
        });
    }
    zip_dig(zip, base_dir, fold) {
        m_fs.readdirSync(base_dir + fold).forEach(f => {
            if (f.charAt(0) == '.')
                return;
            f = m_path.posix.join(fold, f);
            const f2 = m_path.posix.join(base_dir, f);
            if (m_fs.lstatSync(f2).isDirectory()) {
                this.zip_dig(zip, base_dir, f);
                return;
            }
            zip.file(f, m_fs.readFileSync(f2));
        });
    }
    mkp(path) {
        if (!this.existsCfg)
            return;
        let ret = '{';
        const xS = $.parseXML(m_fs.readFileSync(this.path_cfg, 'utf8'));
        const sp = $(xS).find('search path');
        const len = sp.length;
        let aFn = [];
        for (let i = 0; i < len; ++i) {
            const d = $(sp[i]).attr('dir');
            const path_d = path + '/' + d;
            if (!m_fs.existsSync(path_d))
                continue;
            if (!m_fs.statSync(path_d).isDirectory())
                continue;
            m_fs.readdirSync(path_d).forEach(fn => {
                if (fn.indexOf('.') == -1)
                    return;
                aFn.push([fn, d]);
            });
        }
        aFn.sort();
        const len_aFn = aFn.length;
        for (let j = 0; j < len_aFn; ++j) {
            const a = aFn[j];
            const r = m_path.parse(a[0]);
            const d = a[1];
            ret += '"' + r.name + '":{"' + r.ext.slice(1)
                + '":"' + (d + '/' + encodeURIComponent(r.base)) + '"},';
        }
        ret = ret.slice(0, -1) + '}';
        m_fs.writeFile(this.path_nm + 'path.txt', ret, { encoding: 'utf8' });
    }
}
PrjBook.hKey4DateInit = {
    'title': true,
    'creator': true,
    'cre_url': true,
    'publisher': true,
    'pub_url': true,
    'detail': true,
    'upd_an': true,
    'version': true,
    'prjtype': true,
    'nocode_reg': true,
    'nocode': true,
    'pack_exc': true,
    'rotate': true,
    'first_script_P_fn': true,
    'init_P_bg_color': true,
    'init_P_tagch_msecwait': true,
    'init_P_auto_msecpagewait': true,
    'window_P_width': true,
    'window_P_height': true,
    'bld_xml_code_key': true,
    'bld_xml_font_out': true,
    'bld_xml_cnv_oggo': true,
};
PrjBook.REG_FONT_OUT = m_xregexp('<property\\s+name="font_out"\\s+value="(?<val>.+)"');
PrjBook.REG_UPD_AN_SDK = m_xregexp('<property\\s+name="upd_an_sdk"\\s+value="(?<val>.+)"');
PrjBook.REG_CNV_OGGO = m_xregexp('<property\\s+name="cnv_oggo"\\s+value="(?<val>.+)"');
PrjBook.REG_CODE_KEY = m_xregexp('<property\\s+name="code_key"\\s+value="(?<val>.+)"');
PrjBook.key_sc = '654kruXDhVHEkcr1mA9DbZNS2E1J6wovd4ZcWSXfXATcwN75t8Z72xB3SnCua7dORFmWbFuwfpOfQ8L3Es67ErU0i4SzGzwo5orpIzzvBG9YbVuhZB1VBXODWI36pEIyJCRQUTxJZFxAgkhERUMCTkBRl3XzUodzVewPAYIpQqjgyKTdIruut3lTRhkde0Y7O6lCmaMNDbwnaUVSmJNWtYiZp0QP3RpimEhTgMZ0LYcg55NLBgUuQceC3AsPY3d4';
PrjBook.crc4 = new CriptRC4_1.CriptRC4(PrjBook.key_sc);
exports.PrjBook = PrjBook;
//# sourceMappingURL=PrjBook.js.map