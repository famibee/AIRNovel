"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AnbMain_1 = require("./AnbMain");
$(document).on('pageinit', '#index', () => {
    new AnbMain_1.AnbMain;
    const { shell } = require('electron');
    window['openURL'] = shell.openExternal;
});
//# sourceMappingURL=index.js.map