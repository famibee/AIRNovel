"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function int(o) { return parseInt(String(o), 10); }
exports.int = int;
function uint(o) {
    const v = parseInt(String(o), 10);
    return v < 0 ? -v : v;
}
exports.uint = uint;
function trim(s) { return s.replace(/^\s+|\s+$/g, ''); }
exports.trim = trim;
if (!String.prototype['toInt']) {
    String.prototype['toInt'] = function () {
        return parseInt(String(this), 10);
    };
}
if (!String.prototype['toUint']) {
    String.prototype['toUint'] = function () {
        const v = parseInt(String(this), 10);
        return v < 0 ? -v : v;
    };
}
if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, '');
    };
}
const m_path = require("path");
;
class CmnLib {
    static argChk_Num(hash, name, def) {
        const v = hash[name];
        if (!v) {
            if (isNaN(def))
                throw ('[' + hash['タグ名'] + ']属性 ' + name + ' は必須です');
            hash[name] = def;
            return def;
        }
        const n = (String(v).substr(0, 2) == '0x')
            ? parseInt(v)
            : parseFloat(v);
        if (isNaN(n))
            throw ('[' + hash['タグ名'] + ']属性 ' + name + ' の値【' + v + '】が数値ではありません');
        return hash[name] = n;
    }
    static argChk_Boolean(hash, name, def) {
        if (!(name in hash))
            return hash[name] = def;
        const v = hash[name];
        if (v == null)
            return false;
        const v2 = String(v);
        return hash[name] = (v2 == "false") ? false : Boolean(v2);
    }
    static seekScript(vctToken, vctLNum, inMacro, lineNum, skipLabel, idxToken) {
        const len = vctToken.length;
        if (!skipLabel) {
            if (idxToken >= len)
                throw ('[jump系] 内部エラー idxToken:' + idxToken + ' は、最大トークン数:' + len + 'を越えます');
            if (vctLNum[idxToken] == 0) {
                lineNum = 1;
                for (let j = 0; j < idxToken; ++j) {
                    if (vctLNum[j] == 0)
                        vctLNum[j] = lineNum;
                    const token_j = vctToken[j];
                    if (token_j.charCodeAt(0) == 10) {
                        lineNum += token_j.length;
                    }
                }
                vctLNum[idxToken] = lineNum;
            }
            else {
                lineNum = vctLNum[idxToken];
            }
            return {
                idxToken: idxToken,
                lineNum: lineNum
            };
        }
        let i = 0;
        vctLNum[0] = 1;
        const a_skipLabel = skipLabel.match(CmnLib.REG_LABEL);
        if (!a_skipLabel) {
            lineNum = 1;
        }
        else {
            const base_skipLabel = skipLabel;
            skipLabel = a_skipLabel[1];
            switch (a_skipLabel[2]) {
                case 'before':
                    while (vctLNum[i] != lineNum)
                        ++i;
                    while (vctToken[i] != skipLabel) {
                        if (i == 0)
                            throw ('[jump系 無名ラベルbefore] '
                                + lineNum + '行目以前で' + (inMacro ? 'マクロ内に' : '')
                                + 'ラベル【' + skipLabel + '】がありません');
                        if (inMacro && vctToken[i].search(CmnLib.REG_TOKEN_MACRO_BEGIN) > -1)
                            throw ('[jump系 無名ラベルbefore] マクロ内にラベル【' + skipLabel + '】がありません');
                        --i;
                    }
                    return {
                        idxToken: i + 1,
                        lineNum: vctLNum[i]
                    };
                case 'after':
                    i = len - 1;
                    while (vctLNum[i] != lineNum)
                        --i;
                    if (!inMacro)
                        break;
                    while (vctToken[i] != skipLabel) {
                        if (i == len)
                            throw ('[jump系 無名ラベルafter] '
                                + lineNum + '行目以後でマクロ内にラベル【' + skipLabel + '】がありません');
                        if (vctToken[i].search(CmnLib.REG_TOKEN_MACRO_END) > -1)
                            throw ('[jump系 無名ラベルafter] '
                                + lineNum + '行目以後でマクロ内にラベル【' + skipLabel + '】がありません');
                        ++i;
                    }
                    return {
                        idxToken: i + 1,
                        lineNum: vctLNum[i]
                    };
                default:
                    throw ('[jump系] 無名ラベル指定【label=' + base_skipLabel + '】が間違っています');
            }
        }
        const reLabel = new RegExp('^' + skipLabel.replace(CmnLib.REG_LABEL_ESC, '\\*')
            + '(?:\\s|;|\\[|$)');
        for (; i < len; ++i) {
            if (vctLNum[i] == 0)
                vctLNum[i] = lineNum;
            const token = vctToken[i];
            const uc = token.charCodeAt(0);
            if (uc != 42) {
                if (uc == 10)
                    lineNum += token.length;
                continue;
            }
            if (token.search(reLabel) > -1)
                return {
                    idxToken: i + 1,
                    lineNum: lineNum
                };
        }
        throw ('[jump系] ラベル【' + skipLabel + '】がありません');
    }
    static getFn(path) { return m_path.basename(path, m_path.extname(path)); }
    static getExt(path) { return m_path.extname(path).slice(1); }
}
CmnLib.stageW = 0;
CmnLib.stageH = 0;
CmnLib.devtool = false;
CmnLib.osName = '';
CmnLib.isRetina = false;
CmnLib.retinaRate = 1;
CmnLib.retinaFnTail = '';
CmnLib.userFnTail = '';
CmnLib.REG_LABEL = /(\*{2,})(.*)/;
CmnLib.REG_LABEL_ESC = /\*/g;
CmnLib.REG_TOKEN_MACRO_BEGIN = /\[macro\s/;
CmnLib.REG_TOKEN_MACRO_END = /\[endmacro[\s\]]/;
exports.CmnLib = CmnLib;
//# sourceMappingURL=CmnLib.js.map