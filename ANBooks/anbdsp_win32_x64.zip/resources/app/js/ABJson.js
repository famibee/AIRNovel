"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const { remote } = require('electron');
const app = remote.app;
const m_fs = require('fs-extra');
const m_os = require('os');
const m_path = require('path');
const xmls = new XMLSerializer();
require('date-utils');
const PrjBook_1 = require("./PrjBook");
var sSortbtn;
(function (sSortbtn) {
    sSortbtn["SortRandom"] = "raSortRandom";
    sSortbtn["Sort1"] = "raSort1";
    sSortbtn["Sort2"] = "raSort2";
    sSortbtn["Sort3"] = "raSort3";
    sSortbtn["SortMy"] = "raSortM";
})(sSortbtn = exports.sSortbtn || (exports.sSortbtn = {}));
;
;
class AnbData {
    constructor() {
        this.fn = '';
        this.sJson = '';
        this.ver = '';
        this.hSys = {
            'nativeWindow.x': 0,
            'nativeWindow.y': 0,
            'nativeWindow.width': 600,
            'nativeWindow.height': 800,
            'winTerm.x': 600,
            'winTerm.y': 0,
            'winTerm.w': 600,
            'winTerm.h': 800,
            'last_id': 0,
            'sLayoutMode': 'list',
            'sMySort': '',
            'sSortbtn': sSortbtn.Sort1,
            'isReplace_AddSameFile': true,
            'sSortkey': 'id',
            'sSortOrder': 'desc',
        };
        this.hBook = {};
        this.cntBook = 0;
        this.pBldp = null;
        this.sBldp = null;
        this.xBldp = null;
        this.regNoPrjname = new RegExp('\W', 'g');
    }
    init(fn) {
        this.fn = fn;
        this.sJson = m_fs.readFileSync(this.fn, { encoding: 'utf8' });
        const js = JSON.parse(this.sJson);
        this.ver = js.ver;
        this.hSys = js.sys;
        const exists_abnjson = m_fs.existsSync(this.fn);
        if (exists_abnjson) {
            for (let id in js.book) {
                const o = js.book[id];
                const bl = {
                    fn: o.fn,
                    icon: o.icon,
                    title: o.title,
                    creator: o.creator,
                    cre_url: o.cre_url,
                    publisher: o.publisher,
                    pub_url: o.pub_url,
                    detail: o.detail,
                    upd_an: o.upd_an,
                    version: o.version,
                    prjtype: o.prjtype,
                    nocode_reg: o.nocode_reg,
                    nocode: o.nocode,
                    pack_exc: o.pack_exc,
                    rotate: o.rotate,
                    dl_url: o.dl_url,
                };
                this.hBook[id] = bl;
            }
        }
        else {
            const a = m_fs.readdirSync(AnbData.path_unpack), len = a.length;
            const aSort = [];
            for (let i = 0; i < len; ++i) {
                const nm = a[i];
                if (nm.charAt(0) == '.' || nm == 'Thumbs.db'
                    || nm == 'Desktop.ini' || nm == '_notes')
                    continue;
                const pb = new PrjBook_1.PrjBook(nm, 'lst_0');
                const path_nm = AnbData.path_unpack + nm + '/';
                aSort.push({ ab: pb, ts: m_fs.statSync(path_nm).birthtime });
            }
            aSort.sort((a, b) => {
                const a_ = a.ts, b_ = b.ts;
                if (a_ < b_)
                    return -1;
                if (a_ > b_)
                    return 1;
                return 0;
            });
            for (let i = 0; i < this.hSys.last_id; ++i) {
                const ab = aSort[i].ab;
                ab.id = 'lst_' + i;
                this.hBook[ab.id] = ab;
            }
        }
        if (this.hSys.sMySort)
            this.hSys.sMySort = this.hSys.sMySort.split(',')
                .filter((x, i, self) => {
                return self.indexOf(x) === i;
            })
                .join(',');
        this.pBldp = AnbData.path_app_str + 'build.p.xml';
        if (m_fs.existsSync(this.pBldp)) {
            this.sBldp = m_fs.readFileSync(this.pBldp, { encoding: 'utf8' });
        }
        else {
            const code_key = AnbData.create_pwd(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_');
            this.sBldp = m_fs.readFileSync(AnbData.path_app_nw, { encoding: 'utf8' } + 'template/build.p.xml')
                .replace('name="sign_key" value="dummy_password"', 'name="sign_key" value="' + code_key + '"')
                .replace(new RegExp('"app_dir" value=".+"'), '"app_dir" value="' +
                m_path.normalize(AnbData.path_app_nw + '/..') + '"')
                .replace(new RegExp('"appstr_dir" value=".+"'), '"appstr_dir" value="' + AnbData.path_app_str + '"');
            if (AnbData.is_mac) {
                this.sBldp = this.sBldp
                    .replace(new RegExp('"flex_sdk" value=".+"', 'g'), '"flex_sdk" value="' + AnbData.path_desktop + 'SDK/flex_sdk/"');
            }
            m_fs.writeFile(this.pBldp, this.sBldp, { encoding: 'utf8' });
        }
        this.xBldp = $.parseXML(this.sBldp);
        m_fs.copy(AnbData.path_app_nw + 'template/build_base.xml', AnbData.path_app_str + 'build_base.xml');
        const me = this;
        let xl_flex_sdk = $(this.xBldp).find('os[family="' + (AnbData.is_mac ? 'unix' : 'windows')
            + '"]').parent('condition[property="flex_sdk"]');
        $('#txt_gbld_flex_sdk')
            .val(xl_flex_sdk.attr('value'))
            .on('textchange', function () {
            const t = $(this);
            let v = String(t.val());
            const mes = (() => {
                if (v.indexOf(' ') >= 0)
                    return 'Flex SDKパスは半角空白を含んではいけません';
                v = v
                    .replace(/[\\\/]+/g, '/')
                    .replace(/[\/\¥]$/, '') + '/';
                if (!m_fs.existsSync(v))
                    return 'フォルダが見つかりません';
                try {
                    if (!m_fs.existsSync(v + 'airnovel_lib/')) {
                        m_fs.mkdirsSync(v + 'airnovel_lib/');
                        m_fs.rmdirSync(v + 'airnovel_lib/');
                    }
                }
                catch (e) {
                    return '書き込む権限が無いので、別のフォルダにして下さい';
                }
                return '';
            })();
            if (mes)
                $('#lbl_chk_flex_sdk').text(mes).css('color', 'red');
            else {
                $('#lbl_chk_flex_sdk').text('設定完了').css('color', 'blue');
                xl_flex_sdk.attr('value', v);
                me.sBldp = xmls.serializeToString(me.xBldp);
                m_fs.writeFile(me.pBldp, me.sBldp, { encoding: 'utf8' });
            }
        });
        return exists_abnjson;
    }
    newprj(nm) {
        if (nm == '')
            return 'プロジェクト名を指定して下さい';
        if (this.regNoPrjname.test(nm))
            return 'プロジェクト名が異常です';
        const nm_len = nm.length;
        if (nm_len > 30)
            return 'プロジェクト名は30文字までです（現在' + nm_len + '文字）';
        const path_nm = AnbData.path_unpack + nm + '/';
        if (m_fs.existsSync(path_nm))
            return 'プロジェクト ' + nm + ' はすでに有ります';
        m_fs.copySync(AnbData.path_app_nw + 'template/newprj', path_nm);
        this.newprj_config(nm);
        const code_key = AnbData.create_pwd(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_');
        this.replaceTxt(path_nm + 'build.xml', str => str
            .replace('name="app_name" value="temp"', 'name="app_name" value="' + nm + '"')
            .replace('name="my_sign_key" value="dummy_password"', 'name="my_sign_key" value="' + code_key + '"')
            .replace(/web\.famibee\.temp\"\/>/g, 'web.famibee.'
            + nm.replace(/_/g, '-')
            + '\"\/>'));
        this.replaceTxt(path_nm + 'prj-app.xml', str => str
            .replace('web.famibee.temp', 'web.famibee.'
            + nm.replace(new RegExp('_', 'g'), '-'))
            .replace('<filename>temp<', '<filename>' + nm
            .replace(new RegExp('[\*":><\?\\|]', 'g'), '_') + '<')
            .replace('<name>tempプロジェクト<', '<name>' + nm + '<')
            .replace('<content>temp.swf<', '<content>' + nm + '.swf<'));
        this.replaceTxt(path_nm + 'mat/main.an', str => str.replace('temp[span layout', nm + '[span layout'));
        return '';
    }
    newprj_config(nm) {
        this.replaceTxt(AnbData.path_unpack + nm + '/config.anprj', str => this.rep_newprj_config(str, nm));
    }
    rep_newprj_config(str, nm) {
        return str
            .replace('web.famibee.temp', 'web.famibee.' + nm)
            .replace('title="temp', 'title="' + nm);
    }
    replaceTxt(url, fnc) {
        if (!m_fs.existsSync(url))
            return;
        const old_ = m_fs.readFileSync(url, 'utf8');
        const new_ = fnc(old_);
        if (old_ != new_)
            m_fs.writeFile(url, new_, { encoding: 'utf8' });
    }
    addPrj(nm, addLst) {
        const id = 'lst_' + ++this.hSys.last_id;
        const pb = this.hBook[id] = new PrjBook_1.PrjBook(nm, id);
        addLst(id, pb);
    }
    getBldp(t) {
        if (!this.xBldp)
            return null;
        const k = t.data('sdb');
        switch (k) {
            case 'keystore_i':
            case 'sign_key_i':
            case 'keystore_as':
            case 'sign_key_as':
            case 'appleid':
            case 'appleid_pass':
                const xl = $(this.xBldp).find('property[name="' + k + '"]');
                return xl.attr('value');
            default:
                return null;
        }
    }
    updBldp(t, v) {
        if (!this.xBldp)
            return null;
        const k = t.data('sdb');
        const xl = $(this.xBldp).find('property[name="' + k + '"]');
        switch (k) {
            case 'keystore_i':
            case 'sign_key_i':
            case 'keystore_as':
            case 'sign_key_as':
            case 'appleid':
            case 'appleid_pass':
                xl.attr('value', v);
                this.sBldp = xmls.serializeToString(this.xBldp);
                m_fs.writeFile(this.pBldp, this.sBldp, { encoding: 'utf8' });
                break;
        }
    }
    nm2pb(nm) {
        for (let id in this.hBook) {
            if (this.hBook[id].fn == nm)
                return this.hBook[id];
        }
        return null;
    }
    bldPrjBook(id, path_unpack) {
        const pb = this.hBook[id];
        return this.hBook[id] = new PrjBook_1.PrjBook(pb.fn, id);
    }
    flush() {
        const new_ = JSON.stringify({ ver: this.ver, sys: this.hSys, book: this.hBook });
        if (this.sJson == new_)
            return;
        this.sJson = new_;
        m_fs.writeFileSync(this.fn, this.sJson, { encoding: 'utf8' });
    }
    static get is_mac() { return m_os.type() == 'Darwin'; }
    ;
    static create_pwd(len = 256, pwd_tbl = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#%()*+-./:;=?@[]_`{}~') {
        let ret = '', cl = pwd_tbl.length;
        for (let i = 0; i < len; ++i)
            ret += pwd_tbl[Math.floor(Math.random() * cl)];
        return ret;
    }
    static getDateStr() {
        let dt = new Date();
        return dt['toFormat']('YYYY/MM/DD(' + AnbData.sday[dt.getDay()] + ') HH24MI');
    }
}
AnbData.path_app_str = app.getPath('appData').replace(/\\/g, '/')
    + '/com.fc2.blog38.famibee.ANBooks/Local Store/';
AnbData.path_app_nw = app.getAppPath().replace(/\\/g, '/') + '/';
AnbData.path_unpack = AnbData.path_app_str + 'unpack/';
AnbData.path_desktop = app.getPath('desktop').replace(/\\/g, '/') + '/';
AnbData.sday = ["日", "月", "火", "水", "木", "金", "土"];
exports.AnbData = AnbData;
//# sourceMappingURL=ABJson.js.map