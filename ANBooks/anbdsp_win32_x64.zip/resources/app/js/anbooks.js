const is_nw = (typeof process !== 'undefined')
var books = null, nav_ft = null, soSys = null, hBook = {}, cntBook = 0
var hSys = {sLayoutMode:'list', sSortbtn:'raSort1', sSortkey:'id', sSortOrder:'desc', isReplace_AddSameFile:'true'}
var jsonVer = null

var m_fs = null, m_path = null, m_os = null, is_mac = true, m_https = null
var m_jszip = null, m_spawn = null

var me_el = null, me_remote = null, me_app = null, me_bw = null
var me_ipc = null, me_shell = null, c_menu = null

var path_app_str = 'app-storage:/', path_app_nw = 'app:/app.nw/'
var path_unpack = path_app_str +'unpack/', path_desktop = null

var guiWin = null,  win_term = null, strBuf = '', ls = null, base_dir = ''

var xmls = null, hTxtCache = {}, path_nm = null
var pBldp = null, pCfg = null, pBld = null, pAppxml = null
var sBldp = null, sCfg = null, sBld = null, sAppxml = null
var xBldp = null, xCfg = null, xBld = null, xAppxml = null

var hWatch = {}, hFncWatch = {}, no_chain_chg_event = false
const KEYLENGTH = 255, keyCodes = [], bufCodes = []


$(document).on('pageinit', '#index', function(event, ui){	// 三番目に発火
	if (is_nw) {
//console.log('anbooks.js:2 is_nw')
//console.time('begin')
		m_fs = require('fs-extra')		// v1.0.0 / 2016-11-01
		m_path = require('path')
		m_os = require('os')
		is_mac = (m_os.type() == 'Darwin')
		me_el = require('electron')
		me_remote = me_el.remote
		me_app = me_remote.app

		path_app_str = me_app.getPath('appData').replace(/\\/g, '/') +'/com.fc2.blog38.famibee.ANBooks/Local Store/'
		path_app_nw = me_app.getAppPath().replace(/\\/g, '/') +'/'
		path_unpack = path_app_str +'unpack/'
		path_desktop = me_app.getPath('desktop').replace(/\\/g, '/') +'/'

//console.timeEnd('begin')
//console.time('db load')
		guiWin = me_remote.getCurrentWindow()
		try {
			if (! m_fs.existsSync(path_unpack)) m_fs.mkdirSync(path_unpack)

			const fn_anb_js = path_app_str +'ANBooks.json'
			fncFlush = function() {
				writeTxt(fn_anb_js, JSON.stringify({ver:jsonVer, sys:hSys, book:hBook}))
			}
			if (m_fs.existsSync(fn_anb_js)) {
//console.info('db already')	// 7 ms
				const js = JSON.parse(readTxt(fn_anb_js))
				hSys = js.sys
				jsonVer = js.ver
				hBook = js.book

				guiWin.setBounds({
					x:		hSys['nativeWindow.x'],
					y:		hSys['nativeWindow.y'],
					width:	hSys['nativeWindow.width'],
					height:	hSys['nativeWindow.height']
				})
			}
			else {
//console.info('db nothing')	// 99 ms
				hSys = {
					last_id		: 0,
					sLayoutMode	: 'grid',
					sSortbtn	: 'raSort1',
					sSortkey	: 'id',
					sSortOrder	: 'desc'
				}

				const a = m_fs.readdirSync(path_unpack), len = a.length
				const aSort = []
				for (var i=0; i<len; ++i) {
					const nm = a[i]
					path_nm = path_unpack + nm +'/'
					if (nm.charAt(0) == '.' || nm == 'Thumbs.db'
						|| nm == 'Desktop.ini' || nm == '_notes') continue

					++hSys.last_id
					xCfg = $.parseXML(readTxt(path_nm +'config.anprj'))
					const anb = $(xCfg).find('anbook')
					const ab = {
						id		: 'lst_0'
					,	fn		: nm
					,	title	: anb.attr('title') || ''
					,	creator	: anb.attr('creator') || ''
					,	cre_url	: anb.attr('cre_url') || ''
					,	publisher:anb.attr('publisher') || ''
					,	pub_url	: anb.attr('pub_url') || ''
					,	detail	: anb.attr('detail') || ''
					,	icon	: m_fs.existsSync(path_nm +'icon.jpg')
					,	upd_an	: 'true'
					,	version	: '1.0'
					,	prjtype	: anb.attr('prjtype') || ''
					,	nocode_reg: anb.attr('nocode_reg') ||
									'system/.+.(mp3|swf|xml)|m4a|config/.+'
					,	nocode	: anb.attr('nocode')
					,	pack_exc: anb.attr('pack_exc') || '\.swf\.cache'
					,	rotate	: anb.attr('rotate')
					,	dl_url	: ''
					}
					const ts = m_fs.statSync(path_nm).birthtime
					aSort.push({ab:ab, ts:ts})
				}
				aSort.sort(function(a,b) {
					const a_ = a.ts, b_ = b.ts
					if (a_ < b_) return -1
					if (a_ > b_) return 1
					return 0
				})
				for (var i=0; i<hSys.last_id; ++i) {
					const ab = aSort[i].ab
					ab.id = 'lst_'+ i
					hBook[ab.id] = ab
				}
				guiWin.webContents.on('dom-ready', function () {
					const p = guiWin.getPosition()
					const s = guiWin.getSize()
//addLog('dom-ready x:'+ p[0] +' y:'+ p[1] +' w:'+ s[0] +' h:'+ s[1])
					hSys['nativeWindow.x']		= p[0]
					hSys['nativeWindow.y']		= p[1]
					hSys['nativeWindow.width']	= s[0]
					hSys['nativeWindow.height']	= s[1]
					fncFlush()
				})
			}
			
			guiWin.on('move', function () {
				const a = guiWin.getPosition()
//addLog('move x:'+ a[0] +' y:'+ a[1])
				hSys['nativeWindow.x'] = a[0]
				hSys['nativeWindow.y'] = a[1]
				fncFlush()
			})
			guiWin.on('resize', function (w, h) {
				const a = guiWin.getSize()
//addLog('resize w:'+ a[0] +' h:'+ a[1])
				hSys['nativeWindow.width'] = a[0]
				hSys['nativeWindow.height']= a[1]
				fncFlush()
			})


			// build.p.xml
			pBldp = path_app_str +'build.p.xml'
			if (m_fs.existsSync(pBldp)) {
				sBldp = readTxt(pBldp)
			}
			else {
				const code_key = create_pwd(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_')
				sBldp = readTxt(path_app_nw +'template/build.p.xml')
				.replace(
					'name="sign_key" value="dummy_password"'
				,	'name="sign_key" value="'+ code_key +'"')
				.replace(	// win未テスト
					new RegExp('"app_dir" value=".+"')
				,	'"app_dir" value="'+
						m_path.normalize(path_app_nw +'/..') +'"')
				.replace(	// win未テスト
					new RegExp('"appstr_dir" value=".+"')
				,	'"appstr_dir" value="'+ path_app_str +'"')

				if (is_mac) {
					// Macでは「flex_sdk」デフォルトをデスクトップにする
						// とにかくなにも考えなくても動くことを優先
					sBldp = sBldp
					.replace(
						new RegExp('"flex_sdk" value=".+"', 'g')
					,	'"flex_sdk" value="'+ path_desktop +'SDK/flex_sdk/"')
				}
				m_fs.writeFile(pBldp, sBldp, {encoding:'utf8'})
			}
			xBldp = $.parseXML(sBldp)

			// build_base.xml
			// ただのコピーで良い（少なくとも2016/03/22には気付いてたらしい）
			m_fs.copy(path_app_nw +'template/build_base.xml'
				,	path_app_str +'build_base.xml')

			// その他
			closeWin = function () {
				if (win_term) {win_term.close(); win_term = null}
				if (ls) {ls.kill(); ls = null}
				strBuf = ''
			}
			$(window).unload(closeWin)

//console.timeEnd('db load')
		} catch (err) {
//			if (err.code !== 'ENOENT') throw err
			addLog(err)
		}

		const me_menu = me_remote.Menu
		const MenuItem = me_remote.MenuItem
		c_menu = new me_menu()
		c_menu.append(new MenuItem({role:'copy'}))
		c_menu.append(new MenuItem({role:'cut'}))
		c_menu.append(new MenuItem({role:'paste'}))
		c_menu.append(new MenuItem({type:'separator'}))
		c_menu.append(new MenuItem({role:'selectall'}))

		// アプリ終了イベント
		process.on('exit', function(code) {
			for (id in hBook) m_fs.unwatch(path_unpack + hBook[id].fn +'/')
		})
	}
	else if (window && window.console) {
		$('#btnTst').show()
		replaceIcon_sub = function (fn) {return fn.slice(5, -2)}
	}
	else {
		soSys = window.runtime.flash.net.SharedObject.getLocal("com.fc2.blog38.famibee.anbooks4", "/")
		jsonVer = "13:11:00 GMT+0900 2017/1/3"
			// ANBooks.as dt_ver_jsonと合わせる
		hSys = soSys.data.sys
		hBook = soSys.data.book
		fncFlush = soSys.flush
//		if (soSys.size > 0) {}
	}

	// 過去の不具合対策
	if (hSys.sMySort) hSys.sMySort = hSys.sMySort.split(',')
		.filter(function (x, i, self) {		// ID重複を削除
			return self.indexOf(x) === i;
		})
/*		.filter(function (x, i, self) {		// 存在しないIDを削除
	addLog('flt id:'+ x +' in:'+ (x in hBook))
			return true;
		})*/
	.join(',');
})
$(document).on('pagehide', '#index', function(){ hideBtnMenu() })



$(function(){	//addLog('$')	// $(document).ready、六番目に発火
//console.time('ready')
	books = $('#books')
	nav_ft = $('#nav_ft')
	if (is_nw) guiWin.setTitle('ANBooks6')

	$.mobile.defaultPageTransition = 'slide'
	$('#lst_-1').mousedown(function(e) {
		if (nav_ft.css('display') != 'none') return
		if (books.hasClass('mode_edit')) return
		$.mobile.pageContainer.pagecontainer('change', '#pg_-1')
	})

	$('#scIncS').on('textchange change', function() {
		const v = $(this).val()
		const cl = v ?books.children('[data-title*="'+ v +'"],[data-creator*="'+ v +'"]') :'.mix'
		books.mixItUp('filter', cl)
		$('input[name=raFlt]').val(['all']).checkboxradio('refresh')
	})

	$('#raLstList').click(function() {
		const old = hSys.sLayoutMode
		hSys.sLayoutMode = 'list'
		if (hSys.sLayoutMode != old) fncFlush()
		books.mixItUp('changeLayout', {display: 'block'}, true, function() { books.removeClass('grid') })
	})
	$('#raLstGrid').click(function() {
		const old = hSys.sLayoutMode
		hSys.sLayoutMode = 'grid'
		if (hSys.sLayoutMode != old) fncFlush()
		if (! books.mixItUp('isLoaded')) {books.addClass('grid'); return}
		books.mixItUp('changeLayout', {display: 'inline-block'}, true, function() { books.addClass('grid') })
	})

	const raSort1 = $('#raSort1'), raSort2 = $('#raSort2'), raSort3 = $('#raSort3')
	const raSortMy = $('#raSortMy')
	const raSortAsc = $('#raSortAsc'), raSortDesc = $('#raSortDesc')
	$('input[name=raLstSort]').click(function() {
		const o_key = hSys.sSortkey
		const o_btn = hSys.sSortbtn
		hSys.sSortkey = $(this).data('sortkey')
		hSys.sSortbtn = this.id
		if (hSys.sSortkey != o_key || hSys.sSortbtn != o_btn) fncFlush()
		if (hSys.sSortkey == 'random') {
			raSortAsc.attr('data-sort', 'random')
			raSortDesc.attr('data-sort', 'random')
		}
		else {
			raSortAsc.attr('data-sort', hSys.sSortkey +':asc')
			raSortDesc.attr('data-sort', hSys.sSortkey +':desc')
		}
	})
	raSortAsc.click(function() {
		hSys.sSortOrder = 'asc'
		fncFlush()
		raSort1.attr('data-sort', 'id:asc')
		raSort2.attr('data-sort', 'title:asc')
		raSort3.attr('data-sort', 'creator:asc')
		raSortMy.attr('data-sort', 'my:asc')
	})
	raSortDesc.click(function() {
		hSys.sSortOrder = 'desc'
		fncFlush()
		raSort1.attr('data-sort', 'id:desc')
		raSort2.attr('data-sort', 'title:desc')
		raSort3.attr('data-sort', 'creator:desc')
		raSortMy.attr('data-sort', 'my:desc')
	})

	$('input[name=raFlt]').click(function() { $('#scIncS').val('') })

	if (is_nw) $('input, textarea').on('contextmenu', function(e) {
		e.preventDefault()
		c_menu.popup(e.originalEvent.x, e.originalEvent.y)
	})


	// mixItUp
	const oMul = {animation: {animateChangeLayout: true}}
	const is_grid = (hSys.sLayoutMode != 'list')
	if (is_grid) {
		$('#raLstGrid').click()
		$('input[name=raLstStyle]').checkboxradio('refresh')
	}
	oMul.layout = {display: is_grid ?'inline-block' :'block'}

	if (hSys.sSortOrder == 'asc') {
		$('#raSortAsc').click()
		$('input[name=raSort]').checkboxradio('refresh')
	}

	$('#'+ hSys.sSortbtn).click()
	$('input[name=raLstSort]').checkboxradio('refresh')
//console.time('ready 1')
	// 任意ソート順に追加する
	var ms = ''			// 過去の不具合対策
	const old_sMySort = hSys.sMySort
	if (! hSys.sMySort) {
		const as = []
		for (k in hBook) as.push(k)
		hSys.sMySort = as.sort().reverse().join(',')
	}
	$.each(hSys.sMySort.split(','), function(){
		const ab = hBook[this]
		if (ab == undefined) return	// 過去の不具合対策

		addLst(ab)			// 一部処理が非同期
		ms = ms +','+ this	// 過去の不具合対策
	});
	hSys.sMySort = ms.slice(1)
	if (hSys.sMySort != old_sMySort) fncFlush()

	if (is_nw) {
		me_bw = me_remote.BrowserWindow
		m_https = require('https')
		m_jszip = require('./js/jszip.min')		// v3.0.0 2016-04-13
		m_spawn = require('child_process').spawn
		xmls = new XMLSerializer()
		require('./js/date-utils.min')			// v1.2.21


		cbDrawDetail = function (id, cache) {
			if (cache === undefined) cache = true

			const ab = hBook[id], nm = ab.fn
			path_nm = path_unpack + nm +'/'
			pCfg = path_nm +'config.anprj'
			pBld = path_nm +'build.xml'
			pAppxml = path_nm +'prj-app.xml'
			try {
				cbDrawDetail_Appxml(id, cache)	// _Cfgより前にする
				cbDrawDetail_Cfg(id, cache)
				cbDrawDetail_Bld(cache)

	//addLog('id:'+ id +' title:'+ $(xCfg).find('anbook').attr('title'))
				// j	id: 417,			// no touch
				// j	fn: "Emote",		// no touch
				ab.icon = (m_fs.existsSync(path_unpack + ab.fn +'/icon.jpg'))
				// 	rotate: { },
				// j	upd_an: "true",		// no touch
				// j	dl_url: "",			// no touch
			} catch (err) {
				addLog(err)
				// If the type is not what you want, then just throw the error again.
				if (err.code !== 'ENOENT') throw err
				
				// Handle a file-not-found error
			}
		}
		function cbDrawDetail_Cfg(id, cache) {
			sCfg = readTxt(pCfg, cache)
			xCfg = $.parseXML(sCfg)
//addLog('[*]pCfg:'+ pCfg +' xCfg:'+ xCfg +' pCfg:'+ m_fs.existsSync(pCfg))

			const ab = hBook[id]
			ab.title = $(xCfg).find('anbook').attr('title')	|| ''
			ab.creator = $(xCfg).find('anbook').attr('creator')	|| ''
			ab.cre_url = $(xCfg).find('anbook').attr('cre_url')	|| ''
			ab.publisher = $(xCfg).find('anbook').attr('publisher')	|| ''
			ab.pub_url = $(xCfg).find('anbook').attr('pub_url')	|| ''
			ab.detail = $(xCfg).find('anbook').attr('detail')	|| ''
			ab.upd_an = $(xCfg).find('anbook').attr('upd_an')	|| 'true'
			ab.version = $(xCfg).find('anbook').attr('version')	|| '1.0'
			ab.prjtype = $(xCfg).find('anbook').attr('prjtype')	|| ''
			ab.pack_exc = $(xCfg).find('anbook').attr('pack_exc')	|| ''
			// 	→まぁbの「<project default="do_i">」みてもいいけどね
			// j	nocode_reg: "system/.+.(mp3|swf|xml)|m4a|config/.+",
				// no touch
			ab.nocode = $(xCfg).find('anbook').attr('nocode')	|| ''
			ab.pack_exc = $(xCfg).find('anbook').attr('pack_exc')
				|| '\.swf\.cache'

			if (m_fs.existsSync(pAppxml)) replaceAppxml(ab)
		}
			function replaceAppxml(ab) {
				if (! sAppxml) return

				sAppxml = sAppxml
				.replace(
					new RegExp('<versionNumber>.*<\/versionNumber>')
				,	'<versionNumber>'+ ab.version +'</versionNumber>'
				)
				.replace(
					new RegExp('<filename>.*<\/filename>')
				,	'<filename>'+ ab.title
					.replace(
						new RegExp('[\*":><\?\\|]', 'g')
					,	'_'
					) +'</filename>'
					// ダメな文字
					// http://help.adobe.com/ja_JP/air/build/WSfffb011ac560372f2fea1812938a6e463-8000.html#WSfffb011ac560372f2fea1812938a6e463-7ff9
				)
				.replace(
					new RegExp('<name>.*<\/name>')
				,	'<name>'+ ab.title +'</name>'
				)
				.replace(
					new RegExp('<copyright>.*<\/copyright>')
				,	'<copyright>'+ (ab.publisher || ab.creator)
					+'</copyright>'
				)
				.replace(
					new RegExp('<description>.*<\/description>')
				,	'<description>'+ ab.detail +'</description>'
				)
				m_fs.writeFile(pAppxml, sAppxml, {encoding:'utf8'})
				xAppxml = $.parseXML(sAppxml)
			}
		function cbDrawDetail_Bld(cache) {
			if (m_fs.existsSync(pBld)) {
				sBld = readTxt(pBld, cache)
				xBld = $.parseXML(sBld)
			}
			else {
				sBld = xBld = null
			}
		}
		function cbDrawDetail_Appxml(id, cache) {
			if (m_fs.existsSync(pAppxml)) {
				sAppxml = readTxt(pAppxml, cache)
				xAppxml = $.parseXML(sAppxml)
				const ab = hBook[id]
				ab.version = $(xAppxml).find('versionNumber').text()
					|| '1.0'
			}
			else {
				sAppxml = xAppxml = null
			}
		}

		replaceIcon = function (id) {
			var fn = path_unpack + hBook[id].fn +'/icon.jpg'
			if (! m_fs.existsSync(fn)) {
				fn = 'mat/menu_def_icon.jpg'
			}
			else fn = 'file://'+ fn
			fn = fn + '?'+ (new Date().getTime())

			const img = $('#'+ id +' >div:first')
			img.css('background-image', fn)
			$('#pg_'+ id +'_icon').attr('src', fn)
		}

// 「SharedObjectまたはjson」を読んだ後、実ファイルから調べて上書き
//		c … config.anprj
//		b … build.xml
//		p … prj-app.xml
//		j … AIRNovel.json
		loadFDB = function (id) {
			const nm = hBook[id].fn
			if (! m_fs.existsSync(path_unpack + nm +'/')) {
				delete hBook[id]
				return
			}
			cbDrawDetail(id)

			// ここで変更監視もつける。id単位の関数にし、
			// プロジェクトの追加変更で、監視も個別に追加変更する
			def_watch(id)
		}
		for (id in hBook) loadFDB(id)

		//============================
		const a_cbDrawDetail_Cfg = ['title', 'creator', 'cre_url', 'publisher', 'pub_url', 'detail', 'pack_exc', 'nocode', 'version', 'fn', 'bg_color', 'tagch_msecwait', 'auto_msecpagewait', 'width', 'height']
		const a_cbDrawDetail_Bld = ['upd_an', 'font_out', 'cnv_oggo']
		function def_watch(id) {
//addLog('[def_watch] id:'+ id)
			hFncWatch[id] = function (fn2) {
				if (no_chain_chg_event) return
				no_chain_chg_event = true

//addLog('[watch] fn:'+ nm +' fn2:'+ fn2)
				// icon
				if (fn2 == 'icon.jpg') {
					replaceIcon(id)
//addLog('[watch] Go!')
					no_chain_chg_event = false
					return
				}

				const ab = hBook[id]
					// 中でセットする変数は退避しておく必要がある
					// =================	→？
				switch (fn2) {
				case 'config.anprj':
					if (! xCfg) break

					const osCfg = sCfg
					sCfg = readTxt(pCfg, false)
					if (sCfg == osCfg) break

//addLog('[watch] Go!')
					cbDrawDetail_Cfg(id, false)
					a_cbDrawDetail_Cfg.forEach(function (v) {
						redrawDetail(id, ab, v)
					})
					break
				case 'prj-app.xml':
					if (! xAppxml) break

					const osAppxml = sAppxml
					sAppxml = readTxt(pAppxml, false)
					if (sAppxml == osAppxml) break

//addLog('[watch] Go!')
					cbDrawDetail_Appxml(id, false)
					redrawDetail(id, ab, 'version')
					break
				case 'build.xml':
					if (! xBld) break

					const osBld = sBld
					sBld = readTxt(pBld, false)
					if (sBld == osBld) break

//addLog('[watch] Go!')
					cbDrawDetail_Bld(id)
					cbDrawDetail_Bld.forEach(function (v) {
						redrawDetail(id, ab, v)
					})
					break
			// j	nocode_reg
			//		rotate
			// j	dl_url				// no touch
				}

	//			fncFlush()
				no_chain_chg_event = false
			}

			const nm = hBook[id].fn
			hWatch[id] = m_fs.watch(path_unpack + nm +'/', {persistent: false}, function (e, fn2) {
				if (id in hFncWatch) hFncWatch[id](fn2)
			})
		}
		function undef_watch(id) {
//addLog('[undef_watch] id:'+ id)
			if (! (id in hWatch)) return

//addLog('\tclose')
			hWatch[id].close()
			delete hWatch[id]
			delete hFncWatch[id]
		}
		//============================
		lockChgEvent = function(id) {
			if (no_chain_chg_event) return true

//addLog('\tGo ! id:'+ id)
			no_chain_chg_event = true
			undef_watch(id)

			return false
		}
		unlockChgEvent = function(id) {
//addLog('\tEnd. id:'+ id)
			no_chain_chg_event = false
			def_watch(id)
		}
		//============================


		delLst = function (ab) {
			$('#'+ ab.id).remove()
			undef_watch(ab.id)
			dropDust(path_unpack + ab.fn)
			clearTxtCache(path_unpack + ab.fn +'/')
			hSys.sMySort = hSys.sMySort
				.replace(ab.id +',', '').replace(',,', ',')
			delete hBook[ab.id]
			fncFlush()
			
		}


		function CriptRC4(key) {
			const len = key.length
			for (var i=0; i<=KEYLENGTH; ++i) {
				bufCodes[i] = key[i % len].charCodeAt(0)
				keyCodes[i] = i
			}
			for (var j=i=0; i<=KEYLENGTH; ++i) {
				j = (j + keyCodes[i] + bufCodes[i]) & KEYLENGTH
				keyCodes[i] ^= keyCodes[j]
				keyCodes[j] ^= keyCodes[i]
				keyCodes[i] ^= keyCodes[j]
			}
		}
		CriptRC4(key_sc)
		
		function rc4(data, len) {
			if (len === undefined) len = 0
			var data_pos = 0
			const data_len = data.length
			if ((len == 0) || (len > data_len)) len = data_len

			const buf = keyCodes.concat()
			const baRet = new Buffer(data_len)
			var baRet_pos = 0

			var i, j, k
			for (i = j = k = 0; k<len; ++k) {
				i = (i + 1) & KEYLENGTH
				j = (j + buf[i]) & KEYLENGTH

				buf[i] ^= buf[j]
				buf[j] ^= buf[i]
				buf[i] ^= buf[j]

				const t = (buf[i] + buf[j]) & KEYLENGTH
				baRet[baRet_pos++] = (data[data_pos++] ^ buf[t])
			}

			if (len < data_len) for (var m=0; m<len; ++m) baRet[baRet_pos++] = data[data_pos++]

			return baRet
		}

	}	// if (is_nw) {	の終わり

//console.timeEnd('ready 1')
	raSortAsc.attr('data-sort', hSys.sSortkey +':asc')
	raSortDesc.attr('data-sort', hSys.sSortkey +':desc')
	oMul.load = {sort: hSys.sSortkey +':'+ hSys.sSortOrder}

//console.time('ready 3')
	books.mixItUp(oMul)
	.sortable({
		disabled: true
	,	placeholder: 'ui-state-highlight'
	,	items: '.mix'
	,	revert: 150
	,	cursor: 'move'
	,	opacity: 0.8
	,	tolerance: 'pointer'
	,	update: function(event, ui) {
			books.children() .each(function(i, e) { $(e).attr('data-my', (cntBook-i).toString()) })
			raSortMy.click()
			$("input[name='raLstSort']").checkboxradio('refresh').checkboxradio("disable")

			const o_sMySort = hSys.sMySort
			hSys.sMySort = books.sortable('toArray').join(',')
			if (hSys.sMySort != o_sMySort) fncFlush()
		}
	})
//console.timeEnd('ready 3')
	tooltip('lst_-1')

	// 新規作成
	if (is_nw) {
		const regNoPrjname = new RegExp('\W', 'g')
		function newprj(nm) {
			if (nm == '') return 'プロジェクト名を指定して下さい'
			if (regNoPrjname.test(nm)) return 'プロジェクト名が異常です'
			const nm_len = nm.length
			if (nm_len > 30) return 'プロジェクト名は30文字までです（現在'+ nm_len +'文字）'

			// copy
			path_nm = path_unpack + nm +'/'
			if (m_fs.existsSync(path_nm)) return 'プロジェクト '+ nm +' はすでに有ります'
			m_fs.copySync(
				path_app_nw +'template/newprj',
				path_nm)

			// config.anprj
			newprj_config(nm)

			// build.xml
			var fn = path_nm +'build.xml'
			replaceTxt(
				fn
			,	function (str) {return str
				.replace(
					'name="app_name" value="temp"'
				,	'name="app_name" value="'+ nm +'"'
				)
				.replace(
					/web\.famibee\.temp\"\/>/g
				,	'web.famibee.'
				//	+ nm.replace('_', '-') // _はダメらしい
					+ nm.replace(/_/g, '-') // _はダメらしい
					+ '\"\/>'
				)
			})

			// prj-app.xml
			fn = path_nm +'prj-app.xml'
			replaceTxt(
				fn
			,	function (str) {return str
				.replace(
					'web.famibee.temp'
				,	'web.famibee.'
					+ nm.replace(new RegExp('_', 'g'), '-')
						// _はダメらしい
				)
				.replace(
					'<filename>temp<'
				,	'<filename>'+ nm
					.replace(
						new RegExp('[\*":><\?\\|]', 'g')
					,	'_'
					) +'<'
					// ダメな文字
					// http://help.adobe.com/ja_JP/air/build/WSfffb011ac560372f2fea1812938a6e463-8000.html#WSfffb011ac560372f2fea1812938a6e463-7ff9
				)
				.replace(
					'<name>tempプロジェクト<'
				,	'<name>'+ nm +'<'
				)
				.replace(
					'<content>temp.swf<'
				,	'<content>'+ nm +'.swf<'
				)
			})

			// main.an
			fn = path_nm +'mat/main.an'
			replaceTxt(
				fn
			,	function (str) {return str
					.replace(
						'temp[span layout'
					,	nm +'[span layout'
					)
			})

			chg_code_key(nm, create_pwd())

			return ''
		}
		function newprj_config(nm) {
			// config.anprj
			replaceTxt(
				path_unpack + nm +'/config.anprj'
			,	function (str) {return rep_newprj_config(str, nm)}
			)
		}
			function rep_newprj_config(str, nm) {
				return str
				.replace(
					'web.famibee.temp'
				,	'web.famibee.'+ nm
				)
				.replace(
					'title="temp'
				,	'title="'+ nm
				)
			}
		function addLst_nm(nm, dl_url) {
			if (dl_url === undefined) dl_url = ''

			path_nm = path_unpack + nm +'/'
			pCfg = path_nm +'config.anprj'
			sCfg = readTxt(pCfg)
			xCfg = $.parseXML(sCfg)
			if (xCfg == null) {
				notice('開いた '+ nm +' に config.anprjがありません', 'error')
				return
			}

			const id = 'lst_'+ ++hSys.last_id
			const anb = $(xCfg).find('anbook')
			const ab = {
				id		: id
			,	fn		: nm
			,	title	: anb.attr('title') || ''
			,	creator	: anb.attr('creator') || ''
			,	cre_url	: anb.attr('cre_url') || ''
			,	publisher:anb.attr('publisher') || ''
			,	pub_url	: anb.attr('pub_url') || ''
			,	detail	: anb.attr('detail') || ''
			,	icon	: m_fs.existsSync(path_nm +'icon.jpg')
			,	upd_an	: 'true'
			,	version	: '1.0'
			,	prjtype	: anb.attr('prjtype') || ''
			,	nocode_reg: anb.attr('nocode_reg') ||
							'system/.+.(mp3|swf|xml)|m4a|config/.+'
			,	nocode	: anb.attr('nocode')
			,	pack_exc: anb.attr('pack_exc') || '\.swf\.cache'
			,	rotate	: anb.attr('rotate')
			,	dl_url	: dl_url
			}

			addLst(hBook[id] = ab)		// 一部処理が非同期
			loadFDB(id)
		}
	//	// シンプルなプロジェクトを作成
	$('#btn_newprj_simple').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != "") {notice(res, 'error'); return}

		path_nm = path_unpack + nm +'/'
		replaceTxt(
			path_nm +'prj-app.xml'
		, function (str) {return str
			.replace(
				new RegExp('<supportedProfiles>.+?<')
			,	'<supportedProfiles>desktop extendedDesktop<'
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				/<antcall target="anc2">[\s\S]+?\/target>/
			,	'<antcall target="anc2"><param name="dir_n" value="mat"/></antcall>\n\t</target>'
			)
		})

		addLst_nm(nm)
	})

		const fnprj_uc_zip = path_app_str +'template/UnderCherry.zip'
		const fnprj_if_zip = path_app_str +'template/If_I_can_fly.zip'
		const fnprj_iphone_zip = path_app_str +'template/iPhone.zip'
		const fnprj_ipad_zip = path_app_str +'template/iPad.zip'
		const fnprj_and_zip = path_app_str +'template/Android.zip'
		
		const fnprj_plg_zip = path_app_str +'template/Plugin.zip'

	//	// 「空を飛べたら Win Mac版」を元に作成
	$('#btn_newprj_if').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
				/<supportedProfiles>.+?</
			,	'<supportedProfiles>desktop extendedDesktop<'
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				/config\.anprj icon mat/g
			,	'config.anprj album bgimage bgm config fgimage icon image menu rule scenario system'
			)
			.replace(
				'<property name="font_out" value="mat"/>'
			,	'<property name="font_out" value="system"/>'
			)
		})

		dlTmp(fnprj_if_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				case 'index_l.htm':
				case 'index.htm':
					return String(data)
					.replace(/=\"temp/g, '=\"'+ nm)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})

	//	// 「桜の樹の下には Win Mac版」を元に作成
	$('#btn_newprj_uc').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
				/<supportedProfiles>.+?</
			,	'<supportedProfiles>desktop extendedDesktop<'
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				/config\.anprj icon mat/g
			,	'config.anprj album bgimage bgm config fgimage icon image menu rule scenario system'
			)
			.replace(
				'<property name="font_out" value="mat"/>'
			,	'<property name="font_out" value="system"/>'
			)
		})

		dlTmp(fnprj_uc_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				case 'index_l.htm':
				case 'index.htm':
					return String(data)
					.replace(/=\"temp/g, '=\"'+ nm)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})

	//	// 「桜の樹の下には iPhone（Retina対応）版」を元に作成
	$('#btn_newprj_uc_iphone').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
//				/<icon>.+<\/icon>/s
				/<icon>[\s\S]+<\/icon>/
			,	"<icon>\n"
			+	"\t\t<image29x29>icon/icon_029.png</image29x29>\n"
			+	"\t\t<image40x40>icon/icon_040.png</image40x40>\n"
			+	"\t\t<image50x50>icon/icon_050.png</image50x50>\n"
			+	"\t\t<image57x57>icon/icon_057.png</image57x57>\n"
			+	"\t\t<image58x58>icon/icon_058.png</image58x58>\n"
			+	"\t\t<image72x72>icon/icon_072.png</image72x72>\n"
			+	"\t\t<image76x76>icon/icon_076.png</image76x76>\n"
			+	"\t\t<image80x80>icon/icon_080.png</image80x80>\n"
			+	"\t\t<image87x87>icon/icon_087.png</image87x87>\n"
			+	"\t\t<image100x100>icon/icon_100.png</image100x100>\n"
			+	"\t\t<image114x114>icon/icon_114.png</image114x114>\n"
			+	"\t\t<image120x120>icon/icon_120.png</image120x120>\n"
			+	"\t\t<image144x144>icon/icon_144.png</image144x144>\n"
			+	"\t\t<image152x152>icon/icon_152.png</image152x152>\n"
			+	"\t\t<image180x180>icon/icon_180.png</image180x180>\n"
			+	"\t\t<image512x512>icon/icon_512.png</image512x512>\n"
			+	"\t</icon>"
			)
			.replace(
				"\t</initialWindow>"
			,	"\t\t<fullScreen>true</fullScreen>\n"
			+	"\t\t<autoOrients>false</autoOrients>\n"
			+	"\t\t<aspectRatio>landscape</aspectRatio>\n"
			+	"\t\t<renderMode>cpu</renderMode>\n"
			+	"\t</initialWindow>"
			)
			.replace(
				"</InfoAdditions>"
			,	"</InfoAdditions>\n\t\t<requestedDisplayResolution>high</requestedDisplayResolution>"
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				'-default-size 480 320'
			,	'-default-size 480 320 -source-path+=Work/システム/plgGallery'
			)
			.replace(
				'<project default="do">'
			,	'<project default="do_i">'
			)
			.replace(
				'<property name="font_out" value="mat"/>'
			,	'<property name="font_out" value="system"/>'
			)
		})

		dlTmp(fnprj_iphone_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})

	//	// 「〃 iPad（Retina対応）版」を元に作成
	$('#btn_newprj_uc_ipad').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
//				/<icon>.+<\/icon>/s
				/<icon>[\s\S]+<\/icon>/
			,	"<icon>\n"
			+	"\t\t<image29x29>icon/icon_029.png</image29x29>\n"
			+	"\t\t<image50x50>icon/icon_050.png</image50x50>\n"
			+	"\t\t<image58x58>icon/icon_058.png</image58x58>\n"
			+	"\t\t<image72x72>icon/icon_072.png</image72x72>\n"
			+	"\t\t<image76x76>icon/icon_076.png</image76x76>\n"
			+	"\t\t<image100x100>icon/icon_100.png</image100x100>\n"
			+	"\t\t<image144x144>icon/icon_144.png</image144x144>\n"
			+	"\t\t<image152x152>icon/icon_152.png</image152x152>\n"
			+	"\t\t<image512x512>icon/icon_512.png</image512x512>\n"
			+	"\t</icon>"
			)
			.replace(
				"\t</initialWindow>"
			,	"\t\t<fullScreen>true</fullScreen>\n"
			+	"\t\t<autoOrients>false</autoOrients>\n"
			+	"\t\t<aspectRatio>landscape</aspectRatio>\n"
			+	"\t\t<renderMode>cpu</renderMode>\n"
			+	"\t</initialWindow>"
			)
			.replace(
				"</InfoAdditions>"
			,	"</InfoAdditions>\n\t\t<requestedDisplayResolution>high</requestedDisplayResolution>"
			)
			.replace(
				"UIDeviceFamily</key><array><string>1"
			,	"UIDeviceFamily</key><array><string>2"
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				'<project default="do">'
			,	'<project default="do_i">'
			)
			.replace(
				'-default-size 480 320'
			,	'-default-size 1024 768 -source-path+=Work/システム/plgGallery'
			)
			.replace(
				'Default-Landscape@2x.png Default.png Default@2x.png'
			,	'Default-Portrait.png'
			)
			.replace(
				'<property name="font_out" value="mat"/>'
			,	'<property name="font_out" value="system"/>'
			)
		})

		dlTmp(fnprj_ipad_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})

	//	// 「〃 Android版」を元に作成
	$('#btn_newprj_uc_and').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
//				/<icon>.+<\/icon>/s
				/<icon>[\s\S]+<\/icon>/
			,	"<icon>\n"
			+	"\t\t<image36x36>icon/icon_036.png</image36x36>\n"
			+	"\t\t<image48x48>icon/icon_048.png</image48x48>\n"
			+	"\t\t<image72x72>icon/icon_072.png</image72x72>\n"
			+	"\t</icon>"
			)
			.replace(
				"\t</initialWindow>"
			,	"\t\t<fullScreen>true</fullScreen>\n"
			+	"\t\t<autoOrients>false</autoOrients>\n"
			+	"\t\t<aspectRatio>landscape</aspectRatio>\n"
			+	"\t\t<renderMode>cpu</renderMode>\n"
			+	"\t</initialWindow>"
			)
			.replace(
				"UIDeviceFamily</key><array><string>1"
			,	"UIDeviceFamily</key><array><string>2"
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				'<project default="do">'
			,	'<project default="do_a">'
			)
			.replace(
				'<property name="font_out" value="mat"/>'
			,	'<property name="font_out" value="system"/>'
			)
		})

		dlTmp(fnprj_and_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})

	//	// シンプルなプラグインを作成
	$('#btn_newplg_simple').click(function() {
		const nm = $('#txt_newprj').val()
		const res = newprj(nm)
		if (res != '') {noticeErr(res); return true;}

		path_nm = path_unpack + nm +'/'
		m_fs.removeSync(path_nm +'icon/')
		m_fs.removeSync(path_nm +'mat/')

		const NNm = nm.charAt().toLocaleUpperCase()
							+ (nm.length > 1 ?nm.substr(1) :"");
		replaceTxt(path_nm +'prj-app.xml', function (str) {return str
			.replace(
				/<supportedProfiles>.+?</
			,	"<supportedProfiles>desktop extendedDesktop<"
			)
		})
		replaceTxt(path_nm +'build.xml', function (str) {return str
			.replace(
				'<target name="do" depends="cmp,anc">'
			,	'<target name="do" depends="myplg_cmp,cmp,anc">'
			)
			.replace(
				'plgTemp'
			,	"plg"+ NNm
			)
			.replace(
				/<antcall target="anc2">[\s\S]+?\/target>/
			,	'<antcall target="anc2"><param name="dir_n" value="mat"/></antcall>\n\t\t<antcall target="anc2"><param name="dir_n" value="plg"/></antcall>\n\t</target>'
			)
		})

		dlTmp(fnprj_plg_zip, function (fn) {
			unZip(fn, path_nm, function (zo, data) {
				switch (zo.name) {
				case 'config.anprj':
					return rep_newprj_config(String(data), nm)
				case 'mat/main.an':
					return String(data)
					.replace(
						/plgTemp/g
					,	"plg"+ NNm
					)
				case 'source/plgTemp.as':
					zo.name = 'source/plg'+ NNm +'.as'
					return String(data)
					.replace(
						/plgTemp/g
					,	"plg"+ NNm
					)
				}
				return data
			}, function () {
				addLst_nm(nm)
			})
		})
	})


		me_shell = me_el.shell
		openURL = me_shell.openExternal
		setClipboard = function (txt) {
			me_el.clipboard.writeText(txt)
			notice('クリップボードへコピーしました', 'information')
		}
		dropDustProc = me_shell.moveItemToTrash
		
		me_ipc = me_el.ipcRenderer
		me_ipc.on('invoke', function (e, cl) {
			const len = cl.length
			if (len == 0) return

			// ターミナル実行では['app.nw']になるのに注意
			const c0 = Array.isArray(cl[0]) ?cl[0][0]  :cl[0]
			if (c0 == 'app.nw') return
//addLog('invoke='+ c0)

			const retF = new RegExp(/termf="(.+)"/).exec(c0)
			if (retF) {
				addTerm(readTxt(path_app_str + retF[1], false))
				return
			}
/*			const retM = new RegExp(/addterm="(.+)"/).exec(c0)
			if (retM) {
				addTerm(retM[1])
				return
			}
*/
			const ext = m_path.extname(c0).slice(1)
			switch (ext) {
				case 'anbook':
				case 'anbzip':
					m_fs.removeSync(path_nm +'tmp/')
					unZip(c0, path_app_str +'tmp/', undefined, function () {
						var nm = m_path.basename(c0, m_path.extname(c0))
						m_fs.readdirSync(path_app_str +'tmp/').forEach(function(f) {
							nm = f	// anbookファイル名を変更されてるかもなので
						})

						const nm2 = nm + (m_fs.existsSync(path_unpack)
							? (new Date()).toFormat('_YYYYMMDD_HH24MISS')
							: '')
//addLog('addLst_nm['+ nm +']['+ nm2 +']')
						m_fs.move(
							path_app_str +'tmp/'+ nm,
							path_unpack + nm2,
							{clobber:true},
							function (err) {
								if (err) {noticeErr(err) ;return}
								addLst_nm(nm2)
								invokeDecryption(nm2)
							})
					})
					break
				default:
					notice('サポートされない形式['+ ext +']です', 'error')
			}
		})
		function invokeDecryption(nm) {
			path_nm = path_unpack + nm +'/'
			xCfg = $.parseXML(readTxt(path_nm +'config.anprj'))
			const code = ($(xCfg).find('anbook').attr('nocode') != 'true')
//addLog('code:'+ code)
			if (! code) return

			// 復号
//addLog('path_nm:'+ path_nm)
			m_fs.readdirSync(path_nm).forEach(function(f) {
				const fDir = path_nm + f
				if (! m_fs.lstatSync(fDir).isDirectory()) return

				m_fs.readdirSync(fDir).forEach(function(f2) {
					if (f2.substr(-1) != '_') return

					f2 = fDir +'/'+ f2
					const buf = m_fs.readFileSync(f2)
					m_fs.writeFileSync(f2.slice(0, -1), rc4(buf, buf.length))
					m_fs.removeSync(f2)
				})
			})
		}

		function addLogHead(txt, ab) {
			const w = new me_bw({
				id		: 'term',
				x		: hSys['winTerm.x'],
				y		: hSys['winTerm.y'],
				width	: hSys['winTerm.w'],
				height	: hSys['winTerm.h'],
	//	x		title	: 'ターミナル：'+ ab.fn +'【'+ ab.title +'】',
				acceptFirstMouse		: true,
				textAreasAreResizable	: false,
			})
//w.openDevTools(true)
			w.webContents.on('dom-ready', function () {
				w.on('move', function() {
					const a = w.getPosition()
					hSys['winTerm.x'] = a[0]
					hSys['winTerm.y'] = a[1]
					fncFlush()
				})
				w.on('resize', function() {
					const a = w.getSize()
					hSys['winTerm.w'] = a[0]
					hSys['winTerm.h'] = a[1]
					fncFlush()
				})
			})
			w.webContents.on('did-finish-load', function() {
				if (win_term) win_term.close()	// closeWin()
				win_term = w

				addTerm('')
				w.setTitle('ターミナル：'+ ab.fn +'【'+ ab.title +'】')
				w.webContents.send('setTitle', ab.fn +'【'+ ab.title +'】')
			})
			w.loadURL('file://'+ __dirname +'/term.htm')
			w.on('close', function() {win_term = null; closeWin()})

			addTerm("<span class='inf'>"+ txt +" " + getDateStr()
				+ " " + ab.fn +"【"+ ab.title +"】</span>\n")
		}
		function addTerm(txt) {
			if (win_term) {
				if (strBuf) {win_term.webContents.send('addTrace', strBuf); strBuf = ''}
				win_term.webContents.send('addTrace', txt)
			} else strBuf += txt +'<br/>'
		}
		function goNoBld(nm, is_detail) {
			if (xCfg) ans(nm, (is_detail ?'start_detail' :'start'))
		}
		function ans(nm, arg, arg2) {
			const a = [path_unpack + nm +'/config.anprj']
			if (arg !== undefined) a.push(arg)
			if (arg2 !== undefined) a.push(arg2)
			if (is_mac) {
//addLog('ans nm:'+ nm +' arg:'+ arg +' arg2:'+ arg2)
//notice('ans', 'information')
				ls = m_spawn('/Applications/ANBooks.app/Contents/MacOS/ANBooks', a)
			}
			else {
				a[0] = nm
				ls = m_spawn(path_app_str +'app/resources/app/template/script/ans.bat', a)
			}
		}
		function onMake_app(id) {
			const ab = hBook[id]
			addLogHead("簡易アプリ生成", ab)

			addTerm("<span class='lbl'>- ez_app</span><br/>")
			m_fs.mkdirsSync(path_app_str +'template/')
			const path_ezapp_zip = path_app_str +'template/easy_app.zip'
				// AIRNovel_l.swf
				// index_ez.htm
				// package.json
			const fn_nwjs_zip = 'nwjs_'+ (is_mac ?'MAC' :'WIN') +'.zip'
			const path_nwjs_zip = path_app_str +'template/'+ fn_nwjs_zip
				// nwjs.appなど
			const path_wk_ezapp = path_nm +'Work/easy_app/'
			m_fs.mkdirsSync(path_wk_ezapp)
			dlTmp(
				path_ezapp_zip
			,	function () {
					addTerm("- 準備ez_app<br/>")
					m_fs.emptyDirSync(path_wk_ezapp)
					
					const cfg_win = $(xCfg).find('window')
					const cfg_anb = $(xCfg).find('anbook')
					// cmn.unZipではパーミッションを失うので、node-webkitは別途
					unZip(path_ezapp_zip, path_wk_ezapp, function(zo, data) {
						switch (zo.name) {
						case 'package.json':
							return String(data)
							.replace(
								'test name'
							,	ab.fn
							)
							.replace(
								'詳細'
							,	ab.detail
							)
							.replace(
								'0.1'
							,	ab.version
							)
							.replace(
								'タイトル'
							,	ab.title
							)
							.replace(
								'width": 300'
							,	'width": '+ cfg_win.attr('width')
							)
							.replace(
								'height": 300'
							,	'height": '+ cfg_win.attr('height')
							)
						case 'index_ez.htm':
							return String(data)
							.replace(
								'width="1024" height="768"'
							,	'width="'+ cfg_win.attr('width')
							+'" height="'+ cfg_win.attr('height') +'"'
							)
						}
						return data
					})

					addTerm("<span class='lbl'>- "+ fn_nwjs_zip +"</span><br/>")
					m_fs.copy(path_nm +'config.anprj',
						path_wk_ezapp +'config.anprj')
					const sp = $(xCfg).find('search path')
					const len = sp.length
					for (i=0; i<len; ++i) {
						const nm_fld = $(sp[i]).attr('dir')
						const path_anc = path_nm +'Work/before_anc/'+ nm_fld
						m_fs.copySync(
							(m_fs.existsSync(path_anc)
								? path_anc
								: path_nm + nm_fld),
							path_wk_ezapp + nm_fld)
					}
					mkp(path_nm)
					m_fs.copy(path_nm +'path.txt',
						path_wk_ezapp +'path.txt')

					// node-webkit 公式のzipでないと実行権限が付かない
					// （手動/Antで上手くいかなかった）
					dlTmp(
						path_nwjs_zip
					,	function () {
							const path_scr = path_app_nw +'template/script/mkEazyApp6.'+ (is_mac ?'sh' :'bat')
							const a = [ab.fn]
							if (is_mac) {
								a.unshift(path_scr)
								ls = m_spawn('sh', a)
							}
							else {
								ls = m_spawn(path_scr, a)
							}
							ls.stderr.on('data', function (data) {
								addTerm("<span class='err'>"+ data +"</span><br/>")
							})
							ls.on('close', function (code) {
								addTerm("<span class='inf'>[END] "+ code +"</span><br/>")
								notice('簡易アプリを生成しました', 'success')
								ls = null
							})

							return true
						}
					)
					return false	// 閉じない
				}
			)
		}
		function pack_anbook(id) {
			// tmpフォルダにコピーして処理する方式に。実ファイル触らない
			const path_tmp = path_app_str +'tmp/'
			m_fs.removeSync(path_tmp)

			// tmpフォルダのルートにファイル追加
			const b = hBook[id], nm = b.fn, code = !(b.nocode == 'true')
//addLog('pack_anbook b.nocode['+ b.nocode +'] code['+ code +']')
			m_fs.mkdirsSync(path_tmp + nm)
			path_nm = path_unpack + nm +'/'
			m_fs.readdirSync(path_nm).forEach(function(f) {
				const fDir = path_nm + f
				if (m_fs.lstatSync(fDir).isDirectory()) {
					if (! $(xCfg).find('search path[dir="'+ f +'"]')
						[0]) return

					// tmpフォルダのルートにフォルダ追加
					const fTmpDir = path_tmp + nm +'/'+ f +'/'
					m_fs.copySync(fDir, fTmpDir)
					
					const fAncDir = path_nm +'Work/after_anc/'+ f +'/'
					if (m_fs.existsSync(fAncDir)) {
						// 正フォルダの暗号化ファイル「だけ」を捨てる
						m_fs.readdirSync(fTmpDir).forEach(function(f2) {
							if (f2.substr(-1) == '_') dropDust(fTmpDir + f2)
						})
						// 暗号化前フォルダを正フォルダに上書き移動
						m_fs.readdirSync(fAncDir).forEach(function(f2) {
							m_fs.copySync(
								fAncDir + f2,
								fTmpDir + f2)
						})
					}

					// 暗号化
					if (code) m_fs.readdirSync(fTmpDir).forEach(function(f2) {
						const fn2 = fTmpDir + f2
						const buf = m_fs.readFileSync(fn2)
						m_fs.writeFileSync(fn2 +'_', rc4(buf, buf.length))
						m_fs.removeSync(fn2)
					})
					return
				}
				if (f.charAt() == '.') return
				if (f.substr(-6) == '\.cache') return
				if (f.substr(-4) == '\.swf') return

				m_fs.copySync(path_nm +f, path_tmp + nm +'/'+ f)
			})

			// パック
			const fn_anbook = path_desktop + nm +'.anbook'
			const zip = m_jszip()
			zip_dig(zip, path_tmp, nm)
			
			zip.generateAsync({type:'nodebuffer'}).then(function (content) {
				m_fs.writeFile(fn_anbook, content, function(err) {
					if (err) throw '例外:'+ err
					m_fs.removeSync(path_tmp)
					notice('デスクトップに '+ nm +'.anbook を保存しました', 'success')
				})
			})
		}
		function zip_full(id) {
			const b = hBook[id], nm = b.fn
			const fn_anbook = path_desktop + nm +'.anbzip'
		//	if (m_fs.existsSync(fn_anbook)) dropDust(fn_anbook)
				// 非同期なので
			
			const zip = m_jszip()
			zip_dig(zip, path_unpack, nm)
			
			zip.generateAsync({type:'nodebuffer'}).then(function (content) {
				m_fs.writeFile(fn_anbook, content, function(err) {
					if (err) throw '例外:'+ err
					notice('デスクトップに '+ nm +'.anbzip を保存しました', 'success')
				})
			})
		}
			function zip_dig(zip, base_dir, fold) {
//addLog('   base_dir='+ base_dir)
//addLog('   fold='+ fold)
				m_fs.readdirSync(base_dir + fold).forEach(function(f) {
					if (f.charAt() == '.') return

					f = m_path.posix.join(fold, f)
					const f2 = m_path.posix.join(base_dir, f)
					if (m_fs.lstatSync(f2).isDirectory()) {
						zip_dig(zip, base_dir, f)
						return
					}
					zip.file(f, m_fs.readFileSync(f2))
				})
			}

		const regUserName = /Users([\\\/]).+?\1/g
		function doNativeProcessAnt(fn, arg) {
			m_fs.unlink(path_app_str +'nobld/term3d.json')
			closeWin()
			addTerm("<span class='inf'>[BEGIN] ant "+ arg +"</span><br/>")

			const path_scr = path_app_nw +'template/script/ant.'
				+ (is_mac ?'sh' :'bat')
			const a = [path_unpack + fn +'/build.xml']
			if (arg) a.push(arg)
			if (is_mac) {
				a.unshift(path_scr)
				ls = m_spawn('sh', a)
			}
			else {
				a[0] = fn
				ls = m_spawn(path_scr, a)
			}
			ls.stdout.on('data', function (data) {
				addTerm(
					(data.toString() +'\n')
					.replace(/ /g, "&nbsp;")
					.replace(/\t/g, "&nbsp;&nbsp;&nbsp;")
					.replace(/([^\n]+):\n/g, "<span class='lbl'>$1:</span><br/>")
					.replace(/\n/g, '<br/>')
					.replace(
						"BUILD&nbsp;SUCCESSFUL"
					,	"<span class='suc'>BUILD SUCCESSFUL</span>"
					)
					.replace(
						"BUILD&nbsp;FAILED"
					,	"<span class='err'>BUILD FAILED</span>"
					)
					.replace(regUserName, "Users/[xxx]/")
				)
			})
			ls.stderr.on('data', function (data) {
				addTerm("<span class='err'>"+ data +"</span><br/>")
			})
			ls.on('close', function (code) {
				addTerm("<span class='inf'>[END] "+ code +"</span><br/>")
				ls = null
			})
		}
		btnProc = function(id, arg, e) {
//	addLog('btnProc id:'+ id +' arg['+ arg +']')
//	addLog(e)
			const b = hBook[id]
			const nm = b.fn
			switch (arg) {
			case '_title':	if (e.which == 3) {setClipboard(path_unpack + b.fn); break}
			case '_path_opn':	openURL('file://'+ path_unpack + b.fn);	break
			case '_path_cpy':	setClipboard(path_unpack + b.fn);	break

			case '_creator':	openURL(b.cre_url);	break
			case '_publisher':	openURL(b.pub_url);	break

			case '_mk_nw':	onMake_app(id);	break
			case '_per':
/*				if (! cmn.fXnHtm.exists && cmn.isHtmlPrj(nm)) {
					notice("ANBooks設定で XNovel形式 環境を準備して下さい", "information")
					ldrHtm.window.popPg_dlg_gear()
					break
				}
*/
				const is_detail = (e.which == 3)
				if (win_term) {
					win_term.webContents.on('close', function() {
						doNoBld(is_detail)
					})
					closeWin()
					break
				}
				doNoBld(is_detail)
				break

			case '_pack':	pack_anbook(id);	break
			case '_pack_full':	zip_full(id);	break

			default:
				if (win_term) {
					win_term.on('closed', function() {
						addLogHead('ビルド実行', b)
						doNativeProcessAnt(b.fn, arg)
					})
					closeWin()
					return
				}

				addLogHead('ビルド実行', b)
				doNativeProcessAnt(b.fn, arg)
			}
			function doNoBld(is_detail) {
				addLogHead('疑似環境実行'+ (is_detail ?'【詳細モード】':''), b)
				cbDrawDetail(id)		// トップ画面右クリック対応
				goNoBld(nm, is_detail)
			}
		}
		
		fileDB = function (id, k, v) {
			if (! xAppxml) return null

			const b = hBook[id], nm = b.fn
			const a_k = k.split('.@'), tag = a_k[0], att = a_k[1]
			const xl = $(xCfg).find(tag).attr(att)
			if (v === undefined) {
				switch (att) {
				case 'font_out':
				case 'code_key':
				case 'cnv_oggo':
					if (! xBld) return xl
					return $(xBld).find('property[name="'+ att +'"]').attr('value')
				case 'upd_an':
					if (! xBld) return xl
					return $(xBld).find('property[name="upd_an_sdk"]').attr('value')
				}
				return xl
//				return 'cfg['+ id +']['+ k +']'
			}

			// 更新
//addLog('set fileDB['+ id +']['+ k +'] (tag='+ tag +', att='+ att +') v='+ v)
			switch (att) {
			case 'upd_an':
				if (! sBld) break

				sBld = sBld.replace(
					new RegExp('name="upd_an_sdk" value=".+"')
				,	'name="upd_an_sdk" value="'+ v +'"')
				m_fs.writeFile(pBld, sBld, {encoding:'utf8'})
				xBld = $.parseXML(sBld)
				break
			case 'font_out':
			case 'cnv_oggo':
				if (! sBld) break

				sBld = sBld.replace(
					new RegExp('name="'+ att +'" value=".+"')
				,	'name="'+ att +'" value="'+ v +'"')
				m_fs.writeFile(pBld, sBld, {encoding:'utf8'})
				xBld = $.parseXML(sBld)
//addLog('font_out nm:'+ nm +' k:'+ k +' att:'+ att +' v:'+ v)
				break
			case 'code_key':
				chg_code_key(nm, v)
				break
			case 'version':
				v = v || '1.0'
			case 'title':
			case 'publisher':
			case 'detail':
				b[att] = v
				replaceAppxml(b)
//addLog('font_out nm:'+ nm +' k:'+ k +' att:'+ att +' v:'+ v)
			//	break
			default:
				// xCfg
//				if (v == '' || v == 'false') $(xCfg).find(tag).removeAttr(att); else $(xCfg).find(tag).attr(att, v)
				const xct = $(xCfg).find(tag)
				if (v == '' || v == 'false') {
					xct.removeAttr(att)
					if (! $(xCfg)[0]) $(xCfg).remove(xct)
				} else {
					if (! xct[0]) xct = $(xCfg).find('search').after($('<init/>'))
						// .removeAttr('xmlns') が効かない、残る
					xct.attr(att, v)
				}
				sCfg = xmls.serializeToString(xCfg)
				m_fs.writeFile(pCfg, sCfg, {encoding:'utf8'})
			}
			switch (att) {
			case 'title':	case 'creator':	case 'cre_url':	case 'publisher':
			case 'pub_url':	case 'detail':	//	case 'icon':
			case 'upd_an':	case 'version':	//	case 'prjtype':
			case 'nocode_reg':	case 'nocode':	case 'pack_exc':
			case 'rotate':
				b[att] = v
				fncFlush()
			}
		}
		chgCodeKey = function (id) {
			const code_key = create_pwd()
			fileDB(id, 'cripter.as.@code_key', code_key)
			return code_key
		}
		prjFoldDB = function (id, path, val) {
//addLog('prjFoldDB:0 id:'+ id +' path:'+ path +' val:'+ val)
			if (path === undefined) path = null
			if (val === undefined) val = null

			cbDrawDetail(id)
			const b = hBook[id], nm = b.fn
//addLog('prjFoldDB:1 xCfg:'+ xCfg +' nm:'+ nm +' path_unpack:'+ path_unpack)
			if (xCfg == null) return []
			path_nm = path_unpack + nm +'/'
			pBld = path_nm +'build.xml'

			var i=0
			if (path == null || val == null) {
				if (! m_fs.existsSync(pBld)) return []

				const aCfg = []
				var s_anc = ''
				const font_out = $(xBld).find('property[name="font_out"]').attr('value')

				a = m_fs.readdirSync(path_nm)
				.sort(function(a,b) {
					a = a.toString().toLowerCase()
					b = b.toString().toLowerCase()
					if(a > b) return 1
					if(a < b) return -1
					return 0
				})
				a.forEach(function(d) {
					const stat = m_fs.statSync(path_nm + d)
//addLog('prjFoldDB stat:'+ stat)
					if (d.charAt() == '.') return
	//				if (stat.isHidden) return
//					if (vD.isHidden) return
					const ext = m_path.extname(path_nm + d).slice(1)
					if (ext == 'cache') return
					if (ext == 'air') return
					if (ext == 'exe') return
					if (ext == 'ipa') return
					if (ext == 'apk') return
					if (ext == 'swf') return
//					if (vD.isPackage) return

					const pe = {
						path	: m_path.basename(path_nm + d)
					,	value	: 'n'
					}
					if ($(xCfg).find('anbook inc[path="'+ pe.path +'"]')
						[0]) {
						pe.value = 'a'
//addLog('anbook inc[path="'+ pe.path +'"]')
					}
					if (stat.isDirectory()) {
						pe.fn = pe.path +'/'
						if ($(xCfg).find('search path[dir="'+ pe.path +'"]')
							[0]) {
							pe.value = 'p'
//addLog('search path[dir="'+ pe.path +'"]')
						}
					}
					else {
						pe.fn = pe.path
						pe.p_enabled = false
					}
					const fnc = hCaedN2F[pe.fn]
					if (fnc != null) {
						fnc(pe)
						if (pe.hide) return
					}

					if (! stat.isDirectory()) {
						aCfg.push(pe)
						return
					}
					switch (d) {
					case 'font':
					case 'icon':
					case 'SDK':
					case 'Work':
					case 'Work_dust':
						aCfg.push(pe)
						return
					}

					s_anc += '\t\t<antcall target="anc2"><param name="dir_n" value="'+ d +'"/></antcall>\n'
					if (! m_fs.existsSync(path_nm + font_out)) font_out = d
					aCfg.push(pe)
				})

				sBld = sBld
				.replace(
					/name="font_out" value=".+"/
				,	'name="font_out" value="'+ font_out +'"'
				)
				.replace(
//					/\t\t<antcall target="anc2">.+?\/target>/s
					new RegExp('\t\t<antcall target="anc2">[\s\S]+?\/target>')
				,	s_anc +'\t</target>'
				)
//addLog('pBld:'+ pBld +' sBld:'+ sBld)
				xBld = $.parseXML(sBld)
				writeTxt(pBld, sBld)
				refreshCfgPath()

				const spD = $(xCfg).find('search path')
				const lenspD = spD.length
				for (i=0; i<lenspD; ++i) {
					const fspDir = path_nm + $(spD[i]).attr('dir') +'/'
					if (m_fs.existsSync(fspDir)) continue

					$(xCfg).find('search path[dir="'+ $(spD[i]).attr('dir') +'"]').remove()
				}
				const aiD = $(xCfg).find('anbook inc')
				const lenaiD = aiD.length
				for (i=0; i<lenaiD; ++i) {
					const faiDir = path_nm + $(aiD[i]).attr('path') +'/'
					if (m_fs.existsSync(faiDir)) continue

					$(xCfg).find('search path[dir="'+ $(spD[i]).attr('path') +'"]').remove()
				}
				sCfg = xmls.serializeToString(xCfg)
				return aCfg
			}

			if (! m_fs.existsSync(pBld)) return null
//addLog('sBld'+ sBld)

			$(xCfg).find('search path[dir="'+ path +'"]').remove()
			$(xCfg).find('anbook inc[path="'+ path +'"]').remove()
			switch (val) {
			case "n":	break
			case "p":	$(xCfg).find('search').append('<path dir="'+ path +'"/>')
						break
			case "a":	$(xCfg).find('anbook').append('<inc path="'+ path +'"/>')
						break
			default:	return null
			}
			sCfg = xmls.serializeToString(xCfg)
			writeTxt(pCfg, sCfg)
			refreshCfgPath()

			return null
		}

		codeFoldDB = function (id, path, val) {
			const b = hBook[id]
			const nm = b.fn
			path_nm = path_unpack + nm +'/'

			if (path == null || val == null) {
				const aCfg = []
				m_fs.readdirSync(path_nm).forEach(function(f) {
					const stat = m_fs.statSync(path_nm + f)
//					if (vD.isHidden) continue;
//					if (vD.isPackage) continue;
					if (! stat.isDirectory()) return

					const oD = {nm:f +'/', code:0}
					switch (f) {
					case 'font':
					case 'icon':
					case 'SDK':
					case 'Work':
					case 'Work_dust':
						oD.ds = 1; break
					default:
						if (m_fs.existsSync(path_nm +'Work/before_anc/'+ f)) oD.code = 1
					}
//addLog('nm:'+ f +' code:'+ oD.code +' ds:'+ oD.ds)
					aCfg.push(oD)
				})
				return aCfg
			}

			// 正フォルダ（内の全ファイル）
//addLog('set codeFoldDB['+ id +']['+ path +'] v='+ val)
			if (! m_fs.existsSync(path_nm + path)) return null
			const stat_w = m_fs.statSync(path_nm + path)
			if (! stat_w.isDirectory()) return null

			// 暗号化前フォルダ
			const fAncDir = path_nm +'Work/before_anc/'+ path
			const exist_AncDir = m_fs.existsSync(fAncDir)
			switch (val) {
			case "n":	// 非暗号化
				if (! exist_AncDir) break

				// 正フォルダの暗号化ファイル「だけ」を捨てる
				m_fs.readdirSync(fAncDir).forEach(function(f) {
					if (f.substr(-1) == '_') dropDust(fAncDir + f)
				})

				// 暗号化前フォルダを正フォルダに上書き移動
				m_fs.readdirSync(fAncDir).forEach(function(f) {
					m_fs.copySync(		//	(is_mac ?'' :'file://')+ 
						fAncDir + f,
						path_nm + path + f)
				})
				dropDust(fAncDir)
				break
			case "a":	// 暗号化
				if (exist_AncDir) break

				// 正フォルダ（暗号化可能な素材のみ）暗号化前に移動
				const regNoAnc = new RegExp(hBook[id].nocode_reg)
				m_fs.readdirSync(path_nm + path).forEach(function(f) {
					if (regNoAnc.test(path + f)) return

					m_fs.move(
						path_nm + path + f,
						fAncDir + f,
						{clobber:true},
						function (err) { if (err) noticeErr(err) })
				})
				break
			}

			return null
		}

		function refreshCfgPath() {
			var s = ' icon'
			var sp = $(xCfg).find('search path')
			var len = sp.length
			var a = []
			for (var i=0; i<len; ++i) a.push($(sp[i]).attr('dir'))
			a.sort()
			for (i=0; i<len; ++i) s += ' '+ a[i]

			replaceTxt(
				pBld
			,	function (str) {sBld = str
				.replace(
					new RegExp('(\{app_name\}\.swf)( .+)?( config\.anprj).*?"', 'g')
				,	'$1$2$3'+ s +'"'
				)
				xBld = $.parseXML(sBld)
				return sBld
			})
		}
		// P -- 実行形式とanbook	a -- anbook
		var	hCaedN2F	= {
			'build.xml'		: function (p) {p.hide = true;}
		,	'cfg.properties': function (p) {p.hide = true;}
		,	'config.anprj'	: function (p) {p.hide = true;}
		,	'font/'			: function (p) {
								p.enabled = false; p.value = 'n';}
		,	'icon/'			: function (p) {
								p.enabled = false; p.value = 'p';}
		,	'icon.jpg'		: function (p) {
								p.enabled = false; p.value = 'a';}
		,	'my_store.p12'	: function (p) {p.hide = true;}
		,	'path.txt'		: function (p) {p.hide = true;}
		,	'prj-app.xml'	: function (p) {p.hide = true;}
		,	'SDK/'			: function (p) {
								p.enabled = false; p.value = 'n';}
		,	'Work/'			: function (p) {
								p.enabled = false; p.value = 'n';}
		,	'Work_dust/'	: function (p) {
								p.enabled = false; p.value = 'n';}
		};

		// URLからダウンロード
		

		// ビルド環境設定
		var xl_flex_sdk = $(xBldp).find('os[family="'+ (is_mac ?'unix':'windows')
			+'"]').parent('condition[property="flex_sdk"]')
		$('#txt_gbld_flex_sdk')
		.val(xl_flex_sdk.attr('value'))
		.on('textchange', function() {
			var t = $(this), v = t.val()
//addLog('       v:'+ v)
			var mes = (function () {
				if (v.indexOf(' ') >= 0) return 'Flex SDKパスは半角空白を含んではいけません'
				v = v
				.replace(/[\\\/]+/g, '/')
				.replace(/[\/\¥]$/, '') +'/'

				if (! m_fs.existsSync(v)) return 'フォルダが見つかりません'
//				if (! m_fs.statSync(v).isDirectory()) return 'ディレクトリではありません'
					// 上でかならず「/」を付けるので処理不要
				try {
					if (! m_fs.existsSync(v +'airnovel_lib/')) {
						m_fs.mkdirSync(v +'airnovel_lib/')
						m_fs.rmdirSync(v +'airnovel_lib/')
					}
				}
				catch (e) {
					return '書き込む権限が無いので、別のフォルダにして下さい'
				}
				return ''
			})()
//addLog('   new v:'+ v +' mes:'+ mes)
			if (mes) $('#lbl_chk_flex_sdk').text(mes).css('color', 'red')
			else {
				$('#lbl_chk_flex_sdk').text('設定完了').css('color', 'blue')
				xl_flex_sdk.attr('value', v)
				sBldp = xmls.serializeToString(xBldp)
				m_fs.writeFile(pBldp, sBldp, {encoding:'utf8'})
			}
		})
	}	// if (is_nw) {	の終わり

	// data-sdb系はシステム共通入力項目
	$('[data-sdb]').each(function () {		// 初期値セット
		var t = $(this); onCtl(t, fileDB_sys(t))
	})
	.on('textchange change', function() {	// 変更反映機構
		var t = $(this), k = t.data('sdb')
/*		if (t.is('[data-role="controlgroup"]')) {
			fileDB_sys(id, k, t.find('input:checked').val())
			return
		}*/
		fileDB_sys(t, t.val())
	})
		function fileDB_sys(t, v) {
			if (! xBldp) return null
			var k = t.data('sdb')

			var xl = null
			switch (k) {
			case 'keystore_i':
			case 'sign_key_i':
			case 'keystore_as':
			case 'sign_key_as':
			case 'appleid':
			case 'appleid_pass':
				xl = $(xBldp).find('property[name="'+ k +'"]')
				att = 'value'
				if (v !== undefined) {
//addLog('k:'+ k +' v:'+ v)
					xl.attr(att, v)
					sBldp = xmls.serializeToString(xBldp)
					m_fs.writeFile(pBldp, sBldp, {encoding:'utf8'})
					return
				}
				break
//			case '':
			default:
				return xl
			}
			if (v === undefined) return xl.attr(att)

//			onCtl(t, v)
			upd()
		}

		// ANBooks設定
		$('#flip-isReplace_AddSameFile').on('change', function() {
			var t = $(this), k = t.data('inp')
			if (k in hSys) {hSys[k] = t.val(); fncFlush()}
		})
		.flipswitch({ create: function( event, ui ) {
			var t=$(this); onCtl(t, hSys[t.data('inp')])
		} })

//console.timeEnd('ready')
})
	function onCtl(t, v) {
		if (t.is('[data-role="controlgroup"]')) {
			t.find('input[value="'+ v +'"]').attr('checked', true).checkboxradio('refresh')
			return
		}

		t.val(v)
		if (t.is('[data-role="flipswitch"]')) {
			t.flipswitch().flipswitch('refresh')
		}
		else t.text(v)
	}


function dlTmp(fn_zip, finish, dl_url) {
	if (m_fs.existsSync(fn_zip)) {
		finish(fn_zip)
		return
	}
	const path_tmp = path_app_str +'template/'
	if (! m_fs.existsSync(path_tmp)) m_fs.mkdirSync(path_tmp)

	var fn = m_path.basename(fn_zip)
	dlgDL(
		fn +' ダウンロード中 0.00 %'
	,	function () {
			dlTmp_close()
			finish = null
			m_fs.unlink(fn_zip)
			notice('ダウンロードをキャンセルしました', 'information')
		}
	)

	if (! dl_url) dl_url = 'https://raw.githubusercontent.com/famibee/AIRNovel/master/ANBooks/template/'+ fn
	const ws = m_fs.createWriteStream(fn_zip)
	ws.on('open', function () {
		m_https.get(dl_url, function (res) {
			res.pipe(ws)

			var bytesTotal = 0, bytesLoaded = 0, cnt_dsp = 0
			res.on('data', function(d) {
				bytesLoaded += d.length
				if (++cnt_dsp % 300 > 0) return

				dlgDL_setText(
					fn +' ダウンロード中 '+ (bytesTotal==0
						? (Math.floor(bytesLoaded /1000) +'KB')
						: (Number(
							(bytesLoaded/bytesTotal)*100
							).toFixed(2) + ' %')
					)
				)
			})
		})
	})
	.on("close", function () {
		dlTmp_close()
		if (finish) finish(fn_zip)
	})
	
	function dlTmp_close() {
		ws.close()
		dlgDL_close()
	}
}

function unZip(fn, path, proc, finish) {
	if (proc === undefined) proc = function (zo, data) {return data}
	if (finish === undefined) finish = function (v) {}

	m_jszip.loadAsync(m_fs.readFileSync(fn)).then(function(zip) {
		var a = []
		zip.forEach(function (relativePath, zo) {
			a.push(zo.async('nodebuffer').then(function (data) {
				const nm = zo.name
				const p_nm = m_path.join(path, nm)
				switch (nm.slice(-1)) {
				case '/':
				case '\\':
					m_fs.mkdirsSync(p_nm)
					return
				}
				data = proc(zo, data)	// zo変更するかも、わざと二行に
				m_fs.mkdirsSync(m_path.dirname(p_nm))
					// zipにフォルダを含まない場合もあるので
				writeTxt(p_nm, data)
			}))
		})
		Promise.all(a).then(finish)

	}, function (e) {
		notice('unZip Error fn='+ m_path.basename(fn), 'error')
		dropDust(fn)
		dropDust(path)
	})
}

function mkp(path) {
	// ｛ファイル名：｛拡張子：パス｝｝形式で格納。
	//		検索が高速なハッシュ形式。
	//		ここでの「ファイル名」と「拡張子」はスクリプト経由なので
	//		URLエンコードされていない物を想定。
	//		パスのみURLエンコード済みの、File.urlと同様の物を。
	//		あとで実際にロード関数に渡すので。
//addLog('nm:'+ nm)
	var ret = '{'

	const xS = $.parseXML(readTxt(path +'config.anprj'))
	const sp = $(xS).find('search path')
	const len = sp.length
	var aFn = []
	for (var i=0; i<len; ++i) {
		const d = $(sp[i]).attr('dir')
		const path_d = path +'/'+ d
		if (! m_fs.existsSync(path_d)) continue
		if (! m_fs.statSync(path_d).isDirectory()) continue

		m_fs.readdirSync(path_d).forEach(function(fn) {
			if (fn.indexOf('.') == -1) return
//addLog(fn)
			aFn.push([fn, d])
		})
	}
	aFn.sort()

	const len_aFn = aFn.length
	for (var j=0; j<len_aFn; ++j) {
		const a = aFn[j]
		const r = m_path.parse(a[0])
		const d = a[1]
		ret += '"'+ r.name +'":{"'+ r.ext.slice(1)
			+'":"'+ (d +'/'+ encodeURIComponent(r.base)) +'"},'
	}

	ret = ret.slice(0, -1) +'}'
//addLog(ret)

	replaceTxt(path +'/path.txt', function (str) { return ret })
}


function addLst(ab) {		// 一部処理が非同期
//addLog('addLst:0 ab:'+ ab)
	if ($.mobile.activePage[0].id == 'index') { addLst_Sub(ab); return }

	$(document).on('pagecontainershow', function (e, ui) {
		$(document).off('pagecontainershow')
//addLog('addLst:1 ab:'+ ab)
		addLst_Sub(ab)
	})
	$.mobile.changePage($('#index'), {reverse :true})
}
function addLst_Sub(ab) {
	hideBtnMenu()

if (ab == undefined) return		// ===========
	var icon = (is_nw ?'file://' :'') + (ab.icon ?path_unpack + ab.fn +'/' :'mat/menu_def_') +'icon.jpg'

	var h_pt = {
		''			: ''
	,	'Plugin'	: '<i class="icn_pt fa fa-puzzle-piece fa-lg"></i>'
	,	'IOS'	: '<i class="icn_pt fa fa-apple fa-lg"></i>'
	,	'AND'	: '<i class="icn_pt fa fa-android fa-lg"></i>'
	}
	var htm_pt = h_pt[ab.prjtype], $id = '#'+ ab.id, is_rep = $($id).length
	books.prepend('<li id="'+ ab.id +'" class="mix can_edit pt_'+ (ab.prjtype || '') +'" data-id="'+ ab.id +'" data-title="'+ ab.title +'" data-creator="'+ ab.creator +'" data-my="'+ ++cntBook +'" title=""><div style="background-image:url(\''+ icon +'\'); -webkit-animation-delay: -'+ (Math.floor(Math.random () * 100)*0.01) +'s;"></div><h3>'+ ab.title +'</h3><p>【'+ ab.creator +'】'+ ab.detail +'</p><p class="ui-li-aside">'+ ab.fn +'</p><a class="btndel" data-icon="delete" data-role="button" data-mini="true" data-inline="true" data-iconpos="notext"></a>'+ htm_pt +'</li>').trigger('create')
//	books.listview().listview('refresh')	これだと削除ボタンが崩れる
	$($id).mousedown(function(e) {
		if (nav_ft.css('display') != 'none') return
		if (books.hasClass('mode_edit')) return

		if (e.which == 3) {	// 右クリック
			if (ab.prjtype) btnProc(ab.id, ''); else btnProc(ab.id, '_per', e)
		}
		else {
			$.mobile.pageContainer.pagecontainer('change', '#pg_'+ ab.id)
			cbDrawDetail(ab.id)
			if (! (ab.id in hBookDetail)) drawDetail(ab.id)
		}
	}).find('.btndel').click(function() {
		alertYN('プロジェクト「'+ ab.title +'」を削除しますか？（ゴミ箱に捨てます）'
		, function (nt){
			delLst(ab)
			nt.close()
		})
	})
	tooltip($id)
	
	// 重複チェックしつつ追加
//addLog('addLst_Sub(ab) 0:'+ hSys.sMySort)
	if (! hSys.sMySort) {
		hSys.sMySort = ab.id
	}
	else if ((hSys.sMySort +',').search(new RegExp(ab.id +',')) <0) {
		hSys.sMySort = ab.id +','+ hSys.sMySort
	}
	fncFlush()
//addLog('addLst_Sub(ab) 1:'+ hSys.sMySort)

	addDetail(ab, icon)
	if (books.mixItUp('isLoaded')) {
		books.mixItUp('prepend', ab.id)
		notice(ab.fn +'を書庫に'+ (is_rep ?'上書き' :'追加')+'しました', 'success')
	}
}
function addDetail(ab, icon) {
	var id = ab.id
	tmp = '\
<div data-role="page" id="pg_'+ id +'" class="book_d">\
	<div data-role="header" data-position="fixed" data-tap-toggle="false" data-theme="b">\
		<a data-icon="arrow-l" data-rel="back">書庫</a>\
		<h1 data-dsp="title"></h1>\
		<a id="pg_'+ id +'_ed" data-icon="edit">編集</a>\
	</div>\
<div data-role="content">\
<div data-role="collapsible-set">'

+	'<div data-role="collapsible" data-collapsed="false">\
	<h3>プロジェクト情報 -- '+ ab.fn +'</h3>\
	<ul id="books_d'+ id +'" data-role="listview" data-inset="true">\
		<li data-icon="bars"><a data-arg="_title"'+
		(is_nw ?' class="nw_title"' :'')
		+'><img id="pg_'+ id +'_icon" src="'+ icon +'"/><h3 data-dsp="title"></h3></a></li>\
		<li data-role="list-divider" class="tgl" style="display:none">プロジェクト情報</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_title">タイトル</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_anbook_title" value="" placeholder="タイトル名" data-inp="title" data-fdb="anbook.@title"/>\
		</li>\
\
		<li class="tgl">著作者<span class="ui-li-aside'+ (ab.cre_url ? ' books_dlst_link' : '')
			+'" data-arg="_creator" data-dsp="creator"></span>'
			+	((ab.cre_url && String(ab.cre_url).indexOf('//twitter.com/') >= 0)
				? '<span class="ui-li-count"><img src="mat/icon_twitter.png"/></span>' : '')
	+	'</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_creator">著作者</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_anbook_creator" value="" placeholder="ペンネーム、ハンドルネームなど" data-inp="creator" data-fdb="anbook.@creator"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_cre_url">著作者URL</label>\
			<input type="url" data-mini="true" data-clear-btn="false" id="txt_gear'+ id +'_anbook_cre_url" value="" placeholder="連絡先URL。Twitterなど" data-inp="cre_url" data-fdb="anbook.@cre_url"/>\
		</li>\
\
		<li class="tgl">出版者<span class="ui-li-aside'+ (ab.pub_url ? ' books_dlst_link' : '')
			+'" data-arg="_publisher" data-dsp="publisher"></span>'
			+	((ab.pub_url && String(ab.pub_url).indexOf('//twitter.com/') >= 0)
				? '<span class="ui-li-count"><img src="mat/icon_twitter.png"/></span>' : '')
	+	'</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_publisher">出版者</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_anbook_publisher" value="" placeholder="サークル名、団体名など" data-inp="publisher" data-fdb="anbook.@publisher"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_pub_url">出版者URL</label>\
			<input type="url" data-mini="true" id="txt_gear'+ id +'_anbook_pub_url" value="" placeholder="連絡先URL。Twitterなど" data-clear-btn="false" data-inp="pub_url" data-fdb="anbook.@pub_url"/>\
		</li>\
\
		<li class="tgl"><h3>内容</h3><p style="white-space: normal" data-dsp="detail"></p></li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_detail">内容</label>\
			<textarea cols="40" rows="8" data-mini="true" id="txt_gear'+ id +'_anbook_detail" placeholder="プロジェクトの説明" data-inp="detail" data-fdb="anbook.@detail"></textarea>\
		</li>\
\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_anbook_version">バージョン</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_version" value="" placeholder="小数でも可" data-inp="version" data-fdb="anbook.@version"/>\
		</li>\
\
		<li data-role="list-divider" class="tgl" style="display:none">ゲームの初期状態</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<p style="font-size:medium">最初に呼び出すスクリプト</p>\
			<label for="txt_gear'+ id +'_first_script_fn"></label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_first_script_fn" value="" placeholder="anスクリプトファイル名。拡張子省略推奨" data-fdb="first_script.@fn"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_init_bg_color">背景色</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_init_bg_color" value="" placeholder="省略時は 0x000000（黒）" data-fdb="init.@bg_color"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<p style="font-size:medium">通常文字表示待ち時間 (ms)</p>\
			<label for="txt_gear'+ id +'_init_tagch_msecwait"></label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_init_tagch_msecwait" value="" placeholder="インストール直後の初期値。未読／既読兼用" data-fdb="init.@tagch_msecwait"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<p style="font-size:medium">自動文字表示での行クリック待ち時間 (ms)</p>\
			<label for="txt_gear'+ id +'_init_auto_msecpagewait"></label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_init_auto_msecpagewait" value="" placeholder="インストール直後の初期値。未読／既読兼用" data-fdb="init.@auto_msecpagewait"/>\
		</li>\
\
		<li data-role="list-divider" class="tgl" style="display:none">アプリウインドウ設定</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_window_width">横幅 (px)</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_window_width" value="" placeholder="1〜、アプリウインドウの横幅を指定" data-fdb="window.@width"/>\
		</li>\
		<li data-role="fieldcontain" class="tgl" style="display:none">\
			<label for="txt_gear'+ id +'_window_height">高さ (px)</label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_window_height" value="" placeholder="1〜、アプリウインドウの高さを指定" data-fdb="window.@height"/>\
		</li>\
\
		<li data-role="list-divider" class="tgl" style="display:none">プロジェクトの実行</li>\
		<li data-icon="action">'
			+ (ab.prjtype
				? 'ビルドかコマンドライン実行のみ可能です'
				: '<a data-arg="_per">最初から読む（疑似環境実行・右ｸﾘｯｸで詳細ﾓｰﾄﾞ)</a>')
		+ '</li>'

	switch (ab.prjtype) {
	case 'IOS':
		tmp += '\
		<li data-icon="action" data-theme="b"><a data-arg="">【ant do_i】iOS版をビルド＆実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_i4">【ant do_i4】iOS版（iPhone4 Retina環境）実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_i5">【ant do_i5】iOS版（iPhone5 Retina環境）実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_i6">【ant do_i6】iOS版（iPhone6環境）実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_i6p">【ant do_i6p】iOS版（iPhone6 Plus環境）実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_ip">【ant do_ip】iOS版（iPad環境）実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_ip3">【ant do_ip3】iOS版（iPad3 Retina環境）実行</a></li>'
		break;
	case 'AND':
		tmp += '\
		<li data-icon="action" data-theme="b"><a data-arg="">【ant do_a_no】NexusOne 480 x 800 実行</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="do_a_sgt">【ant do_a_sgt】GalaxyTab 600 x 1024 実行</a></li>'
		break;
	default:
		tmp += '\
	</ul>\
\
	<ul data-role="listview" data-inset="true">\
		<li data-icon="action" data-theme="b"><a data-arg="">【ant】ターミナルでビルド＆実行</a></li>\
		<li data-icon="shop"><a data-arg="_mk_nw">OS個別・簡易アプリ生成（exe、app)</a></li>'
	}

	tmp += '\
		</li>\
	</ul>\
</div>'


	tmp += '\
<div data-role="collapsible">\
	<h3>プロジェクトフォルダ設定</h3>\
	<ul id="books_sp'+ id +'" data-role="listview" data-inset="true">\
		<li data-role="list-divider">ファイル・フォルダをパッケージに含むか</li>\
\
		<li data-role="fieldcontain">\
		<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
			<legend>build.xml</legend>\
			<input type="radio" name="books_sp999_f0" id="books_sp999_f0n" value="n" checked="checked"/>\
			<label for="books_sp999_f0n">無視</label>\
			<input type="radio" name="books_sp999_f0" id="books_sp999_f0p" value="p"/>\
			<label for="books_sp999_f0p">含める</label>\
			<input type="radio" name="books_sp999_f0" id="books_sp999_f0a" value="a"/>\
			<label for="books_sp999_f0a">anbookだけ</label>\
		</fieldset>\
		</li>\
	</ul>\
</div>'


	switch (ab.prjtype) {
	case 'IOS':	break;
	default:
		tmp += '\
	<div data-role="collapsible">\
	<h3>素材暗号化</h3>\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
			<label for="txt_ba'+ id +'_code_key">暗号化キー</label>\
			<input type="text" data-mini="true" id="txt_ba'+ id +'_code_key" value="" disabled="disabled" data-fdb="build.xml.@code_key"/>\
		</li>\
\
		<li id="btn_ba'+ id +'_code_key" data-icon="refresh"><a>暗号化キーを自動生成</a></li>\
	</ul>\
		<small>※暗号化キーを変更すると、次のビルド時に全暗号化ファイルを再暗号化します。ファイル数が多いと処理に時間が掛かります。</small><br/>\
\
		<br/>\
		<label for="txt_ba'+ id +'_nocode_reg">暗号化対象外ファイル名パターン</label>\
		<input type="text" data-mini="true" id="txt_ba'+ id +'_nocode_reg" value="" placeholder="暗号化しないファイル名にマッチする正規表現" data-inp="nocode_reg" data-fdb="anbook.@nocode_reg"/>\
		<small>※暗号化処理時は、元素材をWork/before_anc下へ移動します</small>\
\
		<ul id="books_ba'+ id +'" data-role="listview" data-inset="true">\
			<li data-role="list-divider">フォルダ単位の暗号化</li>\
			<li data-role="fieldcontain">\
			<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
				<legend>mat/</legend>\
				<input type="radio" name="books_anc999_a0" id="books_anc999_a0n" value="n" checked="checked"/>\
				<label for="books_anc999_a0n">しない</label>\
				<input type="radio" name="books_anc999_a0" id="books_anc999_a0a" value="a"/>\
				<label for="books_anc999_a0a">する</label>\
			</fieldset>\
			</li>\
		</ul>\
	</div>'
	}


	tmp += '\
<div data-role="collapsible">\
	<h3>実行形式パッケージ（*.air、ipa、apkなど）生成</h3>\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
		<fieldset data-role="controlgroup" data-mini="true" id="books_ba'+ id +'_font_out" data-fdb="build.xml.@font_out">\
			<legend>swf出力先</legend>\
			<input type="radio" name="books_ba'+ id +'_fo" id="books_ba'+ id +'_fo_mat" value="mat"/>\
			<label for="books_ba'+ id +'_fo_mat">mat</label>\
			<input type="radio" name="books_ba'+ id +'_fo" id="books_ba'+ id +'_fo_system" value="system"/>\
			<label for="books_ba'+ id +'_fo_system">system</label>\
		</fieldset>\
		</li>\
\
		<li data-icon="refresh"><a data-arg="font">【ant font】フォントswfビルド（最低限の文字で）</a></li>\
		<li data-icon="refresh"><a data-arg="font_all">【ant font_all】フォントswfビルド（全文字を含む）</a></li>\
	</ul>\
\
\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
			<p style="font-size:medium">oggファイルをoggo変換するか</p>\
			<select data-mini="true" data-role="flipswitch" data-fdb="build.xml.@cnv_oggo">\
				<option value="false">しない</option>\
				<option value="true">する</option>\
			</select>\
		</li>\
	</ul>\
\
\
	<ul data-role="listview" data-inset="true">'
	switch (ab.prjtype) {
	case 'IOS':
		tmp += '\
		<li data-icon="shop"><a data-arg="ipi">【ant ipi】実機テスト用高速ビルド（*-ipi.ipa)</a></li>\
		<li data-icon="shop" data-theme="b"><a data-arg="ip">【ant ip】実機テスト用ビルド（*-ip.ipa)</a></li>\
		<li data-icon="shop" data-theme="b"><a data-arg="ip_appstore">【ant ip_appstore】AppStore配布用ビルド</a></li>'
		if (navigator.platform.indexOf('Mac') >= 0) tmp += '\
		<li data-icon="info"><a data-arg="ip_itc_chk">配布用アプリを iTunes Connect で検査（Xcode必須）</a></li>\
		<li data-icon="info"><a data-arg="ip_itc_upl">配布用アプリを iTunes Connect に送信（Xcode必須）</a></li>'
		break;
	case 'AND':
		tmp += '\
		<li data-icon="shop" data-theme="a"><a data-arg="apk">【ant apk】apkパッケージビルド（apk)</a></li>\
		<li data-icon="action" data-theme="b"><a data-arg="ir">【ant ir】ビルド＆実機にインストール</a></li>'
		break;
	default:
		tmp += '\
		<li data-icon="shop"><a data-arg="local">【ant local】ブラウザ向けビルド</a></li>\
		<li data-icon="shop" data-theme="b"><a data-arg="air">【ant air】Adobe AIRパッケージ（air)</a></li>\
		<li data-icon="shop"><a data-arg="air_r">【ant air_r】OS個別インストーラー（exe、dmg)</a></li>'
	}

	tmp += '\
	</ul>\
</div>'


+	'<div data-role="collapsible">\
	<h3>anbookパッケージ（*.anbook）</h3>\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
			<label for="tgl_gear'+ id +'_anbook_nocode">暗号化</label>\
			<select data-mini="true" id="tgl_gear'+ id +'_anbook_nocode" data-role="flipswitch" data-inp="nocode" data-fdb="anbook.@nocode">\
				<option value="">する</option>\
				<option value="true">しない</option>\
			</select>\
		</li>\
		<li data-role="fieldcontain">\
			<p style="font-size:medium">パックに含めないファイル名パターン (<a onclick="openURL(\'http://help.adobe.com/ja_JP/as3/dev/WS5b3ccc516d4fbf351e63e3d118a9b90204-7ea9.html\')">正規表現</a>)</p>\
			<label for="txt_gear'+ id +'_anbook_pack_exc"></label>\
			<input type="text" data-mini="true" id="txt_gear'+ id +'_anbook_pack_exc" value="" placeholder="ファイル・フォルダ名の正規表現" data-inp="pack_exc" data-fdb="anbook.@pack_exc"/>\
		</li>\
		<li data-role="fieldcontain">\
			<label for="tgl_gear'+ id +'_anbook_rotate">画面回転</label>\
			<select data-mini="true" id="tgl_gear'+ id +'_anbook_rotate" data-role="flipswitch" data-inp="rotate" data-fdb="anbook.@rotate">\
				<option value="">なし</option>\
				<option value="true">する</option>\
			</select>\
		</li>\
		<li data-icon="grid" data-theme="b"><a data-arg="_pack">anbook形式にパック（配布用）</a></li>\
		<li data-icon="heart"><a data-arg="_pack_full">anbzip形式に丸ごとバックアップ</a></li>'
		+ (ab.dl_url ?('<li data-icon="alert"><a data-arg="_re_dl">作品アップデート<span class="ui-li-aside"></span></a></li>') : '') +'\
	</ul>\
</div>'


+	'<div data-role="collapsible" id="bld'+ id +'">\
	<h3>拡張ビルド</h3>\
	<ul data-role="listview" data-inset="true" data-theme="b">\
		<li data-icon="info"><a data-arg="chk_env">開発環境情報の表示</a></li>\
	</ul>\
\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
			<p style="font-size:medium">ターゲット名を指定してant実行</p>\
			<input id="inp_'+ id +'_free" type="text" value="" placeholder="ターゲット名（例：h …ターゲット一覧）"/>\
		</li>\
		<li data-icon="alert"><a id="bld_'+ id +'_free" data-arg="">上記のantを実行</a></li>\
	</ul>\
\
	<ul data-role="listview" data-inset="true">\
		<li data-role="fieldcontain">\
			<p style="font-size:medium">ビルド時にAIRNovelソースを最新に自動更新</p>\
			<select data-mini="true" data-role="flipswitch" data-fdb="build.xml.@upd_an">\
				<option value="false">しない</option>\
				<option value="true">する</option>\
			</select>\
		</li>\
		<li data-icon="gear" data-theme="b"><a data-arg="upd_an">プロジェクトのAIRNovelソース更新</a></li>\
		<li data-icon="gear" data-theme="b"><a data-arg="AIRlib_dl_sub">共通のAIRNovelライブラリを更新</a></li>\
		<li data-icon="alert"><a data-arg="flexsdk">Apache Flexを最新Verへ更新</a></li>\
		<li data-icon="alert"><a data-arg="airsdk">Adobe AIR SDKを最新Verへ更新</a></li>\
	</ul>\
</div>'

+	'<div data-role="collapsible">\
	<h3>ツール</h3>\
	<ul data-role="listview" data-inset="true" data-theme="a">\
		<li data-icon="info"><a data-arg="_path_opn">フォルダをエクスプローラーやFinderで開く</a></li>\
		<li data-icon="info"><a data-arg="_path_cpy">フォルダ絶対パスをクリップボードへ</a></li>\
	</ul>\
		</div>\
\
	</div>'

+	'</div>'
+	'</div>';
	$('body').append(tmp)

	$('#pg_'+ id +'_ed').click(function() {
		$('#books_d'+ id +' >li.tgl').slideToggle()
		drawDetail(id)
	})

	var pg = $('#pg_'+ id)
	pg.find('[data-arg]').mousedown(function(e) { btnProc(id, $(this).data('arg'), e) })
	// data-inp系は表示更新か？
	pg.find('[data-inp]').on('textchange', function() {
		if (lockChgEvent(id)) return

//addLog('on [data-inp]')
		var t = $(this)
		redrawDetail(id, ab, t.data('inp'), t.val())
		unlockChgEvent(id)
	})
	// data-fdb系は変更反映だっけ
	pg.find('[data-fdb]').on('textchange change', function() {
		var t = $(this), k = t.data('fdb')
//addLog('on [data-fdb] t:'+ t +' k:'+ k)
		if (! k) return
		if (lockChgEvent(id)) return

		var v = t.is('[data-role="controlgroup"]')
			? t.find('input:checked').val()
			: t.val()
//addLog('on [data-fdb] 2: v:'+ v)
		fileDB(id, k, v)
		unlockChgEvent(id)
	})
	// ウィジット生成
	$('[data-role="flipswitch"]').flipswitch()

	pg.find('#inp_'+ id +'_free').on('textchange', function() {
		$('#bld_'+ id +'_free').data('arg', $(this).val())
	})

	$('#btn_ba'+ id +'_code_key').click(function() {
		alertYN('暗号化キーを再生成しますか？（後のビルド時、全ての素材暗号化をやり直します）', function (nt){
			$('#txt_ba'+ id +'_code_key').val( chgCodeKey(id) )
			$.each(codeFoldDB(id), function(i, o){
				if (! o.code) return
//addLog('i:'+ i +' nm:'+ o.nm +' code:'+ o.code)
				codeFoldDB(id, o.nm, 'n')
				codeFoldDB(id, o.nm, 'a')
			})
			nt.close()
		})
	})

	if (is_nw) pg.find('input, textarea').on('contextmenu', function(e) {
		e.preventDefault()
		c_menu.popup(e.originalEvent.x, e.originalEvent.y)
	})
}
function delLst(ab) {
	$('#'+ ab.id).remove()
	dropDust(ab.fn)
	delete hBook[ab.id]
	fncFlush()
}
function dropDust(fn) {dropDustProc((is_mac ?'' :'file://') + fn)}
function dropDustProc(fn) {addLog('dropDust()='+ fn)}
function unlockChgEvent(id) {}
function lockChgEvent(id) {}

function redrawDetail(id, ab, k, v) {
//addLog('redrawDetail id:'+ id +'  k:'+ k +'  v:'+ v +' kk:'+ $(xCfg).find('anbook').attr(k))
//if (id == 'lst_99') $('#scIncS').before('[js] redrawDetail id:'+ id +'  k:'+ k +'  v:'+ v +':')	// 苦肉のログ
	var pg = $('#pg_'+ id)
	switch (k) {
	case 'title':
		if (v === undefined) v = $(xCfg).find('anbook').attr(k)
		$('#'+ id).attr('data-title', v).children('h3').text(v)
		$('#txt_gear'+ id +'_anbook_title').val(v)
		break
	case 'version':
		if (v === undefined) v = $(xAppxml).find('versionNumber').text() || '1.0'
		$('#txt_gear'+ id +'_'+ k).val(v)
		break	// .text(v)だとイベント発生してしまうので.val(v)
	case 'fn':
		if (v === undefined) v = $(xCfg).find('first_script').attr(k)
		$('#txt_gear'+ id +'_first_script_'+ k).val(v)
		break	// .text(v)だとイベント発生してしまうので.val(v)
	case 'bg_color':
	case 'tagch_msecwait':
	case 'auto_msecpagewait':
//addLog('redrawDetail k:'+ k +' v:'+ v)
		if (v === undefined) v = $(xCfg).find('init').attr(k)
		$('#txt_gear'+ id +'_init_'+ k).val(v)
		break	// .text(v)だとイベント発生してしまうので.val(v)
	case 'width':
	case 'height':
		if (v === undefined) v = $(xCfg).find('window').attr(k)
		$('#txt_gear'+ id +'_window_'+ k).val(v)
		break	// .text(v)だとイベント発生してしまうので.val(v)
	case 'upd_an':
	case 'font_out':
	case 'cnv_oggo':
		if (v === undefined) v = fileDB(id, 'build.xml.@'+ k)
		onCtl(pg.find('[data-fdb="build.xml.@'+ k +'"]'), v)
		break	// .text(v)だとイベント発生してしまうので.val(v)
	case 'creator':
	case 'detail':
		$('#'+ id).attr('data-creator', ab.creator).attr('data-detail', ab.detail).children('p:first').text('【'+ ab.creator +'】'+ ab.detail)
	//	break
	default:
		if (v === undefined) v = $(xCfg).find('anbook').attr(k)
		$('#txt_gear'+ id +'_anbook_'+ k).val(v)
			// .text(v)だとイベント発生してしまうので.val(v)
	}

	pg.find('[data-dsp="'+ k +'"]').val(v).text(v)
	if ((k in ab) && (k != 'fn')) {ab[k] = v; fncFlush()}
}


var hBookDetail = {}
function cbDrawDetail() {addLog('cbDrawDetail')}
function drawDetail(id) {
//addLog('drawDetail:')
	if (no_chain_chg_event) return
	no_chain_chg_event = true

	replaceIcon(id)
	hBookDetail[id] = 1

	var b = hBook[id]
	// data-inp系は表示更新か？
	$('#pg_'+ id +' [data-inp]').each(function () { var t=$(this); onCtl(t, b[t.data('inp')]) 
//addLog('[data-inp] t:'+ t.attr('id') +' k:'+ t.data('inp'))
})
	// data-dsp系は表示用だった気が
	$('#pg_'+ id +' [data-dsp]').each(function () { var t=$(this); onCtl(t, b[t.data('dsp')]) 
//addLog('[data-dsp] t:'+ t.attr('id') +' k:'+ t.data('dsp'))
})
	// data-fdb系は変更反映だっけ
	$('#pg_'+ id +' [data-fdb]').not('[data-inp]').each(function() {
//		var t=$(this); onCtl(t, fileDB(id, t.data('fdb')))
		var t=$(this)
//addLog('[data-fdb] t:'+ t.attr('id') +' k:'+ t.data('fdb') +' v:'+ fileDB(id, t.data('fdb')))
//		var a= fileDB(id, t.data('fdb'))
		onCtl(t, fileDB(id, t.data('fdb')))

//addLog('[data-fdb] t:'+ t.attr('id') +' k:'+ t.data('fdb'))
	})

	var sp = '<li data-role="list-divider" class="ui-first-child ui-li-static ui-body-inherit ui-field-contain">ファイル・フォルダをパッケージに含むか</li>'
	$.each(prjFoldDB(id), function(i, o){
		var n = 'books_sp'+ id +'_'+ i
		sp += '\
<li data-role="fieldcontain" class="ui-li-static ui-body-inherit">\
<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
	<legend>'+ o.fn +'</legend>\
	<input type="radio" name="'+ n +'" id="'+ n +'n" value="n"'+ (o.value=='n' ?' checked="checked"' :'') + (o.n_enabled!=false && o.enabled!=false ?'' :' disabled="disabled"') +' data-fld="'+ o.path +'"/><label for="'+ n +'n">無視</label>\
	<input type="radio" name="'+ n +'" id="'+ n +'p" value="p"'+ (o.value=='p' ?' checked="checked"' :'') + (o.p_enabled!=false && o.enabled!=false ?'' :' disabled="disabled"') +' data-fld="'+ o.path +'"/><label for="'+ n +'p">含める</label>\
	<input type="radio" name="'+ n +'" id="'+ n +'a" value="a"'+ (o.value=='a' ?' checked="checked"' :'') + (o.a_enabled!=false && o.enabled!=false ?'' :' disabled="disabled"') +' data-fld="'+ o.path +'"/><label for="'+ n +'a">anbookだけ</label>\
</fieldset>\
</li>'
	})
	$('#books_sp'+ id).html(sp).trigger('create')
	.find('input').change(function(e) { var t = $(this); prjFoldDB(id, t.data('fld'), t.val()) })
	$('#books_sp'+ id +' >li:last').addClass('ui-last-child')

	var ba = '<li data-role="list-divider" class="ui-first-child ui-li-static ui-body-inherit ui-field-contain">フォルダ単位の暗号化</li>'
	$.each(codeFoldDB(id), function(i, o){
//addLog('i:'+ i)
		var n = 'books_ba'+ id +'_'+ i, ds = (o.ds ?' disabled="disabled"' :'')
		ba +=
			'<li data-role="fieldcontain" class="ui-li-static ui-body-inherit">\
			<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
				<legend>'+ o.nm +'</legend>\
				<input type="radio" name="'+ n +'" id="'+ n +'n" value="n"'+ (o.code ?'' :' checked="checked"') + ds +' data-fld="'+ o.nm +'"/>\
				<label for="'+ n +'n">しない</label>\
				<input type="radio" name="'+ n +'" id="'+ n +'a" value="a"'+ (o.code ?' checked="checked"' :'') + ds +' data-fld="'+ o.nm +'"/>\
				<label for="'+ n +'a">する</label>\
			</fieldset>\
			</li>'
	})
	$('#books_ba'+ id).html(ba).trigger('create')
	.find('input').change(function(e) { var t = $(this); codeFoldDB(id, t.data('fld'), t.val()) })
	$('#books_ba'+ id +' >li:last').addClass('ui-last-child')

	no_chain_chg_event = false
}



// == tst start =================
var tst_id=10000	// === DEBUG ===
function addTst() {	// === DEBUG ===
	var id = tst_id++, a_pt = ['', 'Plugin', 'IOS', 'AND']
	addLst(hBook['lst_'+ id] = {		// 一部処理が非同期
		id : 'lst_'+ id
	,	fn : '140821lst_'+ id +'_fn'
	,	title : 'タイトル'+ Math.random() +'ifugmsigisigis'
	,	creator : 'クリエイター'+ (Math.floor(Math.random () * 100) + 100)
	,	cre_url : 'https://twitter.com/'
	,	publisher : 'パブリッシャー'
	,	pub_url : 'http://famibee.blog38.fc2.com/'
	,	detail : '詳細説明文面０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９'
	,	version : '1.0'
	,	prjtype : a_pt[tst_id % 4]
	,	nocode_reg : 'system/.+.(mp3|swf|xml)'
	,	nocode	: true
	,	pack_exc: '(aaa|bbb)'
	,	rotate	: false
	,	upd_an	: true
	})
}
// == tst end ===================



function create_pwd(len, pwd_tbl) {
	if (len === undefined) len = 256
	if (pwd_tbl === undefined) pwd_tbl = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#%()*+-./:;=?@[]_`{}~'		// &<\^| はダメ

	var ret = '', cl = pwd_tbl.length
	for (var i=0; i<len; ++i) {
		ret += pwd_tbl[Math.floor(Math.random() *cl)]
	}

	return ret
}

function chg_code_key(nm, code_key) {
	path_nm === path_unpack + nm +'/'
	pBld = path_nm +'build.xml'

	// cripter.as
	replaceTxt(
		path_nm +'SDK/an_sdk/com/fc2/blog38/famibee/AIRNovel/cripter.as'
	,	function (str) {return str
		.replace(
			/_o:CriptRC4	= new CriptRC4\(".+"\);/
		,	'_o:CriptRC4	= new CriptRC4("AAA");'
		)
		.replace(
			'_o:CriptRC4	= new CriptRC4("AAA");'
		,	'_o:CriptRC4	= new CriptRC4("'+ code_key +'");'
		)
	})

	// build.xml
	replaceTxt(
		pBld
	,	function (str) {
			sBld = str
			.replace(
				/name="code_key" value=".+"/
			,	'name="code_key" value="AAA"'
			)
			.replace(
				'name="code_key" value="AAA"'
			,	'name="code_key" value="'+ code_key +'"'
			)
			xBld = $.parseXML(sBld)
			return sBld
	})
}


function clearTxtCache(path) {
	const h = {}, url_up = new RegExp('^'+ path)
	for (k in hTxtCache) {
		if (k.match(url_up)) continue
		h[k] = hTxtCache[k]
	}
	hTxtCache = h
}
function readTxt(url, cache, chkCollision) {
	if (cache === undefined) cache = true
	if (cache) {
		const o = hTxtCache[url]
		if (o) return o.txt
	}
	else delete hTxtCache[url]

	if (! m_fs.existsSync(url)) {
		addLog('存在しないパス['+ url +']です')
		return ''
	}
	const stat = m_fs.statSync(url)
	if (stat.isDirectory()) {
		addLog('['+ url +']はフォルダです')
		return
	}

	var ret = ""
	try {
		ret = m_fs.readFileSync(url, 'utf8')
		if (chkCollision === undefined) chkCollision = false
		hTxtCache[url] = {
			md			:stat.mtime
		,	txt			:ret
		,	chkCollision:chkCollision
		}
	}
	catch (e) {
		throw "例外:"+ e.text +"("+ e.errorID +")"
	}

	return ret
}
function writeTxt(url, txt) {
	try {
//addLog('writeTxt '+ url)
		const o = hTxtCache[url]

		var mtime = null
		if (m_fs.existsSync(url)) {
			mtime = m_fs.statSync(url).mtime
			if (o) {
				if (o.chkCollision && mtime != o.md) return true
				if (txt == o.txt) return false
			}
		}

		m_fs.writeFileSync(url, txt, {encoding:'utf8'})
		if (! mtime) mtime = m_fs.statSync(url).mtime

		const h = {
			md			:mtime
		,	txt			:txt
		,	chkCollision:(o) ?o.chkCollision :false
		}
		hTxtCache[url] = h
	}
	catch (e) {
		throw "例外:"+ e.text +"("+ e.errorID +")"
	}

	return false
}
function replaceTxt(url, fnc, cache, chkCollision) {
	if (cache === undefined) cache = true

	const txtOrg = m_fs.existsSync(url)
		? readTxt(url, cache, chkCollision)
		: ''
	var txtPrc = fnc(txtOrg)
	if (txtOrg == txtPrc) return true
	return writeTxt(url, txtPrc)
}



const key_sc = '654kruXDhVHEkcr1mA9DbZNS2E1J6wovd4ZcWSXfXATcwN75t8Z72xB3SnCua7dORFmWbFuwfpOfQ8L3Es67ErU0i4SzGzwo5orpIzzvBG9YbVuhZB1VBXODWI36pEIyJCRQUTxJZFxAgkhERUMCTkBRl3XzUodzVewPAYIpQqjgyKTdIruut3lTRhkde0Y7O6lCmaMNDbwnaUVSmJNWtYiZp0QP3RpimEhTgMZ0LYcg55NLBgUuQceC3AsPY3d4'

const sday = ["日","月","火","水","木","金","土"]
function getDateStr() {
	var dt = new Date()
	return dt.toFormat('YYYY/MM/DD('+ sday[dt.getDay()] +') HH24MI')
}

function loadFDB(id) {addLog('loadFDB('+ id +')')}

function prjFoldDB(id, k, v) {
	if (k === undefined) return [
	{fn:'aaa/', value:'a'}
	, {fn:'bbbbb', value:'p', n_enabled:false}
	, {fn:'cc/', value:'n', n_enabled:true, p_enabled:false, a_enabled:false}
	, {fn:'dddd', value:'p', n_enabled:false, p_enabled:false, a_enabled:false}
	, {fn:'eeeeee/', value:'a', enabled:false}
	]
	addLog('set prjFoldDB['+ id +']['+ k +'] v='+ v)
}
function codeFoldDB(id, k, v) {
	if (k === undefined) return [{nm:'aaa/'}, {nm:'bbbbb/', code:1}, {nm:'cc/'}, {nm:'dddd/', ds:1}]
	addLog('set codeFoldDB['+ id +']['+ k +'] v='+ v)
}
function chgCodeKey(id) {return 'chgCodeKey='+ id}
function fileDB(id, k, v) {
	if (v === undefined) return 'cfg['+ id +']['+ k +']'
}
function replaceIcon(id) {
	var img = $('#'+ id +' >div:first')
	var fn = img.css('background-image').replace(/\.jpg(\?\d+)?/, '.jpg?'+ (new Date().getTime()))
	img.css('background-image', fn)
	$('#pg_'+ id +'_icon').attr('src', replaceIcon_sub(fn))
}
function replaceIcon_sub(fn) {return fn.slice(4, -1)}
function btnProc(id, arg, e) {notice('id:'+ id +' arg:'+ arg +' e:'+ e, 'information')}
function tooltip($id) {
	$($id).tooltip({ content:function(){
		return (hSys.sLayoutMode == 'grid') ?$(this).data('title') :null
	}, position:{my:'left top', at:'left bottom'} })
}

function fncFlush() {addLog('fncFlush()')}

function tglBtnMenu() {nav_ft.slideToggle(); tglSortable(false)}
function hideBtnMenu() {if (nav_ft.css('display') != 'none') nav_ft.hide()}
function tglBtnEdit() {
	if (nav_ft.css('display') != 'none') return

	$("input[name='raLstSort']").checkboxradio("enable")
	var is_ed = ! books.hasClass('mode_edit')
	tglSortable(is_ed)
//	$('#btnEdit').buttonMarkup({theme: is_ed ?'a': 'b'})
}
function tglSortable(b) {
	books.toggleClass('mode_edit', b).sortable({disabled:!b})
	$('#btnEdit').toggleClass('ui-btn-active', b)
}

function closeWin() {}
function addLog(txt) {if (window && window.console) console.log(txt)}
function openURL(url) {window.open(url)}
function setClipboard(txt) {}
function notice(text, type) {noty({
	text:text
,	layout:'top'
,	type:type
,	animation:{
		open: {height:'toggle'}
	,	close: {height:'toggle'}
	,	easing:'swing'
	,	speed:500
	}
,	timeout:5000
,	modal:false
,	closeWith:['click']
})}
function alertYN(text, yes) {noty({
	text:text
,	type:'alert'
,	layout:'center'
,	modal:true
,	timeout:5000
,	buttons:[
		{addClass: 'btn btn-primary', text: 'Ok', onClick: function(nt) {yes(nt)}}
	,	{addClass: 'btn btn-danger', text: 'Cancel', onClick: function(nt) {nt.close()}}
	]
})}
function noticeErr(text) {notice(text, 'error')}

var notyDlgDL = null
function dlgDL(text, cancel) {notyDlgDL = noty({
	text:text
,	type:'information'
,	layout:'center'
,	modal:true
,	callback: {onClose: function() {notyDlgDL = null}}
,	buttons:[
		{addClass: 'btn btn-danger', text: 'Cancel', onClick: function(nt) {cancel()}}
	]
})}
function dlgDL_setText(text) {
	if (notyDlgDL) notyDlgDL.setText(text)
	else dlgDL(text, function (){})
}
function dlgDL_close() {if (notyDlgDL) notyDlgDL.close()}
