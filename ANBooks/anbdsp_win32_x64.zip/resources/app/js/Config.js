"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const m_fs = require("fs-extra");
const CmnLib_1 = require("./CmnLib");
;
;
class Config {
    constructor(oCfg, path_nm) {
        this.first_script = { fn: 'main' };
        this.save_ns = { name: '' };
        this.search = {};
        this.search_p_use_pathfile = false;
        this.coder = { len: 0x360 };
        this.window = {
            width: 300,
            height: 300,
        };
        this.anbook = {
            title: '',
            creator: '',
            cre_url: '',
            publisher: '',
            pub_url: '',
            detail: '',
            upd_an: 'true',
            version: '1.0',
            prjtype: '',
            nocode_reg: 'system/.+.(mp3|swf|xml)|m4a|config/.+',
            nocode: '',
            pack_exc: '\.swf\.cache',
            rotate: '',
            dl_url: '',
            inc_path: {},
        };
        this.log = { max_len: 1024 };
        this.init = {
            bg_color: 0x000000,
            tagch_msecwait: 10,
            auto_msecpagewait: 3500,
        };
        this.debug = { devtool: false };
        this.hPathFn2Exts = {};
        this.hPathFn2Retina = {};
        this.hExtNG = {
            'db': 0,
            'ini': 0,
            'DS_Store': 0
        };
        try {
            if (('first_script' in oCfg) && ('$' in oCfg.first_script[0].$)) {
                this.first_script = oCfg.first_script[0].$;
            }
            if ('search' in oCfg && oCfg.search[0].$)
                this.search_p_use_pathfile
                    = Boolean(oCfg.search[0].$.use_pathfile
                        || this.search_p_use_pathfile);
            this.save_ns = oCfg.save_ns[0].$;
            if ('coder' in oCfg && oCfg.coder[0].$)
                this.coder.len
                    = parseInt(oCfg.coder[0].$.len || this.coder.len);
            if ('window' in oCfg && oCfg.window[0].$) {
                this.window.width = parseInt(oCfg.window[0].$.width
                    || this.window.width);
                this.window.height = parseInt(oCfg.window[0].$.height
                    || this.window.height);
            }
            if ('anbook' in oCfg && oCfg.anbook[0].$) {
                const ab = oCfg.anbook[0].$;
                if ('title' in ab)
                    this.anbook.title = ab.title;
                if ('creator' in ab)
                    this.anbook.creator = ab.creator;
                if ('cre_url' in ab)
                    this.anbook.cre_url = ab.cre_url;
                if ('publisher' in ab)
                    this.anbook.publisher = ab.publisher;
                if ('pub_url' in ab)
                    this.anbook.pub_url = ab.pub_url;
                if ('detail' in ab)
                    this.anbook.detail = ab.detail;
                if ('upd_an' in ab)
                    this.anbook.upd_an = ab.upd_an;
                if ('version' in ab)
                    this.anbook.version = ab.version;
                if ('prjtype' in ab)
                    this.anbook.prjtype = ab.prjtype;
                if ('nocode_reg' in ab)
                    this.anbook.nocode_reg = ab.nocode_reg;
                if ('nocode' in ab)
                    this.anbook.nocode = ab.nocode;
                if ('pack_exc' in ab)
                    this.anbook.pack_exc = ab.pack_exc;
                if ('rotate' in ab)
                    this.anbook.rotate = ab.rotate;
                if ('inc' in ab)
                    ab.inc.forEach(e => this.anbook[e.$.path] = true);
            }
            if ('log' in oCfg && oCfg.log[0].$)
                this.log.max_len
                    = parseInt(oCfg.log[0].$.max_len || this.log.max_len);
            if ('init' in oCfg && oCfg.init[0].$) {
                this.init.bg_color
                    = parseInt(oCfg.init[0].$.bg_color || this.init.bg_color);
                this.init.tagch_msecwait
                    = parseInt(oCfg.init[0].$.tagch_msecwait
                        || this.init.tagch_msecwait);
                this.init.auto_msecpagewait
                    = parseInt(oCfg.init[0].$.auto_msecpagewait
                        || this.init.auto_msecpagewait);
            }
            if ('debug' in oCfg && oCfg.debug[0].$)
                this.debug.devtool
                    = Boolean(oCfg.debug[0].$.devtool || this.debug.devtool);
            const REG_FN_RATE_SPRIT = /(.+?)(?:%40(\d)x)?(\.\w+)/;
            const aSearch = oCfg.search[0].path;
            if (aSearch == undefined)
                return;
            const lSearch = aSearch.length;
            for (let i = 0; i < lSearch; ++i) {
                if (!aSearch[i].$)
                    continue;
                const dir = aSearch[i].$.dir;
                if (!m_fs.existsSync(path_nm + dir))
                    continue;
                this.search[dir] = true;
                const a = m_fs.readdirSync(path_nm + dir), len = a.length;
                const aSort = [];
                for (let j = 0; j < len; ++j) {
                    const nm = a[j];
                    if (nm.charAt(0) == '.' || nm == 'Thumbs.db'
                        || nm == 'Desktop.ini' || nm == '_notes'
                        || nm == 'Icon\r')
                        continue;
                    const fo_url = path_nm + dir + '/' + nm;
                    if (m_fs.lstatSync(fo_url).isDirectory())
                        continue;
                    const fo_ext = CmnLib_1.CmnLib.getExt(nm);
                    if (fo_ext in this.hExtNG)
                        continue;
                    const fo_fn = CmnLib_1.CmnLib.getFn(nm);
                    let h_exts = this.hPathFn2Exts[fo_fn];
                    if (!h_exts) {
                        h_exts = this.hPathFn2Exts[fo_fn] = { ':cnt': '1' };
                    }
                    else if (fo_ext in h_exts) {
                        throw ('[xmlCfg.search.path] サーチパスにおいてファイル名＋拡張子【' + fo_fn + '】が重複しています。フォルダを縦断検索するため許されません');
                    }
                    else {
                        h_exts[':cnt'] = String(Number(h_exts[':cnt']) + 1);
                    }
                    h_exts[fo_ext] = fo_url;
                    if (!CmnLib_1.CmnLib.isRetina)
                        continue;
                    const oRate = REG_FN_RATE_SPRIT.exec(fo_url);
                    if (oRate[2])
                        continue;
                    const fn_xga = oRate[1] + CmnLib_1.CmnLib.retinaFnTail + oRate[3];
                    if (m_fs.existsSync(fn_xga)) {
                        this.hPathFn2Retina[fo_fn] = true;
                        h_exts[fo_ext] = fn_xga;
                        continue;
                    }
                    h_exts[fo_ext] = fo_url;
                }
            }
        }
        catch (err) {
            if (err instanceof TypeError) {
                console.error('Config(): config.anprj 異常です');
            }
            throw err;
        }
    }
    searchPath(fn, ext = null) {
        if (!fn)
            throw ('[searchPath] fnが空です');
        if (fn.substr(0, 7) == 'http://')
            return fn;
        const a = {
            fn: CmnLib_1.CmnLib.getFn(fn),
            ext: CmnLib_1.CmnLib.getExt(fn)
        };
        if (CmnLib_1.CmnLib.userFnTail) {
            const utn = a.fn + '@@' + CmnLib_1.CmnLib.userFnTail;
            if (utn in this.hPathFn2Exts) {
                if (!ext)
                    a.fn = utn;
                else
                    for (let e3 in this.hPathFn2Exts[utn]) {
                        if (('|' + ext + '|').indexOf('|' + e3 + '|') == -1)
                            continue;
                        a.fn = utn;
                        break;
                    }
            }
        }
        const h_exts = this.hPathFn2Exts[a.fn];
        if (!h_exts)
            throw ('サーチパスに存在しないファイル【' + fn + '】です');
        let ret = '';
        if (!a.ext) {
            const hcnt = parseInt(h_exts[':cnt'], 10);
            if (ext == null) {
                if (hcnt > 1)
                    throw ('指定ファイル【' + fn + '】が複数マッチします。サーチ対象拡張子群【' + ext + '】で絞り込むか、ファイル名を個別にして下さい。');
                return fn;
            }
            const search_exts = '|' + ext + '|';
            if (hcnt > 1) {
                let cnt = 0;
                for (var e2 in h_exts) {
                    if (search_exts.indexOf('|' + e2 + '|') == -1)
                        continue;
                    if (++cnt > 1)
                        throw ('指定ファイル【' + fn + '】が複数マッチします。サーチ対象拡張子群【' + ext + '】で絞り込むか、ファイル名を個別にして下さい。');
                }
            }
            for (let e in h_exts) {
                if (search_exts.indexOf('|' + e + '|') == -1)
                    continue;
                return h_exts[e];
            }
            throw ('サーチ対象拡張子群【' + ext + '】にマッチするファイルがサーチパスに存在しません。探索ファイル名=【' + fn + '】');
        }
        if (ext) {
            const search_exts2 = '|' + ext + '|';
            if (search_exts2.indexOf('|' + a.ext + '|') == -1) {
                throw ('指定ファイルの拡張子【' + a.ext + '】は、サーチ対象拡張子群【' + ext + '】にマッチしません。探索ファイル名=【' + fn + '】');
            }
        }
        ret = h_exts[a.ext];
        if (!ret)
            throw ('サーチパスに存在しない拡張子【' + a.ext + '】です。探索ファイル名=【' + fn + '】、サーチ対象拡張子群【' + ext + '】');
        return ret;
    }
}
Config.EXT_LOADER = 'png_|jpg_|jpeg_|json_|png|jpg|jpeg|json';
Config.EXT_URLLOADER = 'an_|an|txt_|txt';
Config.EXT_SNDLOADER = 'mp3_|mp3|m4a|oggo_|oggo|ogg_|ogg';
exports.Config = Config;
//# sourceMappingURL=Config.js.map