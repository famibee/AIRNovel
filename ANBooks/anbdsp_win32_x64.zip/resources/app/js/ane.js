var path_app_str = '', path_unpack = '', path_nm = ''
var me_ipc = null, guiWin = null, ed = null, ses = null
var m_fs = null
const Range = ace.require('ace/range').Range

$(function(){
	// electron版の処理
	if (typeof process !== 'undefined') {
		const me_el = require('electron')
		me_ipc = me_el.ipcRenderer
		const me_remote = me_el.remote
		const me_app = me_remote.app
		guiWin = me_remote.getCurrentWindow()
		m_fs = require('fs-extra')
		
		path_app_str = me_app.getPath('appData').replace(/\\/g, '/') +'/com.fc2.blog38.famibee.ANBooks/Local Store/'
		path_unpack = path_app_str +'unpack/'

		me_ipc.on('break_wait', function (e, v) { break_wait(v) })
		me_ipc.on('break_exit', function (e, v) { break_exit() })
	}

	ed = ace.edit('editor')
	ses = ed.session
	
//	ed.setTheme('ace/theme/eclipse')
//	ed.setTheme('ace/theme/solarized_light')
//	ed.setTheme('ace/theme/tomorrow')
	
	ed.setTheme('ace/theme/cobalt')
//	ed.setTheme('ace/theme/merbivore')
//	ed.setTheme('ace/theme/merbivore_soft')
	
	ses.setMode('ace/mode/airnovel')
	ses.setUseWrapMode(true)
	ed.setHighlightActiveLine(true)
	ed.setShowInvisibles(true)
	ed.setShowPrintMargin(false)	// いずれはモーダルダイアログで改行桁数指定
//	ed.setOptions({enableBasicAutocompletion: true})
		// http://qiita.com/naga3/items/1bc268243f2e8a6514e5
//	ed.setHighlightGutterLine()
/**/ed.setReadOnly(true)
	ed.$blockScrolling = Infinity
	ed.focus()
/*
	document.body.addEventListener('click', function (e) {
		drop(e.pageX, e.pageY)
	}, false)
*/
})

var mkBreakToken = null
function break_wait(sB) {
	const oB = JSON.parse(sB)
//addLog('\t nm:'+ oB.nm)
//addLog('\t evt:'+ oB.evt)
//addLog('\t mes:'+ oB.mes)
	if (! path_nm) {
		setWorkPath(path_unpack + oB.nm +'/')

		const fn = searchPath(oB.fn +'.an')
		if (! m_fs.existsSync(fn)) return

//addLog('exists')
		const str = m_fs.readFileSync(fn, 'utf8')
		ses.setValue(str)
	}

	// カーソル移動
	ed.moveCursorTo(oB.l -1, oB.cs -1)
//	ed.getSelection().setSelectionRange(new Range(oB.l -1, oB.cs -1, oB.l -1, oB.ce -1), false)
	// マーキング
	break_exit()
	const range = new Range(oB.l -1, oB.cs -1, oB.l -1, oB.ce -1)
	mkBreakToken = ses.addMarker(range, 'ace_step')
	ses.setBreakpoint(oB.l -1, (oB.evt=='wait') ?'ace_info' :'ace_error')
	// 波紋
	const p = ed.renderer.textToScreenCoordinates(oB.l -1, (oB.cs + oB.ce)/2)
	drop(p.pageX, p.pageY, (oB.evt=='wait') ?'#6EB2E0' :'#E04E20')
}
function break_exit() {
	if (! mkBreakToken) return

	ses.removeMarker(mkBreakToken)
	ses.clearBreakpoints()
}

var xS = null, sp = [], sp_len = 0
function setWorkPath(path) {
	path_nm = path
	xS = $.parseXML(m_fs.readFileSync(path +'config.anprj', 'utf8'))
	sp = $(xS).find('search path')
	sp_len = sp.length
}
function searchPath(fn, ext) {
	if (ext === undefined) ext = ''

	for (var i=0; i<sp_len; ++i) {
		const d = $(sp[i]).attr('dir')
		const path_d = path_nm + d +'/'+ fn
		if (! m_fs.existsSync(path_d)) continue
		if (m_fs.statSync(path_d).isDirectory()) continue

		return path_d
	}
}

function drop(x, y, col) {
	const s = document.createElement('div')
	s.style.left = x + 'px'
	s.style.top = y + 'px'
	if (col !== undefined) {
		s.style.backgroundColor = col	/*背景色*/
		s.style.borderColor = col		/*ボーダーの幅と色*/
	}
	document.body.appendChild(s)
	s.className = 'sizuku'
	s.addEventListener('animationend', function() {
		this.parentNode.removeChild(this)
	}, false)
}

function addLog(txt) {
	if (! guiWin.isDevToolsOpened()) guiWin.openDevTools('undocked')
	console.log(txt)
}
