"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const app = electron_1.remote.app;
const m_fs = require("fs-extra");
const m_os = require("os");
const m_path = require("path");
const xmls = new XMLSerializer();
require('date-utils');
const PrjBook_1 = require("./PrjBook");
const AnbMain_1 = require("./AnbMain");
var sSortbtn;
(function (sSortbtn) {
    sSortbtn["SortRandom"] = "raSortRandom";
    sSortbtn["Sort1"] = "raSort1";
    sSortbtn["Sort2"] = "raSort2";
    sSortbtn["Sort3"] = "raSort3";
    sSortbtn["SortMy"] = "raSortM";
})(sSortbtn = exports.sSortbtn || (exports.sSortbtn = {}));
;
;
;
class AnbData {
    constructor() {
        this.fn = '';
        this.oJson = {
            ver: '13:11:00 GMT+0900 2017/1/3',
            sys: {
                'nativeWindow.x': 0,
                'nativeWindow.y': 0,
                'nativeWindow.width': 600,
                'nativeWindow.height': 800,
                'winTerm.x': 600,
                'winTerm.y': 0,
                'winTerm.w': 600,
                'winTerm.h': 800,
                'last_id': 0,
                'sLayoutMode': 'list',
                'sMySort': '',
                'sSortbtn': sSortbtn.Sort1,
                'sSortkey': 'id',
                'sSortOrder': 'desc',
                'isReplace_AddSameFile': true,
            },
            book: {},
        };
        this.pBldp = null;
        this.sBldp = null;
        this.xBldp = null;
        this.sJson = '';
        this.regNoPrjname = new RegExp('\W', 'g');
    }
    init(fn, hBook) {
        this.fn = fn;
        const exists_abnjson = m_fs.existsSync(this.fn);
        if (exists_abnjson) {
            this.oJson = JSON.parse(m_fs.readFileSync(this.fn, { encoding: 'utf8' }));
            for (let id in this.oJson.book)
                hBook[id] = this.oJson.book[id];
            this.sMySort = this.sMySort
                .split(',').filter(id => (id in hBook)).join(',');
        }
        else {
            const a = m_fs.readdirSync(AnbData.path_unpack), len = a.length;
            const aSort = [];
            for (let i = 0; i < len; ++i) {
                const nm = a[i];
                if (nm.charAt(0) == '.' || nm == 'Thumbs.db'
                    || nm == 'Desktop.ini' || nm == '_notes')
                    continue;
                ++this.oJson.sys.last_id;
                const pb = new PrjBook_1.PrjBook(nm, 'lst_0', this);
                const path_nm = AnbData.path_unpack + nm + '/';
                aSort.push({ ab: pb, ts: m_fs.statSync(path_nm).birthtime });
            }
            aSort.sort((a, b) => {
                const a_ = a.ts, b_ = b.ts;
                if (a_ < b_)
                    return -1;
                if (a_ > b_)
                    return 1;
                return 0;
            });
            for (let i = 0; i < this.oJson.sys.last_id; ++i) {
                const ab = aSort[i].ab;
                const id = ab.id = 'lst_' + i;
                hBook[id] = ab;
                this.oJson.book[id] = {
                    fn: ab.fn,
                    id: id,
                    icon: 'true',
                    title: ab.title,
                    creator: ab.creator,
                    cre_url: ab.cre_url,
                    publisher: ab.publisher,
                    pub_url: ab.pub_url,
                    detail: ab.detail,
                    upd_an: ab.upd_an,
                    version: ab.version,
                    prjtype: ab.prjtype,
                    nocode_reg: ab.nocode_reg,
                    nocode: ab.nocode,
                    pack_exc: ab.pack_exc,
                    rotate: ab.rotate,
                    dl_url: ab.dl_url,
                };
            }
        }
        if (this.sMySort == '') {
            const a = [];
            for (let id in this.oJson.book)
                a.push(id);
            this.sMySort = a.sort().reverse().join(',');
        }
        this.replaceJson();
        this.pBldp = AnbData.path_app_str + 'build.p.xml';
        if (m_fs.existsSync(this.pBldp)) {
            this.sBldp = m_fs.readFileSync(this.pBldp, { encoding: 'utf8' });
        }
        else {
            const code_key = AnbData.create_pwd(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_');
            this.sBldp = m_fs.readFileSync(AnbData.path_app_nw + 'template/build.p.xml', { encoding: 'utf8' })
                .replace('name="sign_key" value="dummy_password"', 'name="sign_key" value="' + code_key + '"')
                .replace(new RegExp('"app_dir" value=".+"'), '"app_dir" value="' +
                m_path.normalize(AnbData.path_app_nw + '/..') + '"')
                .replace(new RegExp('"appstr_dir" value=".+"'), '"appstr_dir" value="' + AnbData.path_app_str + '"');
            if (AnbData.is_mac) {
                this.sBldp = this.sBldp
                    .replace(new RegExp('"flex_sdk" value=".+"', 'g'), '"flex_sdk" value="' + AnbData.path_desktop + 'SDK/flex_sdk/"');
            }
            m_fs.writeFile(this.pBldp, this.sBldp, { encoding: 'utf8' });
        }
        this.xBldp = $.parseXML(this.sBldp);
        m_fs.copy(AnbData.path_app_nw + 'template/build_base.xml', AnbData.path_app_str + 'build_base.xml');
        const me = this;
        let xl_flex_sdk = $(this.xBldp).find('os[family="'
            + (AnbData.is_mac ? 'unix' : 'windows')
            + '"]').parent('condition[property="flex_sdk"]');
        $('#txt_gbld_flex_sdk')
            .val(xl_flex_sdk.attr('value'))
            .on('textchange', function () {
            const t = $(this);
            let v = String(t.val());
            const mes = (() => {
                if (v.indexOf(' ') >= 0)
                    return 'Flex SDKパスは半角空白を含んではいけません';
                v = v
                    .replace(/[\\\/]+/g, '/')
                    .replace(/[\/\¥]$/, '') + '/';
                if (!m_fs.existsSync(v))
                    return 'フォルダが見つかりません';
                try {
                    if (!m_fs.existsSync(v + 'airnovel_lib/')) {
                        m_fs.mkdirsSync(v + 'airnovel_lib/');
                        m_fs.rmdirSync(v + 'airnovel_lib/');
                    }
                }
                catch (e) {
                    return '書き込む権限が無いので、別のフォルダにして下さい';
                }
                return '';
            })();
            if (mes)
                $('#lbl_chk_flex_sdk').text(mes).css('color', 'red');
            else {
                $('#lbl_chk_flex_sdk').text('設定完了').css('color', 'blue');
                xl_flex_sdk.attr('value', v);
                me.sBldp = xmls.serializeToString(me.xBldp);
                m_fs.writeFile(me.pBldp, me.sBldp, { encoding: 'utf8' });
            }
        });
        return exists_abnjson;
    }
    addPrj(nm) {
        const id = 'lst_' + this.oJson.sys.last_id++;
        const pb = new PrjBook_1.PrjBook(nm, id, this);
        if (pb.nocode != 'true')
            this.decryption(AnbData.path_unpack + nm + '/');
        this.oJson.book[id] = {
            fn: pb.fn,
            id: id,
            icon: 'true',
            title: pb.title,
            creator: pb.creator,
            cre_url: pb.cre_url,
            publisher: pb.publisher,
            pub_url: pb.pub_url,
            detail: pb.detail,
            upd_an: pb.upd_an,
            version: pb.version,
            prjtype: pb.prjtype,
            nocode_reg: pb.nocode_reg,
            nocode: pb.nocode,
            pack_exc: pb.pack_exc,
            rotate: pb.rotate,
            dl_url: pb.dl_url,
        };
        this.sMySort = id + (this.sMySort == '' ? '' : ',') + this.sMySort;
        this.replaceJson();
        return { id: id, pb: pb };
    }
    delPrj(id) {
        const ab = this.oJson.book[id];
        if (!ab)
            return;
        AnbMain_1.AnbMain.dropDust(AnbData.path_unpack + ab.fn);
        delete this.oJson.book[id];
        this.sMySort = (',' + this.sMySort).replace(',' + id, '').slice(1);
        this.replaceJson();
    }
    decryption(path_nm) {
        m_fs.readdirSync(path_nm).forEach(fld => {
            const fDir = path_nm + fld;
            if (!m_fs.lstatSync(fDir).isDirectory())
                return;
            m_fs.readdirSync(fDir).forEach(function (f2) {
                if (f2.substr(-1) != '_')
                    return;
                f2 = fDir + '/' + f2;
                const buf = m_fs.readFileSync(f2);
                m_fs.writeFileSync(f2.slice(0, -1), this.crc4.rc4(buf, buf.length));
                m_fs.removeSync(f2);
            });
        });
    }
    get bounds() {
        return {
            x: this.oJson.sys['nativeWindow.x'],
            y: this.oJson.sys['nativeWindow.y'],
            width: this.oJson.sys['nativeWindow.width'],
            height: this.oJson.sys['nativeWindow.height'],
        };
    }
    ;
    setPos(x, y) {
        this.oJson.sys['nativeWindow.x'] = x;
        this.oJson.sys['nativeWindow.y'] = y;
        this.replaceJson();
    }
    setSize(w, h) {
        this.oJson.sys['nativeWindow.width'] = w;
        this.oJson.sys['nativeWindow.height'] = h;
        this.replaceJson();
    }
    get boundsTerm() {
        return {
            x: this.oJson.sys['winTerm.x'],
            y: this.oJson.sys['winTerm.y'],
            width: this.oJson.sys['winTerm.w'],
            height: this.oJson.sys['winTerm.h'],
        };
    }
    ;
    setPosTerm(x, y) {
        this.oJson.sys['winTerm.x'] = x;
        this.oJson.sys['winTerm.y'] = y;
        this.replaceJson();
    }
    setSizeTerm(w, h) {
        this.oJson.sys['winTerm.w'] = w;
        this.oJson.sys['winTerm.h'] = h;
        this.replaceJson();
    }
    get sLayoutMode() { return this.oJson.sys.sLayoutMode; }
    set sLayoutMode(v) {
        this.oJson.sys.sLayoutMode = v;
        this.replaceJson();
    }
    get sMySort() { return this.oJson.sys.sMySort; }
    set sMySort(v) { this.oJson.sys.sMySort = v; this.replaceJson(); }
    get sSortbtn() { return this.oJson.sys.sSortbtn; }
    set sSortbtn(v) { this.oJson.sys.sSortbtn = v; this.replaceJson(); }
    get sSortkey() {
        return this.oJson.sys.sSortkey;
    }
    set sSortkey(v) {
        this.oJson.sys.sSortkey = v;
        this.replaceJson();
    }
    get sSortOrder() { return this.oJson.sys.sSortOrder; }
    set sSortOrder(v) { this.oJson.sys.sSortOrder = v; this.replaceJson(); }
    getSysAny(n) {
        if (!(n in this.oJson.sys))
            return null;
        return this.oJson.sys[n];
    }
    setSysAny(n, v) {
        if (!(n in this.oJson.sys))
            return;
        this.oJson.sys[n] = v;
        this.replaceJson();
    }
    getBook(id) {
        if (!(id in this.oJson.book))
            return null;
        return this.oJson.book[id];
    }
    setBook(id, k, v) {
        if (!(id in this.oJson.book))
            return;
        this.oJson.book[id][k] = v;
        this.replaceJson();
    }
    replaceJson() {
        const new_ = JSON.stringify(this.oJson);
        if (this.sJson == new_)
            return;
        this.sJson = new_;
        m_fs.writeFileSync(this.fn, this.sJson, { encoding: 'utf8' });
    }
    newprj(nm) {
        if (nm == '')
            return 'プロジェクト名を指定して下さい';
        if (this.regNoPrjname.test(nm))
            return 'プロジェクト名が異常です';
        const nm_len = nm.length;
        if (nm_len > 30)
            return 'プロジェクト名は30文字までです（現在' + nm_len + '文字）';
        const path_nm = AnbData.path_unpack + nm + '/';
        if (m_fs.existsSync(path_nm))
            return 'プロジェクト ' + nm + ' はすでに有ります';
        m_fs.copySync(AnbData.path_app_nw + 'template/newprj', path_nm);
        this.newprj_config(nm);
        const code_key = AnbData.create_pwd(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_');
        AnbData.replaceTxt(path_nm + 'build.xml', str => str
            .replace('name="app_name" value="temp"', 'name="app_name" value="' + nm + '"')
            .replace('name="my_sign_key" value="dummy_password"', 'name="my_sign_key" value="' + code_key + '"')
            .replace(/web\.famibee\.temp\"\/>/g, 'web.famibee.'
            + nm.replace(/_/g, '-')
            + '\"\/>'));
        AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
            .replace('web.famibee.temp', 'web.famibee.'
            + nm.replace(new RegExp('_', 'g'), '-'))
            .replace('<filename>temp<', '<filename>' + nm
            .replace(new RegExp('[\*":><\?\\|]', 'g'), '_') + '<')
            .replace('<name>tempプロジェクト<', '<name>' + nm + '<')
            .replace('<content>temp.swf<', '<content>' + nm + '.swf<'));
        AnbData.replaceTxt(path_nm + 'mat/main.an', str => str.replace('temp[span layout', nm + '[span layout'));
        PrjBook_1.PrjBook.set_code_key(nm, AnbData.create_pwd());
        return '';
    }
    newprj_config(nm) {
        AnbData.replaceTxt(AnbData.path_unpack + nm + '/config.anprj', str => this.rep_newprj_config(str, nm));
    }
    rep_newprj_config(str, nm) {
        return str
            .replace('web.famibee.temp', 'web.famibee.' + nm)
            .replace('title="temp', 'title="' + nm);
    }
    static replaceTxt(url, fnc) {
        if (!m_fs.existsSync(url))
            return;
        const old_ = m_fs.readFileSync(url, 'utf8');
        const new_ = fnc(old_);
        if (old_ != new_)
            m_fs.writeFileSync(url, new_, { encoding: 'utf8' });
    }
    getBldp(t) {
        if (!this.xBldp)
            return null;
        const k = t.data('sdb');
        switch (k) {
            case 'keystore_i':
            case 'sign_key_i':
            case 'keystore_as':
            case 'sign_key_as':
            case 'appleid':
            case 'appleid_pass':
                const xl = $(this.xBldp).find('property[name="' + k + '"]');
                return xl.attr('value');
            default:
                return null;
        }
    }
    updBldp(t, v) {
        if (!this.xBldp)
            return null;
        const k = t.data('sdb');
        const xl = $(this.xBldp).find('property[name="' + k + '"]');
        switch (k) {
            case 'keystore_i':
            case 'sign_key_i':
            case 'keystore_as':
            case 'sign_key_as':
            case 'appleid':
            case 'appleid_pass':
                xl.attr('value', v);
                this.sBldp = xmls.serializeToString(this.xBldp);
                m_fs.writeFile(this.pBldp, this.sBldp, { encoding: 'utf8' });
                break;
        }
    }
    static get is_mac() { return m_os.type() == 'Darwin'; }
    ;
    static create_pwd(len = 256, pwd_tbl = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#%()*+-./:;=?@[]_`{}~') {
        let ret = '', cl = pwd_tbl.length;
        for (let i = 0; i < len; ++i)
            ret += pwd_tbl[Math.floor(Math.random() * cl)];
        return ret;
    }
    static getDateStr() {
        const dt = new Date();
        return dt['toFormat']('YYYY/MM/DD(' + AnbData.sday[dt.getDay()] + ') HH24MI');
    }
}
AnbData.path_app_str = app.getPath('appData').replace(/\\/g, '/')
    + '/com.fc2.blog38.famibee.ANBooks/Local Store/';
AnbData.path_app_nw = app.getAppPath().replace(/\\/g, '/') + '/';
AnbData.path_unpack = AnbData.path_app_str + 'unpack/';
AnbData.path_desktop = app.getPath('desktop').replace(/\\/g, '/') + '/';
AnbData.sday = ['日', '月', '火', '水', '木', '金', '土'];
exports.AnbData = AnbData;
//# sourceMappingURL=AnbData.js.map