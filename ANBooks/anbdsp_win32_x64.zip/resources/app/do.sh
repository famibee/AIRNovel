#!/bin/bash
cd "`dirname "$0"`"

# 「開発元が未確認のため開けません」の対処
xattr -d com.apple.quarantine ANBooks.app
open -g ANBooks.app
# open -g -W ANBooks.app
# ANBooks.app/Contents/MacOS/nwjs
