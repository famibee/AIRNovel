#!/bin/bash

if [ $# -eq 0 ]; then
	echo "[usage] text_editer_app [line]" 1>&2
	exit 1
fi
#echo "$@"
open "$@"

#exit 0
