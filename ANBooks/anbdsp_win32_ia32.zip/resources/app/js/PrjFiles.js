"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class PrjBook {
    constructor(path_prj) {
        this.cfg = null;
        ;
    }
}
exports.PrjBook = PrjBook;
//# sourceMappingURL=PrjFiles.js.map