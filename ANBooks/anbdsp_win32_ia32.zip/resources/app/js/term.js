function setTitle(txt) {$('h1').text(txt)}
function addTrace(txt) {
	$('#term').append(txt).trigger('create')
	$.mobile.silentScroll(99999999)
}

// AIR版用、ログ追加の度にクリックイベントを付加する処理
function openURL(url) {
	window.runtime.flash.net.navigateToURL(new window.runtime.flash.net.URLRequest(url))
}
function setGoEvt(fnc) {
	$('.goscr').on('click', function () {
		fnc(this.href, $(this).attr('data-line'), $(this).attr('data-col'))
		return false
	}).removeClass('goscr')
	$('.goman').on('click', function () {
		openURL(this.href)
		return false
	}).removeClass('goman')
}

// electron版の処理
if (typeof process !== 'undefined') {
	function addLog(txt) {console.log(txt)}

	const me_el = require('electron');
	const me_ipc = me_el.ipcRenderer;
	const me_remote = me_el.remote;
	const me_app = me_remote.app;
	const me_shell = me_el.shell;
	const m_fs = require('fs-extra');

	const path_app_str = me_app.getPath('appData') +'/com.fc2.blog38.famibee.ANBooks/Local Store/';
	const fn_log = path_app_str +'log/log.htm';
	const path_app_nw = me_app.getAppPath().replace(/\\/g, '/') +'/';
	const fn_log_tmp = path_app_nw +'template/log.htm';
	openURL = me_shell.openExternal;

//addLog('term:0')
	me_ipc.on('setTitle', function (e, v) { setTitle(v); });
	me_ipc.on('addTrace', function (e, v) {
		addTrace(v);

		if (v.indexOf('<a href=') >= 0) {
			setGoEvt(function (path, line, col) {
				const fn = decodeURIComponent(path.slice(7));
				//addLog('openEd:'+ fn +' line:'+ line +' col:'+ col)
			//	me_app.addRecentDocument(fn)	// 最近のドキュメント一覧に追加
				me_shell.openItem(fn);
			})
		}

		if (start3d) {
			const fn_3d = path_app_str +'nobld/term3d.json'
			if (m_fs.existsSync(fn_3d)) {
				const mag = 0.5;
				const o3d = JSON.parse(m_fs.readFileSync(fn_3d));
				const a3dlay = o3d.a3dlay;
				$.each(a3dlay ,function (idx, v) {
					a3dlay[idx] = v.replace(/%2F/g, '\/');
				});
				//addLog('term w:'+ o3d.w +' h:'+ o3d.h)
				start3d(a3dlay, o3d.w *o3d.mag, o3d.h *o3d.mag);
				pg3d.rotate(-20, 5);
			}
		}

		if (! m_fs.existsSync(fn_log)) m_fs.copySync(fn_log_tmp, fn_log);
		m_fs.appendFileSync(fn_log, v, {encoding:'utf8'});
	});

	$(document).on('pageinit', '#index', function(event, ui){	// 三番目に発火
		$('#del_log').on('click', ()=> {
			me_shell.moveItemToTrash(fn_log);
			setTitle('ログをゴミ箱へ捨てました');
		});
		$('#op_br').on('click', ()=> openURL('file://'+ fn_log));
	});
//addLog('term:9')
}
