var Matrix = window.WebKitCSSMatrix || window.MSCSSMatrix || CSSMatrix
var FORCE_AFFINE = /MSIE\s+9/i.test(navigator.userAgent),
	LAYER_SPACING = 75


var pg3d = null
function start3d(dump_lay, w, h) {
	$("#pnl_pg3d").remove()
	$('#term').append('<div id="pnl_pg3d" data-role="collapsible" data-inset="false"><h4>レイヤ構造３Ｄ（※最新のみ）</h4><p><p><a id="btn_pg3d0" data-role="button" data-inline="true">正面</a><a id="btn_pg3d1" data-role="button" data-inline="true">斜め</a></p><div class="pg3d" style="width:'+ w +'px; height:'+ h +'px;"></div></p></div>').trigger('create')

	pg3d = new Page($('.pg3d'), dump_lay)
	$('#btn_pg3d0').on('vclick', function () {pg3d.rotateHome()})
	$('#btn_pg3d1').on('vclick', function () {pg3d.rotateHome(-20, 5)})

	var mousedown = function (ev) {
		var last = getCoord(ev);
		var mousemove = function (ev) {
			var mouse = getCoord(ev);
				dx = mouse.x - last.x,
				dy = mouse.y - last.y;
			last = mouse;
			// note: x and y mean different things in mouse coords, vs rotation axes
			pg3d.rotate(-dy / 2, dx / 2);
			ev.preventDefault();
			return false;
		};
		var mouseup = function (ev) {
			$('#pnl_pg3d').off('mousemove touchmove MSPointerMove', mousemove)
				.off('mouseup touchend MSPointerUp mouseleave', mouseup);
			ev.preventDefault();
			return false;
		};
		$('#pnl_pg3d').on('mousemove touchmove MSPointerMove', mousemove)
			.on('mouseup touchend MSPointerUp mouseleave', mouseup);
		ev.preventDefault();
		return false;
	};
	$('#pnl_pg3d').on('mousedown touchstart MSPointerDown', mousedown);

	$('.open').show();
}

function toAffineString(m) {
	var fix6 = function (val) { return val.toFixed(6); };
	return  'matrix(' + [
			m.a, m.b,
			m.c, m.d,
			m.e, m.f
		].map(fix6).join(', ') + ')';
}

function getCoord(ev, $el) {
	ev = ev.originalEvent || ev;
	var offset = $el ? $el.offset() : { left: 0, top: 0 },
		x = ev.touches && ev.touches[0].pageX ||
			ev.pageX ||
			ev.clientX + document.body.scrollLeft + document.documentElement.scrollLeft,
		y = ev.touches && ev.touches[0].pageY ||
			ev.pageY ||
			ev.clientY + document.body.scrollTop + document.documentElement.scrollTop;
	return {
		x: x - offset.left,
		y: y - offset.top
	};
}


function Page($el, $dump_lay) {
	var self = this,
		$layers,
		// current state of rotation, relative to original position (0,0,0)
		rotation = { x: 0, y: 0, z: 0 },
		// identity matrix, used to update rotationMatrix with a new rotation state
		identityMatrix = new Matrix(),
		// current rotation matrix to be applied to the layers
		rotationMatrix = new Matrix();

	var createLayers,
		updateLayers,
		applyTransform;

	self.rotate = function (dx, dy, dz) {
		rotation.x += dx || 0;
		rotation.y += dy || 0;
		rotation.z += dz || 0;
		rotation.x = rotation.x % 360;
		rotation.y = rotation.y % 360;
		rotation.z = rotation.z % 360;
		rotationMatrix = identityMatrix.rotate(rotation.x, rotation.y, rotation.z);
		updateLayers();
	};

	self.rotateHome = function (dx, dy, dz) {
		rotation.x = dx || 0
		rotation.y = dy || 0
		rotation.z = dz || 0
		rotation.x = rotation.x % 360
		rotation.y = rotation.y % 360
		rotation.z = rotation.z % 360
		rotationMatrix = identityMatrix.rotate(rotation.x, rotation.y, rotation.z)
		updateLayers()
	};

	createLayers = function () {
		var i, layers = '';
		$lay_cnt = $dump_lay.length
		for (i = 0; i < $lay_cnt; ++i) layers += $dump_lay[i]
		$layers = $(layers);
		$el.html($layers);
	};

	updateLayers = function () {
		var flipped = (Math.abs(rotation.x) > 90 && Math.abs(rotation.x) < 270) ||
					  (Math.abs(rotation.y) > 90 && Math.abs(rotation.y) < 270);
		$.each($layers, function (i) {
			var $layer = $(this);
			if (FORCE_AFFINE) {
				if (flipped) $layer.css('z-index', $layers.length - i);
				else $layer.css('z-index', i);
			}
			applyTransform($layer);
		});
	};

	applyTransform = function ($layer) {
		var matrix = rotationMatrix.translate(0, 0, $layer.index() * LAYER_SPACING);
		$layer.css('transform', FORCE_AFFINE ? toAffineString(matrix) : matrix.toString());
	};

	createLayers();
	updateLayers();
};
