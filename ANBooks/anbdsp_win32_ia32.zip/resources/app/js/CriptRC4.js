"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CriptRC4 {
    constructor(key) {
        this.KEYLENGTH = 255;
        this.keyCodes = [];
        this.bufCodes = [];
        const len = key.length;
        for (let i = 0; i <= this.KEYLENGTH; ++i) {
            this.bufCodes[i] = key[i % len].charCodeAt(0);
            this.keyCodes[i] = i;
        }
        for (let j = 0, i = 0; i <= this.KEYLENGTH; ++i) {
            j = (j + this.keyCodes[i] + this.bufCodes[i]) & this.KEYLENGTH;
            this.keyCodes[i] ^= this.keyCodes[j];
            this.keyCodes[j] ^= this.keyCodes[i];
            this.keyCodes[i] ^= this.keyCodes[j];
        }
    }
    rc4(data, len = 0) {
        let data_pos = 0;
        const data_len = data.length;
        if ((len == 0) || (len > data_len))
            len = data_len;
        const buf = this.keyCodes.concat();
        const baRet = new Buffer(data_len);
        let baRet_pos = 0;
        let i, j, k;
        for (let i = j = k = 0; k < len; ++k) {
            i = (i + 1) & this.KEYLENGTH;
            j = (j + buf[i]) & this.KEYLENGTH;
            buf[i] ^= buf[j];
            buf[j] ^= buf[i];
            buf[i] ^= buf[j];
            const t = (buf[i] + buf[j]) & this.KEYLENGTH;
            baRet[baRet_pos++] = (data[data_pos++] ^ buf[t]);
        }
        if (len < data_len)
            for (let m = 0; m < len; ++m)
                baRet[baRet_pos++] = data[data_pos++];
        return baRet;
    }
}
exports.CriptRC4 = CriptRC4;
//# sourceMappingURL=CriptRC4.js.map