"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const me_bw = electron_1.remote.BrowserWindow;
const openURL = electron_1.shell.openExternal;
const m_fs = require("fs-extra");
const m_spawn = require('child_process').spawn;
const m_https = require("https");
const m_path = require("path");
const Noty = require("noty");
const AdmZip = require("adm-zip");
const PrjBook_1 = require("./PrjBook");
const AnbData_1 = require("./AnbData");
class AnbMain {
    constructor() {
        this.c_menu = new electron_1.remote.Menu();
        this.anbdt = new AnbData_1.AnbData;
        this.hBook = {};
        this.cntBook = 0;
        this.books = null;
        this.nav_ft = null;
        this.hisInitedDetail = {};
        this.upd_event = true;
        this.ls = null;
        this.win_term = null;
        this.win_ane = null;
        this.strBuf = '';
        this.regUserName = /Users([\\\/]).+?\1/g;
        m_fs.mkdirsSync(AnbData_1.AnbData.path_unpack);
        m_fs.remove(AnbData_1.AnbData.path_app_str + 'log.htm');
        m_fs.copy(AnbData_1.AnbData.path_app_nw + 'css/anbooks.css', AnbData_1.AnbData.path_app_str + 'log/anbooks.css');
        m_fs.copy(AnbData_1.AnbData.path_app_nw + 'js/jquery-2.2.x.min.js', AnbData_1.AnbData.path_app_str + 'log/jquery-2.2.x.min.js');
        m_fs.copy(AnbData_1.AnbData.path_app_nw + 'css/jquery.mobile-1.4.x.min.css', AnbData_1.AnbData.path_app_str + 'log/jquery.mobile-1.4.x.min.css');
        m_fs.copy(AnbData_1.AnbData.path_app_nw + 'js/jquery.mobile-1.4.x.min.js', AnbData_1.AnbData.path_app_str + 'log/jquery.mobile-1.4.x.min.js');
        const fn_json = AnbData_1.AnbData.path_app_str + 'ANBooks.json';
        if (this.anbdt.init(fn_json, this.hBook)) {
            AnbMain.guiWin.setBounds(this.anbdt.bounds);
        }
        else {
            AnbMain.guiWin.webContents.on('dom-ready', () => {
                const p = AnbMain.guiWin.getPosition();
                this.anbdt.setPos(p[0], p[1]);
                const s = AnbMain.guiWin.getSize();
                this.anbdt.setSize(s[0], s[1]);
            });
        }
        AnbMain.guiWin.on('move', () => {
            const p = AnbMain.guiWin.getPosition();
            this.anbdt.setPos(p[0], p[1]);
        });
        AnbMain.guiWin.on('resize', (w, h) => {
            const s = AnbMain.guiWin.getSize();
            this.anbdt.setSize(s[0], s[1]);
        });
        $(window)['unload'](this.closeWin);
        $('#dlg_newprj .anb6_support').show();
        const MenuItem = electron_1.remote.MenuItem;
        this.c_menu.append(new MenuItem({ role: 'copy' }));
        this.c_menu.append(new MenuItem({ role: 'cut' }));
        this.c_menu.append(new MenuItem({ role: 'paste' }));
        this.c_menu.append(new MenuItem({ type: 'separator' }));
        this.c_menu.append(new MenuItem({ role: 'selectall' }));
        $(document).on('pagehide', '#index', () => this.hideBtnMenu());
        $(() => this.ready());
        const me = this;
        $('#btn_newprj_simple').click(function () {
            const cnv = (nm, path_nm, comp) => {
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(new RegExp('<supportedProfiles>.+?<'), '<supportedProfiles>desktop extendedDesktop<'));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace(/<antcall target="anc2">[\s\S]+?\/target>/, '<antcall target="anc2"><param name="dir_n" value="mat"/></antcall>\n\t</target>'));
                comp();
            };
            btn_newprj_sub(cnv);
        });
        $('#dlg_newprj .prj4pc').click(function () {
            const tmp = AnbData_1.AnbData.path_app_str + 'template/' + $(this).data('tmp') + '.zip';
            const cnv = (nm, path_nm, comp) => {
                m_fs.removeSync(path_nm + 'icon/');
                m_fs.removeSync(path_nm + 'mat/');
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(/<supportedProfiles>.+?</, '<supportedProfiles>desktop extendedDesktop<'));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace(/config\.anprj icon mat/g, 'config.anprj album bgimage bgm config fgimage icon image menu rule scenario system')
                    .replace('<property name="font_out" value="mat"/>', '<property name="font_out" value="system"/>'));
                me.dlTmp(tmp, fn => {
                    AnbMain.unZip(fn, path_nm, {
                        'config.anprj': buf => me.anbdt.rep_newprj_config(buf, nm),
                        'index_l.htm': buf => buf.replace(/=\"temp/g, '=\"' + nm),
                        'index.htm': buf => buf.replace(/=\"temp/g, '=\"' + nm),
                    }, comp);
                });
            };
            btn_newprj_sub(cnv);
        });
        $('#btn_newprj_uc_iphone').click(function () {
            const cnv = (nm, path_nm, comp) => {
                m_fs.removeSync(path_nm + 'icon/');
                m_fs.removeSync(path_nm + 'mat/');
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(/<icon>[\s\S]+<\/icon>/, "<icon>\n"
                    + "\t\t<image29x29>icon/icon_029.png</image29x29>\n"
                    + "\t\t<image40x40>icon/icon_040.png</image40x40>\n"
                    + "\t\t<image50x50>icon/icon_050.png</image50x50>\n"
                    + "\t\t<image57x57>icon/icon_057.png</image57x57>\n"
                    + "\t\t<image58x58>icon/icon_058.png</image58x58>\n"
                    + "\t\t<image72x72>icon/icon_072.png</image72x72>\n"
                    + "\t\t<image76x76>icon/icon_076.png</image76x76>\n"
                    + "\t\t<image80x80>icon/icon_080.png</image80x80>\n"
                    + "\t\t<image87x87>icon/icon_087.png</image87x87>\n"
                    + "\t\t<image100x100>icon/icon_100.png</image100x100>\n"
                    + "\t\t<image114x114>icon/icon_114.png</image114x114>\n"
                    + "\t\t<image120x120>icon/icon_120.png</image120x120>\n"
                    + "\t\t<image144x144>icon/icon_144.png</image144x144>\n"
                    + "\t\t<image152x152>icon/icon_152.png</image152x152>\n"
                    + "\t\t<image180x180>icon/icon_180.png</image180x180>\n"
                    + "\t\t<image512x512>icon/icon_512.png</image512x512>\n"
                    + "\t</icon>")
                    .replace("\t</initialWindow>", "\t\t<fullScreen>true</fullScreen>\n"
                    + "\t\t<autoOrients>false</autoOrients>\n"
                    + "\t\t<aspectRatio>landscape</aspectRatio>\n"
                    + "\t\t<renderMode>cpu</renderMode>\n"
                    + "\t</initialWindow>")
                    .replace("</InfoAdditions>", "</InfoAdditions>\n\t\t<requestedDisplayResolution>high</requestedDisplayResolution>\n"
                    + "\t\t<Entitlements><![CDATA[\n"
                    + "\t\t\t<key>get-task-allow</key><true/>\n"
                    + "\t\t]]></Entitlements>"));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace('-default-size 480 320', '-default-size 480 320 -source-path+=Work/システム/plgGallery')
                    .replace('<project default="do">', '<project default="do_i">')
                    .replace('<property name="font_out" value="mat"/>', '<property name="font_out" value="system"/>'));
                me.dlTmp(AnbMain.fnprj_iphone_zip, fn => {
                    AnbMain.unZip(fn, path_nm, {
                        'config.anprj': buf => me.anbdt.rep_newprj_config(buf, nm),
                    }, comp);
                });
            };
            btn_newprj_sub(cnv);
        });
        $('#btn_newprj_uc_ipad').click(function () {
            const cnv = (nm, path_nm, comp) => {
                m_fs.removeSync(path_nm + 'icon/');
                m_fs.removeSync(path_nm + 'mat/');
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(/<icon>[\s\S]+<\/icon>/, "<icon>\n"
                    + "\t\t<image29x29>icon/icon_029.png</image29x29>\n"
                    + "\t\t<image50x50>icon/icon_050.png</image50x50>\n"
                    + "\t\t<image58x58>icon/icon_058.png</image58x58>\n"
                    + "\t\t<image72x72>icon/icon_072.png</image72x72>\n"
                    + "\t\t<image76x76>icon/icon_076.png</image76x76>\n"
                    + "\t\t<image100x100>icon/icon_100.png</image100x100>\n"
                    + "\t\t<image144x144>icon/icon_144.png</image144x144>\n"
                    + "\t\t<image152x152>icon/icon_152.png</image152x152>\n"
                    + "\t\t<image512x512>icon/icon_512.png</image512x512>\n"
                    + "\t</icon>")
                    .replace("\t</initialWindow>", "\t\t<fullScreen>true</fullScreen>\n"
                    + "\t\t<autoOrients>false</autoOrients>\n"
                    + "\t\t<aspectRatio>landscape</aspectRatio>\n"
                    + "\t\t<renderMode>cpu</renderMode>\n"
                    + "\t</initialWindow>")
                    .replace("</InfoAdditions>", "</InfoAdditions>\n\t\t<requestedDisplayResolution>high</requestedDisplayResolution>\n"
                    + "\t\t<Entitlements><![CDATA[\n"
                    + "\t\t\t<key>get-task-allow</key><true/>\n"
                    + "\t\t]]></Entitlements>")
                    .replace("UIDeviceFamily</key><array><string>1", "UIDeviceFamily</key><array><string>2"));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace('<project default="do">', '<project default="do_i">')
                    .replace('-default-size 480 320', '-default-size 1024 768 -source-path+=Work/システム/plgGallery')
                    .replace('Default-Landscape@2x.png Default.png Default@2x.png', 'Default-Portrait.png')
                    .replace('<property name="font_out" value="mat"/>', '<property name="font_out" value="system"/>'));
                me.dlTmp(AnbMain.fnprj_ipad_zip, fn => {
                    AnbMain.unZip(fn, path_nm, {
                        'config.anprj': buf => me.anbdt.rep_newprj_config(buf, nm),
                    }, comp);
                });
            };
            btn_newprj_sub(cnv);
        });
        $('#btn_newprj_uc_and').click(function () {
            const cnv = (nm, path_nm, comp) => {
                m_fs.removeSync(path_nm + 'icon/');
                m_fs.removeSync(path_nm + 'mat/');
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(/<icon>[\s\S]+<\/icon>/, "<icon>\n"
                    + "\t\t<image36x36>icon/icon_036.png</image36x36>\n"
                    + "\t\t<image48x48>icon/icon_048.png</image48x48>\n"
                    + "\t\t<image72x72>icon/icon_072.png</image72x72>\n"
                    + "\t</icon>")
                    .replace("\t</initialWindow>", "\t\t<fullScreen>true</fullScreen>\n"
                    + "\t\t<autoOrients>false</autoOrients>\n"
                    + "\t\t<aspectRatio>landscape</aspectRatio>\n"
                    + "\t\t<renderMode>cpu</renderMode>\n"
                    + "\t</initialWindow>")
                    .replace("UIDeviceFamily</key><array><string>1", "UIDeviceFamily</key><array><string>2"));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace('<project default="do">', '<project default="do_a">')
                    .replace('<property name="font_out" value="mat"/>', '<property name="font_out" value="system"/>'));
                me.dlTmp(AnbMain.fnprj_and_zip, fn => {
                    AnbMain.unZip(fn, path_nm, {
                        'config.anprj': buf => me.anbdt.rep_newprj_config(buf, nm),
                    }, comp);
                });
            };
            btn_newprj_sub(cnv);
        });
        $('#btn_newplg_simple').click(function () {
            const cnv = (nm, path_nm, comp) => {
                m_fs.removeSync(path_nm + 'icon/');
                m_fs.removeSync(path_nm + 'mat/');
                const NNm = nm.charAt(0).toLocaleUpperCase()
                    + (nm.length > 1 ? nm.substr(1) : '');
                AnbData_1.AnbData.replaceTxt(path_nm + 'prj-app.xml', str => str
                    .replace(/<supportedProfiles>.+?</, "<supportedProfiles>desktop extendedDesktop<"));
                AnbData_1.AnbData.replaceTxt(path_nm + 'build.xml', str => str
                    .replace('<target name="do" depends="cmp,anc">', '<target name="do" depends="myplg_cmp,cmp,anc">')
                    .replace('plgTemp', 'plg' + NNm)
                    .replace(/<antcall target="anc2">[\s\S]+?\/target>/, '<antcall target="anc2"><param name="dir_n" value="mat"/></antcall>\n\t\t<antcall target="anc2"><param name="dir_n" value="plg"/></antcall>\n\t</target>'));
                me.dlTmp(AnbMain.fnprj_plg_zip, fn => {
                    AnbMain.unZip(fn, path_nm, {
                        'config.anprj': buf => me.anbdt.rep_newprj_config(buf, nm),
                        'mat/main.an': buf => buf.replace(/plgTemp/g, 'plg' + NNm),
                        'source/plgTemp.as': buf => buf.replace(/plgTemp/g, 'plg' + NNm),
                        'chg_fn:source/plgTemp.as': () => 'source/plg' + NNm + '.as',
                    }, comp);
                });
            };
            btn_newprj_sub(cnv);
        });
        function btn_newprj_sub(cnv) {
            const nm = String($('#txt_newprj').val());
            const res = me.anbdt.newprj(nm);
            if (res != '') {
                AnbMain.notice(res, 'error');
                return;
            }
            cnv(nm, AnbData_1.AnbData.path_unpack + nm + '/', () => {
                $['mobile'].back();
                $(document).one('pagecontainershow', (e, ui) => {
                    AnbMain.notice(nm + 'を書庫に追加しました', 'success');
                    me.addPrj(nm);
                });
            });
        }
        ;
    }
    addPrj(nm) {
        const { id: id, pb: pb } = this.anbdt.addPrj(nm);
        this.hBook[id] = pb;
        this.addLst(id, pb);
        $('input[name=raFlt]').val(['all'])['checkboxradio']('refresh');
        this.books.mixItUp('filter', '.mix');
    }
    ready() {
        this.books = $('#books');
        this.nav_ft = $('#nav_ft');
        const me = this;
        $['mobile'].defaultPageTransition = 'slide';
        $('#btnMenu').click(() => {
            this.nav_ft.slideToggle();
            this.tglSortable(false);
        });
        $('#btnEdit').click(() => {
            if (this.nav_ft.css('display') != 'none')
                return;
            $("input[name='raLstSort']")['checkboxradio']('enable');
            const is_ed = !this.books.hasClass('mode_edit');
            this.tglSortable(is_ed);
        });
        $('#lst_-1').mousedown(e => {
            if (this.nav_ft.css('display') != 'none')
                return;
            if (this.books.hasClass('mode_edit'))
                return;
            $['mobile'].pageContainer.pagecontainer('change', '#pg_-1');
        });
        $('#scIncS').on('textchange change', function () {
            const v = $(this).val();
            const cl = v ? me.books.children('[data-title*="' + v + '"],[data-creator*="' + v + '"]') : '.mix';
            me.books.mixItUp('filter', cl);
            $('input[name=raFlt]').val(['all'])['checkboxradio']('refresh');
        });
        $('#raLstList').click(() => {
            this.anbdt.sLayoutMode = 'list';
            this.books.mixItUp('changeLayout', { display: 'block' }, true, () => { this.books.removeClass('grid'); });
        });
        $('#raLstGrid').click(() => {
            this.anbdt.sLayoutMode = 'grid';
            if (!this.books.mixItUp('isLoaded')) {
                this.books.addClass('grid');
                return;
            }
            ;
            this.books.mixItUp('changeLayout', { display: 'inline-block' }, true, () => { this.books.addClass('grid'); });
        });
        const raSort1 = $('#raSort1'), raSort2 = $('#raSort2'), raSort3 = $('#raSort3');
        const raSortMy = $('#raSortMy');
        const raSortAsc = $('#raSortAsc'), raSortDesc = $('#raSortDesc');
        $('input[name=raLstSort]').click(function () {
            me.anbdt.sSortkey = $(this).data('sortkey');
            me.anbdt.sSortbtn = this.id;
            if (me.anbdt.sSortkey == 'random') {
                raSortAsc.attr('data-sort', 'random');
                raSortDesc.attr('data-sort', 'random');
            }
            else {
                raSortAsc.attr('data-sort', me.anbdt.sSortkey + ':asc');
                raSortDesc.attr('data-sort', me.anbdt.sSortkey + ':desc');
            }
        });
        raSortAsc.click(() => {
            this.anbdt.sSortOrder = 'asc';
            raSort1.attr('data-sort', 'id:asc');
            raSort2.attr('data-sort', 'title:asc');
            raSort3.attr('data-sort', 'creator:asc');
            raSortMy.attr('data-sort', 'my:asc');
        });
        raSortDesc.click(() => {
            this.anbdt.sSortOrder = 'desc';
            raSort1.attr('data-sort', 'id:desc');
            raSort2.attr('data-sort', 'title:desc');
            raSort3.attr('data-sort', 'creator:desc');
            raSortMy.attr('data-sort', 'my:desc');
        });
        $('input[name=raFlt]').click(() => { $('#scIncS').val(''); });
        $('input, textarea').on('contextmenu', e => {
            e.preventDefault();
            this.c_menu.popup({ x: e.originalEvent['x'], y: e.originalEvent['y'] });
        });
        const is_grid = (this.anbdt.sLayoutMode != 'list');
        if (is_grid) {
            $('#raLstGrid').click();
            $('input[name=raLstStyle]')['checkboxradio']('refresh');
        }
        if (this.anbdt.sSortOrder == 'asc') {
            $('#raSortAsc').click();
            $('input[name=raSort]')['checkboxradio']('refresh');
        }
        $('#' + this.anbdt.sSortbtn).click();
        $('input[name=raLstSort]')['checkboxradio']('refresh');
        raSortAsc.attr('data-sort', this.anbdt.sSortkey + ':asc');
        raSortDesc.attr('data-sort', this.anbdt.sSortkey + ':desc');
        $('[data-sdb]').each(function () {
            const t = $(this);
            me.onCtl(t, me.anbdt.getBldp(t));
        })
            .on('textchange change', function () {
            const t = $(this);
            me.anbdt.updBldp(t, t.val());
        });
        const a = this.anbdt.sMySort.split(',');
        const len = a.length;
        const initMix = () => {
            a.forEach(id => {
                if (!id)
                    return;
                const ab = this.hBook[id];
                this.addLst(id, ab);
            });
            this.books.mixItUp({
                animation: { animateChangeLayout: true },
                layout: { display: is_grid ? 'inline-block' : 'block' },
                load: {
                    sort: this.anbdt.sSortkey + ':' + this.anbdt.sSortOrder
                },
            })
                .sortable({
                disabled: true,
                placeholder: 'ui-state-highlight',
                items: '.mix',
                revert: 150,
                cursor: 'move',
                opacity: 0.8,
                tolerance: 'pointer',
                update: function (event, ui) {
                    me.books.children().each(function (i, e) {
                        $(e).attr('data-my', (me.cntBook - i).toString());
                    });
                    raSortMy.click();
                    $("input[name='raLstSort']")['checkboxradio']('refresh')['checkboxradio']("disable");
                    me.anbdt.sMySort = me.books.sortable('toArray').join(',');
                },
            });
            this.tooltip('lst_-1');
            electron_1.ipcRenderer.on('invoke', (e, cl) => { this.invoke(e, cl); });
        };
        if (len < 10)
            initMix();
        else {
            const noty = new Noty({
                type: 'info',
                layout: 'center',
                text: 'Loading ...',
                modal: true,
            });
            noty.on('afterShow', () => {
                initMix();
                Noty.closeAll();
            });
            noty.show();
        }
    }
    tglSortable(b) {
        this.books.toggleClass('mode_edit', b).sortable({ disabled: !b });
        $('#btnEdit').toggleClass('ui-btn-active', b);
    }
    tooltip($id) {
        const me = this;
        $($id)['tooltip']({
            content: function () {
                return (me.anbdt.sLayoutMode == 'grid') ? $(this).data('title') : null;
            },
            position: { my: 'left top', at: 'left bottom' }
        });
    }
    onCtl(t, v) {
        if (t.is('[data-role="controlgroup"]')) {
            t.find('input[value="' + v + '"]').attr('checked', true)['checkboxradio']('refresh');
            return;
        }
        t.val(v);
        if (t.is('[data-role="flipswitch"]')) {
            t.flipswitch().flipswitch('refresh');
        }
        else
            t.text(v);
    }
    hideBtnMenu() { if (this.nav_ft.css('display') != 'none')
        this.nav_ft.hide(); }
    invoke(e, cl) {
        const len = cl.length;
        if (len == 0)
            return;
        const c0 = Array.isArray(cl[0]) ? cl[0][0] : cl[0];
        if (c0 == 'app.nw' || c0 == './')
            return;
        const retF = new RegExp(/termf="(.+)"/).exec(c0);
        if (retF) {
            this.addTerm(m_fs.readFileSync(AnbData_1.AnbData.path_app_str + retF[1], { encoding: 'utf8' }));
            return;
        }
        const retB = new RegExp(/break="(.+)"/).exec(c0);
        if (retB) {
            const sB = retB[1].replace(/'/g, '"');
            if (this.win_ane) {
                this.win_ane.webContents.send('break_wait', sB);
                return;
            }
            const oB = JSON.parse(sB);
            const w = new me_bw({
                title: 'スクリプト：' + oB.fn + '.an【' + oB.nm + 'プロジェクト】',
                acceptFirstMouse: true,
                webPreferences: {
                    textAreasAreResizable: false,
                },
            });
            w.webContents.on('dom-ready', function () {
            });
            w.webContents.on('did-finish-load', () => {
                if (this.win_ane)
                    this.win_ane.close();
                this.win_ane = w;
                this.win_ane.webContents.send('break_wait', sB);
            });
            w.loadURL('file://' + AnbData_1.AnbData.path_app_nw + 'ane.htm');
            w.on('close', () => { this.win_ane = null; this.closeWin(); });
            return;
        }
        const ext = m_path.extname(c0).slice(1);
        switch (ext) {
            case 'anbook':
            case 'anbzip':
                break;
            default:
                AnbMain.notice('サポートされない形式[' + ext + ']です', 'error');
                return;
        }
        const path_wk = AnbData_1.AnbData.path_app_str + 'tmp/anbook/';
        m_fs.removeSync(path_wk);
        AnbMain.unZip(c0, path_wk, undefined, () => {
            let nm = m_path.basename(c0, m_path.extname(c0));
            m_fs.readdirSync(path_wk).forEach(f => {
                nm = f;
            });
            let id_already_nm = null;
            for (let id in this.hBook) {
                if (this.hBook[id].fn == nm) {
                    id_already_nm = id;
                    break;
                }
            }
            const mov = (to_nm, is_rep) => {
                m_fs.move(path_wk + nm, AnbData_1.AnbData.path_unpack + to_nm, { overwrite: true }, err => {
                    if (err) {
                        AnbMain.noticeErr(err);
                        return;
                    }
                    ;
                    AnbMain.notice(to_nm + 'を' + (is_rep ? '上書き' : '書庫に追加')
                        + 'しました', 'success');
                    this.addPrj(to_nm);
                });
            };
            if (id_already_nm == null) {
                mov(nm, false);
                return;
            }
            const n = new Noty({
                type: 'alert',
                layout: 'center',
                text: m_path.basename(c0) + 'を追加しようとしましたが、<br/>同名フォルダのプロジェクト ' + nm + ' があります',
                closeWith: ['click'],
                modal: true,
                buttons: [
                    Noty.button('上書きする', 'ui-btn ui-btn-b ui-corner-all', () => {
                        Noty.closeAll();
                        this.anbdt.delPrj(id_already_nm);
                        delete this.hBook[id_already_nm];
                        $('#' + id_already_nm).remove();
                        mov(nm, true);
                    }),
                    Noty.button('別名で追加', 'ui-btn ui-btn-a ui-corner-all', () => {
                        Noty.closeAll();
                        mov(nm + (new Date())['toFormat']('_YYYYMMDD_HH24MISS'), false);
                    }),
                    Noty.button('Cancel', 'ui-corner-all', () => Noty.closeAll()),
                ],
            }).show();
            var n2 = new Noty({
                text: 'Do you want to continue? <input id="example" type="text">',
                buttons: [
                    Noty.button('YES', 'btn btn-success', function () {
                        console.log('button 1 clicked');
                    }, { id: 'button1', 'data-status': 'ok' }),
                    Noty.button('NO', 'btn btn-error', function () {
                        console.log('button 2 clicked');
                        Noty.closeAll();
                    })
                ]
            }).show();
        });
    }
    static noticeErr(text) { AnbMain.notice(text, 'error'); }
    static notice(txt, type = 'info', afterShow = undefined) {
        const noty = new Noty({
            layout: 'topRight',
            text: txt,
            timeout: 5000,
            closeWith: ['click'],
        });
        if (afterShow)
            noty.on('afterShow', afterShow);
        noty.show();
    }
    static alertYN(txt, yes) {
        const n = new Noty({
            type: 'alert',
            layout: 'center',
            text: txt,
            closeWith: ['click'],
            modal: true,
            buttons: [
                Noty.button('Ok', 'ui-btn ui-btn-b ui-corner-all', () => yes(n)),
                Noty.button('Cancel', 'ui-btn ui-btn-a ui-corner-all', () => Noty.closeAll())
            ],
        }).show();
    }
    static dlgDL(txt, cancel) {
        AnbMain.notyDlgDL = new Noty({
            type: 'info',
            layout: 'center',
            text: txt,
            closeWith: ['click'],
            modal: true,
            buttons: [
                Noty.button('Cancel', 'ui-btn ui-btn-b ui-corner-all', () => cancel()),
            ],
            callbacks: {
                onClose: () => { Noty.closeAll(); AnbMain.notyDlgDL = null; },
            },
        }).show();
    }
    static dlgDL_setText(text) {
        if (AnbMain.notyDlgDL)
            AnbMain.notyDlgDL.setText(text);
        else
            AnbMain.dlgDL(text, () => { });
    }
    static dlgDL_close() { if (AnbMain.notyDlgDL)
        AnbMain.notyDlgDL.close(); }
    static unZip(fn, path, hCnv = {}, close) {
        const zip = new AdmZip(fn);
        zip.extractAllTo(path, true);
        zip.getEntries().forEach(ze => {
            const cnv = hCnv[ze.entryName];
            if (cnv)
                m_fs.writeFileSync(m_path.join(path, ze.entryName), cnv(ze.getData().toString('utf8')));
        });
        zip.getEntries().forEach(ze => {
            const chg_fn = hCnv['chg_fn:' + ze.entryName];
            if (chg_fn)
                m_fs.move(m_path.join(path, ze.entryName), m_path.join(path, chg_fn(undefined)), err => { if (err)
                    return AnbMain.addLog(err); });
        });
        close();
    }
    static dropDust(fn) { electron_1.shell.moveItemToTrash((AnbData_1.AnbData.is_mac ? '' : 'file://') + fn); }
    ;
    static addLog(txt) {
        if (!AnbMain.guiWin.webContents.isDevToolsOpened())
            AnbMain.guiWin.webContents.openDevTools();
        if (window && window.console)
            console.log(txt);
    }
    static setClipboard(txt) {
        electron_1.clipboard.writeText(txt);
        AnbMain.notice('クリップボードへコピーしました');
    }
    addLst(id, ab) {
        this.hideBtnMenu();
        const fn_icon = m_fs.existsSync(AnbData_1.AnbData.path_unpack + ab.fn + '/icon.jpg')
            ? 'file://' + AnbData_1.AnbData.path_unpack + ab.fn + '/icon.jpg'
            : 'file://' + AnbData_1.AnbData.path_app_nw + 'mat/menu_def_icon.jpg';
        const h_pt = {
            '': '',
            'Plugin': '<i class="icn_pt fa fa-puzzle-piece fa-lg"></i>',
            'IOS': '<i class="icn_pt fa fa-apple fa-lg"></i>',
            'AND': '<i class="icn_pt fa fa-android fa-lg"></i>',
        };
        const htm_pt = h_pt[ab.prjtype], $id = '#' + id;
        this.books.prepend('<li id="' + id + '" class="mix can_edit pt_' + (ab.prjtype || '') + '" data-id="' + id + '" data-title="' + ab.title + '" data-creator="' + ab.creator + '" data-my="' + ++this.cntBook + '" title=""><div style="background-image:url(\'' + fn_icon + '\');"></div><h3>' + ab.title + '</h3><p>【' + ab.creator + '】' + ab.detail + '</p><p class="ui-li-aside">' + ab.fn + '</p><a class="btndel" data-icon="delete" data-role="button" data-mini="true" data-inline="true" data-iconpos="notext"></a>' + htm_pt + '</li>')
            .trigger('create');
        $($id).on('mousedown', e => {
            if (this.nav_ft.css('display') != 'none')
                return;
            if (this.books.hasClass('mode_edit'))
                return;
            if (!(ab instanceof PrjBook_1.PrjBook))
                this.hBook[id] = new PrjBook_1.PrjBook(ab.fn, id, this.anbdt);
            if (e.which == 3) {
                if (ab.prjtype)
                    this.btnProc(id, '');
                else
                    this.btnProc(id, '_per', e);
            }
            else if (id in this.hisInitedDetail) {
                $['mobile'].pageContainer.pagecontainer('change', '#pg_' + id);
            }
            else {
                this.hisInitedDetail[id] = true;
                $($id).one('mouseup', e => $['mobile'].pageContainer.pagecontainer('change', '#pg_' + id));
                this.addDetail(id, ab, fn_icon);
            }
        }).find('.btndel').click(() => {
            AnbMain.alertYN('プロジェクト「' + ab.title + '」を削除しますか？（ゴミ箱に捨てます）', nt => {
                this.anbdt.delPrj(id);
                delete this.hBook[id];
                $('#' + id).remove();
                nt.close();
            });
        });
        this.tooltip($id);
    }
    addDetail(id, ab, fn_icon) {
        let tmp = '\
	<div data-role="page" id="pg_' + id + '" class="book_d">\
		<div data-role="header" data-position="fixed" data-tap-toggle="false" data-theme="b">\
			<a data-icon="arrow-l" data-rel="back">書庫</a>\
			<h1 data-dsp="title"></h1>\
			<a id="pg_' + id + '_ed" data-icon="edit">編集</a>\
		</div>\
	<div data-role="content">\
	<div data-role="collapsible-set">'
            + '<div data-role="collapsible" data-collapsed="false">\
		<h3>プロジェクト情報 -- ' + ab.fn + '</h3>\
		<ul id="books_d' + id + '" data-role="listview" data-inset="true">\
			<li data-icon="bars"><a data-btn="_title" class="nw_title"><img id="pg_' + id + '_icon" src="' + fn_icon + '"/><h3 data-dsp="title"></h3></a></li>\
			<li data-role="list-divider" class="tgl" style="display:none">プロジェクト情報</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_title">タイトル</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_anbook_title" value="" placeholder="タイトル名" data-dsp="title" data-upd/>\
			</li>\
	\
			<li class="tgl">著作者<span class="ui-li-aside' + (ab.cre_url ? ' books_dlst_link' : '')
            + '" data-btn="_creator" data-dsp="creator"></span>'
            + ((ab.cre_url && String(ab.cre_url).indexOf('//twitter.com/') >= 0)
                ? '<span class="ui-li-count"><img src="mat/icon_twitter.png"/></span>' : '')
            + '</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_creator">著作者</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_anbook_creator" value="" placeholder="ペンネーム、ハンドルネームなど" data-dsp="creator" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_cre_url">著作者URL</label>\
				<input type="url" data-mini="true" data-clear-btn="false" id="txt_gear' + id + '_anbook_cre_url" value="" placeholder="連絡先URL。Twitterなど" data-dsp="cre_url" data-upd/>\
			</li>\
	\
			<li class="tgl">出版者<span class="ui-li-aside' + (ab.pub_url ? ' books_dlst_link' : '')
            + '" data-btn="_publisher" data-dsp="publisher"></span>'
            + ((ab.pub_url && String(ab.pub_url).indexOf('//twitter.com/') >= 0)
                ? '<span class="ui-li-count"><img src="mat/icon_twitter.png"/></span>' : '')
            + '</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_publisher">出版者</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_anbook_publisher" value="" placeholder="サークル名、団体名など" data-dsp="publisher" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_pub_url">出版者URL</label>\
				<input type="url" data-mini="true" id="txt_gear' + id + '_anbook_pub_url" value="" placeholder="連絡先URL。Twitterなど" data-clear-btn="false" data-dsp="pub_url" data-upd/>\
			</li>\
	\
			<li class="tgl"><h3>内容</h3><p style="white-space: normal" data-dsp="detail"></p></li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_detail">内容</label>\
				<textarea cols="40" rows="8" data-mini="true" id="txt_gear' + id + '_anbook_detail" placeholder="プロジェクトの説明" data-dsp="detail" data-upd></textarea>\
			</li>\
	\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_anbook_version">バージョン</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_version" value="" placeholder="小数でも可" data-dsp="version" data-upd/>\
			</li>\
	\
			<li data-role="list-divider" class="tgl" style="display:none">ゲームの初期状態</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<p style="font-size:medium">最初に呼び出すスクリプト</p>\
				<label for="txt_gear' + id + '_first_script_fn"></label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_first_script_fn" value="" placeholder="anスクリプトファイル名。拡張子省略推奨" data-dsp="first_script_P_fn" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_init_bg_color">背景色</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_init_bg_color" value="" placeholder="省略時は 0x000000（黒）" data-dsp="init_P_bg_color" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<p style="font-size:medium">通常文字表示待ち時間 (ms)</p>\
				<label for="txt_gear' + id + '_init_tagch_msecwait"></label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_init_tagch_msecwait" value="" placeholder="インストール直後の初期値。未読／既読兼用" data-dsp="init_P_tagch_msecwait" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<p style="font-size:medium">自動文字表示での行クリック待ち時間 (ms)</p>\
				<label for="txt_gear' + id + '_init_auto_msecpagewait"></label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_init_auto_msecpagewait" value="" placeholder="インストール直後の初期値。未読／既読兼用" data-dsp="init_P_auto_msecpagewait" data-upd/>\
			</li>\
	\
			<li data-role="list-divider" class="tgl" style="display:none">アプリウインドウ設定</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_window_width">横幅 (px)</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_window_width" value="" placeholder="1〜、アプリウインドウの横幅を指定" data-dsp="window_P_width" data-upd/>\
			</li>\
			<li data-role="fieldcontain" class="tgl" style="display:none">\
				<label for="txt_gear' + id + '_window_height">高さ (px)</label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_window_height" value="" placeholder="1〜、アプリウインドウの高さを指定" data-dsp="window_P_height" data-upd/>\
			</li>\
	\
			<li data-role="list-divider" class="tgl" style="display:none">プロジェクトの実行</li>\
			<li data-icon="action">'
            + (ab.prjtype
                ? 'ビルドかコマンドライン実行のみ可能です'
                : '<a data-btn="_per">最初から読む（疑似環境実行・右ｸﾘｯｸで詳細ﾓｰﾄﾞ)</a>')
            + '</li>';
        switch (ab.prjtype) {
            case 'IOS':
                tmp += '\
			<li data-icon="action" data-theme="b"><a data-btn="">【ant do_i】iOS版をビルド＆実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_i4">【ant do_i4】iOS版（iPhone4 Retina環境）実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_i5">【ant do_i5】iOS版（iPhone5 Retina環境）実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_i6">【ant do_i6】iOS版（iPhone6環境）実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_i6p">【ant do_i6p】iOS版（iPhone6 Plus環境）実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_ip">【ant do_ip】iOS版（iPad環境）実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_ip3">【ant do_ip3】iOS版（iPad3 Retina環境）実行</a></li>';
                break;
            case 'AND':
                tmp += '\
			<li data-icon="action" data-theme="b"><a data-btn="">【ant do_a_no】NexusOne 480 x 800 実行</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="do_a_sgt">【ant do_a_sgt】GalaxyTab 600 x 1024 実行</a></li>';
                break;
            default:
                tmp += '\
		</ul>\
	\
		<ul data-role="listview" data-inset="true">\
			<li data-icon="action" data-theme="b"><a data-btn="">【ant】ターミナルでビルド＆実行</a></li>\
			<li data-icon="shop"><a data-btn="_mk_nw">OS個別・簡易アプリ生成（exe、app)</a></li>';
        }
        tmp += '\
			</li>\
		</ul>\
	</div>';
        tmp += '\
	<div data-role="collapsible">\
		<h3>プロジェクトフォルダ設定</h3>\
		<ul id="books_sp' + id + '" data-role="listview" data-inset="true">\
			<li data-role="list-divider">ファイル・フォルダをパッケージに含むか</li>\
	\
			<li data-role="fieldcontain">\
			<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
				<legend>build.xml</legend>\
				<input type="radio" name="books_sp999_f0" id="books_sp999_f0n" value="n" checked="checked"/>\
				<label for="books_sp999_f0n">無視</label>\
				<input type="radio" name="books_sp999_f0" id="books_sp999_f0p" value="p"/>\
				<label for="books_sp999_f0p">含める</label>\
				<input type="radio" name="books_sp999_f0" id="books_sp999_f0a" value="a"/>\
				<label for="books_sp999_f0a">anbookだけ</label>\
			</fieldset>\
			</li>\
		</ul>\
	</div>';
        switch (ab.prjtype) {
            case 'IOS': break;
            default:
                tmp += '\
		<div data-role="collapsible">\
		<h3>素材暗号化</h3>\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
				<label for="txt_ba' + id + '_code_key">暗号化キー</label>\
				<input type="text" data-mini="true" id="txt_ba' + id + '_code_key" value="" disabled="disabled" data-dsp="bld_xml_code_key"/>\
			</li>\
	\
			<li data-icon="refresh"><a data-btn="_code_key">暗号化キーを自動生成</a></li>\
		</ul>\
			<small>※暗号化キーを変更すると、次のビルド時に全暗号化ファイルを再暗号化します。ファイル数が多いと処理に時間が掛かります。</small><br/>\
	\
			<br/>\
			<label for="txt_ba' + id + '_nocode_reg">暗号化対象外ファイル名パターン</label>\
			<input type="text" data-mini="true" id="txt_ba' + id + '_nocode_reg" value="" placeholder="暗号化しないファイル名にマッチする正規表現" data-dsp="nocode_reg" data-upd/>\
			<small>※暗号化処理時は、元素材をWork/before_anc下へ移動します</small>\
	\
			<ul id="books_ba' + id + '" data-role="listview" data-inset="true">\
				<li data-role="list-divider">フォルダ単位の暗号化</li>\
				<li data-role="fieldcontain">\
				<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
					<legend>mat/</legend>\
					<input type="radio" name="books_anc999_a0" id="books_anc999_a0n" value="n" checked="checked"/>\
					<label for="books_anc999_a0n">しない</label>\
					<input type="radio" name="books_anc999_a0" id="books_anc999_a0a" value="a"/>\
					<label for="books_anc999_a0a">する</label>\
				</fieldset>\
				</li>\
			</ul>\
		</div>';
        }
        tmp += '\
	<div data-role="collapsible">\
		<h3>実行形式パッケージ（*.air、ipa、apkなど）生成</h3>\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
			<fieldset data-role="controlgroup" data-mini="true" id="books_ba' + id + '_font_out" data-dsp="bld_xml_font_out" data-upd>\
				<legend>swf出力先</legend>\
				<input type="radio" name="books_ba' + id + '_fo" id="books_ba' + id + '_fo_mat" value="mat"/>\
				<label for="books_ba' + id + '_fo_mat">mat</label>\
				<input type="radio" name="books_ba' + id + '_fo" id="books_ba' + id + '_fo_system" value="system"/>\
				<label for="books_ba' + id + '_fo_system">system</label>\
			</fieldset>\
			</li>\
	\
			<li data-icon="refresh"><a data-btn="font">【ant font】フォントswfビルド（最低限の文字で）</a></li>\
			<li data-icon="refresh"><a data-btn="font_all">【ant font_all】フォントswfビルド（全文字を含む）</a></li>\
		</ul>\
	\
	\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
				<p style="font-size:medium">oggファイルをoggo変換するか</p>\
				<select data-mini="true" data-role="flipswitch" data-dsp="bld_xml_cnv_oggo" data-upd>\
					<option value="false">しない</option>\
					<option value="true">する</option>\
				</select>\
			</li>\
		</ul>\
	\
	\
		<ul data-role="listview" data-inset="true">';
        switch (ab.prjtype) {
            case 'IOS':
                tmp += '\
			<li data-icon="shop"><a data-btn="ipi">【ant ipi】実機テスト用高速ビルド（*-ipi.ipa)</a></li>\
			<li data-icon="shop" data-theme="b"><a data-btn="ip">【ant ip】実機テスト用ビルド（*-ip.ipa)</a></li>\
			<li data-icon="shop" data-theme="b"><a data-btn="ip_appstore">【ant ip_appstore】AppStore配布用ビルド</a></li>';
                if (navigator.platform.indexOf('Mac') >= 0)
                    tmp += '\
			<li data-icon="info"><a data-btn="ip_itc_chk">配布用アプリを iTunes Connect で検査（Xcode必須）</a></li>\
			<li data-icon="info"><a data-btn="ip_itc_upl">配布用アプリを iTunes Connect に送信（Xcode必須）</a></li>';
                break;
            case 'AND':
                tmp += '\
			<li data-icon="shop" data-theme="a"><a data-btn="apk">【ant apk】apkパッケージビルド（apk)</a></li>\
			<li data-icon="action" data-theme="b"><a data-btn="ir">【ant ir】ビルド＆実機にインストール</a></li>';
                break;
            default:
                tmp += '\
			<li data-icon="shop"><a data-btn="local">【ant local】ブラウザ向けビルド</a></li>\
			<li data-icon="shop" data-theme="b"><a data-btn="air">【ant air】Adobe AIRパッケージ（air)</a></li>\
			<li data-icon="shop"><a data-btn="air_r">【ant air_r】OS個別インストーラー（exe、dmg)</a></li>\
			<li data-icon="shop"><a data-btn="air_b">【ant air_b】OS個別RTバンドルパッケージ（exe、dmg)</a></li>';
        }
        tmp += '\
		</ul>\
	</div>'
            + '<div data-role="collapsible">\
		<h3>anbookパッケージ（*.anbook）</h3>\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
				<label for="tgl_gear' + id + '_anbook_nocode">暗号化</label>\
				<select data-mini="true" id="tgl_gear' + id + '_anbook_nocode" data-role="flipswitch" data-dsp="nocode" data-upd>\
					<option value="">する</option>\
					<option value="true">しない</option>\
				</select>\
			</li>\
			<li data-role="fieldcontain">\
				<p style="font-size:medium">パックに含めないファイル名パターン (<a onclick="openURL(\'http://help.adobe.com/ja_JP/as3/dev/WS5b3ccc516d4fbf351e63e3d118a9b90204-7ea9.html\')">正規表現</a>)</p>\
				<label for="txt_gear' + id + '_anbook_pack_exc"></label>\
				<input type="text" data-mini="true" id="txt_gear' + id + '_anbook_pack_exc" value="" placeholder="ファイル・フォルダ名の正規表現" data-dsp="pack_exc" data-upd/>\
			</li>\
			<li data-role="fieldcontain">\
				<label for="tgl_gear' + id + '_anbook_rotate">画面回転</label>\
				<select data-mini="true" id="tgl_gear' + id + '_anbook_rotate" data-role="flipswitch" data-dsp="rotate" data-upd>\
					<option value="">なし</option>\
					<option value="true">する</option>\
				</select>\
			</li>\
			<li data-icon="grid" data-theme="b"><a data-btn="_pack">anbook形式にパック（配布用）</a></li>\
			<li data-icon="heart"><a data-btn="_pack_full">anbzip形式に丸ごとバックアップ</a></li>'
            + (ab.dl_url ? ('<li data-icon="alert"><a data-btn="_re_dl">作品アップデート<span class="ui-li-aside"></span></a></li>') : '') + '\
		</ul>\
	</div>'
            + '<div data-role="collapsible" id="bld' + id + '">\
		<h3>拡張ビルド</h3>\
		<ul data-role="listview" data-inset="true" data-theme="b">\
			<li data-icon="info"><a data-btn="chk_env">開発環境情報の表示</a></li>\
		</ul>\
		<ul data-role="listview" data-inset="true" data-theme="b">\
		<li data-icon="info"><a data-btn="chk_key_lifespan">署名有効期限の表示</a></li>\
	</ul>\
\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
				<p style="font-size:medium">ターゲット名を指定してant実行</p>\
				<input id="inp_' + id + '_free" type="text" value="" placeholder="ターゲット名（例：h …ターゲット一覧）"/>\
			</li>\
			<li data-icon="alert"><a id="bld_' + id + '_free" data-btn="_ant_free" data-arg="">上記のantを実行</a></li>\
		</ul>\
	\
		<ul data-role="listview" data-inset="true">\
			<li data-role="fieldcontain">\
				<p style="font-size:medium">ビルド時にAIRNovelソースを最新に自動更新</p>\
				<select data-mini="true" data-role="flipswitch" data-dsp="upd_an" data-upd>\
					<option value="false">しない</option>\
					<option value="true">する</option>\
				</select>\
			</li>\
			<li data-icon="gear" data-theme="b"><a data-btn="upd_an">プロジェクトのAIRNovelソース更新</a></li>\
			<li data-icon="gear" data-theme="b"><a data-btn="AIRlib_dl_sub">共通のAIRNovelライブラリを更新</a></li>\
			<li data-icon="alert"><a data-btn="flexsdk">Apache Flexを最新Verへ更新</a></li>\
			<li data-icon="alert"><a data-btn="airsdk">Adobe AIR SDKを最新Verへ更新</a></li>\
		</ul>\
	</div>'
            + '<div data-role="collapsible">\
		<h3>ツール</h3>\
		<ul data-role="listview" data-inset="true" data-theme="a">\
			<li data-icon="info"><a data-btn="_path_opn">フォルダをエクスプローラーやFinderで開く</a></li>\
			<li data-icon="info"><a data-btn="_path_cpy">フォルダ絶対パスをクリップボードへ</a></li>\
		</ul>\
			</div>\
	\
		</div>'
            + '</div>'
            + '</div>';
        $('body').append(tmp);
        const me = this;
        $('#pg_' + id + '_ed').click(function () {
            $('#books_d' + id + ' >li.tgl').slideToggle();
            me.initDetail(id);
        });
        $('#pg_' + id + ' [data-upd]').on('change', function (e) {
            if (!me.upd_event)
                return;
            const t = $(this);
            const k = t.data('dsp');
            const v = t.is('[data-role="controlgroup"]')
                ? t.find('input:checked').val()
                : t.val();
            const pb = me.hBook[id];
            pb[k] = v;
            me.redrawDetail(id, k, v);
        });
        $('#pg_' + id + ' [data-role="flipswitch"][data-upd]').on('change', function () {
            if (!me.upd_event)
                return;
            const t = $(this);
            const k = t.data('dsp');
            const v = t.val();
            const pb = me.hBook[id];
            pb[k] = v;
        });
        const pg = $('#pg_' + id);
        pg.find('[data-btn]').mousedown(function (e) {
            me.btnProc(id, $(this).data('btn'), e);
        });
        $('[data-role="flipswitch"]')['flipswitch']();
        pg.find('input, textarea').on('contextmenu', e => {
            e.preventDefault();
            this.c_menu.popup({ x: e.originalEvent['x'], y: e.originalEvent['y'] });
        });
        this.initDetail(id);
    }
    redrawDetail(id, k, v) {
        const ab = this.hBook[id];
        const pb = ab;
        switch (k) {
            case 'title':
                if (v === undefined)
                    v = ab[k];
                $('#' + id).attr('data-title', v).children('h3').text(v);
                $('#txt_gear' + id + '_anbook_title').val(v);
                break;
            case 'version':
                if (v === undefined)
                    v = ab.version;
                $('#txt_gear' + id + '_' + k).val(v);
                break;
            case 'fn':
                if (v === undefined)
                    v = pb.first_script_P_fn;
                $('#txt_gear' + id + '_first_script_' + k).val(v);
                break;
            case 'bg_color':
            case 'tagch_msecwait':
            case 'auto_msecpagewait':
                if (v === undefined)
                    v = pb['init_P_' + k];
                $('#txt_gear' + id + '_init_' + k).val(v);
                break;
            case 'width':
            case 'height':
                if (v === undefined)
                    v = pb['window_P_' + k];
                $('#txt_gear' + id + '_window_' + k).val(v);
                break;
            case 'upd_an':
                break;
            case 'font_out':
            case 'cnv_oggo':
                break;
            case 'creator':
            case 'detail':
                $('#' + id).attr('data-creator', ab.creator).attr('data-detail', ab.detail).children('p:first').text('【' + ab.creator + '】' + ab.detail);
            default:
                if (v === undefined)
                    v = pb[k];
                $('#txt_gear' + id + '_anbook_' + k).val(v);
        }
        const pg = $('#pg_' + id);
        pg.find('[data-dsp="' + k + '"]').val(v).text(v);
        if ((k in ab) && (k != 'fn'))
            ab[k] = v;
    }
    replaceIcon(id) {
        let fn = AnbData_1.AnbData.path_unpack + this.hBook[id].fn + '/icon.jpg';
        if (!m_fs.existsSync(fn)) {
            fn = 'mat/menu_def_icon.jpg';
        }
        else
            fn = 'file://' + fn;
        fn = fn + '?' + (new Date().getTime());
        const img = $('#' + id + ' >div:first');
        img.css('background-image', "url('" + fn + "')");
        $('#pg_' + id + '_icon').attr('src', fn);
    }
    initDetail(id) {
        this.replaceIcon(id);
        if (!(this.hBook[id] instanceof PrjBook_1.PrjBook))
            return;
        const pb = this.hBook[id];
        this.upd_event = false;
        $('#pg_' + id + ' [data-dsp]').each(function () {
            const t = $(this);
            const v = pb.dataGet(t.data('dsp'));
            putCtl(t, v);
        });
        this.upd_event = true;
        function putCtl(t, v) {
            if (t.is('[data-role="controlgroup"]')) {
                t.find('input[value="' + v + '"]').attr('checked', true)['checkboxradio']()['checkboxradio']('refresh');
                return;
            }
            t.val(v);
            if (t.is('[data-role="flipswitch"]'))
                t.flipswitch().flipswitch('refresh');
            else
                t.text(v);
        }
        let sp = '<li data-role="list-divider" class="ui-first-child ui-li-static ui-body-inherit ui-field-contain">ファイル・フォルダを配布パッケージに含むか</li>';
        $.each(pb.prjFoldDB, (i, o) => {
            const n = 'books_sp' + id + '_' + i;
            sp += '\
			<li data-role="fieldcontain" class="ui-li-static ui-body-inherit">\
			<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
				<legend>' + o.fn + '</legend>\
				<input type="radio" name="' + n + '" id="' + n + 'n" value="n"' + (o.value == 'n' ? ' checked="checked"' : '') + (o['n_enabled'] != false && o['enabled'] != false ? '' : ' disabled="disabled"') + ' data-fld="' + o['path'] + '"/><label for="' + n + 'n">含まない</label>\
				<input type="radio" name="' + n + '" id="' + n + 'p" value="p"' + (o['value'] == 'p' ? ' checked="checked"' : '') + (o['p_enabled'] != false && o['enabled'] != false ? '' : ' disabled="disabled"') + ' data-fld="' + o['path'] + '"/><label for="' + n + 'p">含める</label>\
				<input type="radio" name="' + n + '" id="' + n + 'a" value="a"' + (o['value'] == 'a' ? ' checked="checked"' : '') + (o['a_enabled'] != false && o['enabled'] != false ? '' : ' disabled="disabled"') + ' data-fld="' + o['path'] + '"/><label for="' + n + 'a">anbookだけ</label>\
			</fieldset>\
			</li>';
        });
        $('#books_sp' + id).html(sp).trigger('create').find('input').change(function (e) {
            const t = $(this);
            pb.setPrjFoldDB(t.data('fld'), t.val().toString());
        });
        $('#books_sp' + id + ' >li:last').addClass('ui-last-child');
        let ba = '<li data-role="list-divider" class="ui-first-child ui-li-static ui-body-inherit ui-field-contain">フォルダ単位の暗号化</li>';
        $.each(pb.codeFoldDB, (i, oD) => {
            const n = 'books_ba' + id + '_' + i;
            const ds = (oD.disabled ? ' disabled="disabled"' : '');
            ba +=
                '<li data-role="fieldcontain" class="ui-li-static ui-body-inherit">\
				<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">\
					<legend>' + oD.nm + '</legend>\
					<input type="radio" name="' + n + '" id="' + n + 'n" value="n"' + (oD.code ? '' : ' checked="checked"') + ds + ' data-fld="' + oD.nm + '"/>\
					<label for="' + n + 'n">しない</label>\
					<input type="radio" name="' + n + '" id="' + n + 'a" value="a"' + (oD.code ? ' checked="checked"' : '') + ds + ' data-fld="' + oD.nm + '"/>\
					<label for="' + n + 'a">する</label>\
				</fieldset>\
				</li>';
        });
        $('#books_ba' + id).html(ba).trigger('create')
            .find('input').change(function (e) {
            const t = $(this);
            pb.setCodeFoldDB(t.data('fld'), t.val());
        });
        $('#books_ba' + id + ' >li:last').addClass('ui-last-child');
    }
    btnProc(id, btn, e = {}) {
        const pb = this.hBook[id];
        switch (btn) {
            case '_title': if (e['which'] == 3) {
                AnbMain.setClipboard(AnbData_1.AnbData.path_unpack + pb.fn);
                break;
            }
            case '_path_opn':
                openURL('file://' + AnbData_1.AnbData.path_unpack + pb.fn);
                break;
            case '_path_cpy':
                AnbMain.setClipboard(AnbData_1.AnbData.path_unpack + pb.fn);
                break;
            case '_creator':
                openURL(pb.cre_url);
                break;
            case '_publisher':
                openURL(pb.pub_url);
                break;
            case '_code_key':
                AnbMain.alertYN('暗号化キーを再生成しますか？（後のビルド時、全ての素材暗号化をやり直します）', nt => {
                    const code_key = AnbData_1.AnbData.create_pwd();
                    pb.bld_xml_code_key = code_key;
                    $('#txt_ba' + id + '_code_key').val(code_key);
                    $.each(pb.codeFoldDB, (i, o) => {
                        if (!o.code)
                            return;
                        pb.setCodeFoldDB(o.nm, 'n');
                        pb.setCodeFoldDB(o.nm, 'a');
                    });
                    nt.close();
                });
                break;
            case '_mk_nw':
                this.onMake_app(id);
                break;
            case '_per':
                if (!pb.existsCfg) {
                    AnbMain.notice('config.anprj がありません');
                    break;
                }
                const is_detail = (e['which'] == 3);
                const doNoBld = () => {
                    this.addLogHead('疑似環境実行' + (is_detail ? '【詳細モード】' : ''), pb);
                    this.goNoBld(pb, is_detail);
                };
                if (!this.win_term) {
                    doNoBld();
                    break;
                }
                this.win_term.webContents.on('close', doNoBld);
                this.closeWin();
                break;
            case '_pack':
                pb.pack_anbook();
                break;
            case '_pack_full':
                pb.zip_full();
                break;
            case '_ant_free': btn = String($('#inp_' + id + '_free').val());
            default:
                if (this.win_term) {
                    this.win_term.on('closed', () => {
                        this.addLogHead('ビルド実行', pb);
                        this.doNativeProcessAnt(pb.fn, btn);
                    });
                    this.closeWin();
                    break;
                }
                this.addLogHead('ビルド実行', pb);
                this.doNativeProcessAnt(pb.fn, btn);
                break;
        }
    }
    ;
    closeWin() {
        if (this.win_term) {
            this.win_term.close();
            this.win_term = null;
        }
        if (this.win_ane) {
            this.win_ane.close();
            this.win_ane = null;
        }
        if (this.ls) {
            this.ls.kill();
            this.ls = null;
        }
        this.strBuf = '';
    }
    addLogHead(txt, ab) {
        const sysTerm = this.anbdt.boundsTerm;
        const w = new me_bw({
            x: sysTerm.x,
            y: sysTerm.y,
            width: sysTerm.width,
            height: sysTerm.height,
            acceptFirstMouse: true,
            webPreferences: {
                textAreasAreResizable: false,
            },
        });
        w.webContents.on('dom-ready', () => {
            w.on('move', () => {
                const a = w.getPosition();
                this.anbdt.setPosTerm(a[0], a[1]);
            });
            w.on('resize', () => {
                const a = w.getSize();
                this.anbdt.setSizeTerm(a[0], a[1]);
            });
        });
        w.webContents.on('did-finish-load', () => {
            if (this.win_term)
                this.win_term.close();
            this.win_term = w;
            this.addTerm('');
            w.setTitle('ターミナル：' + ab.fn + '【' + ab.title + '】');
            w.webContents.send('setTitle', ab.fn + '【' + ab.title + '】');
        });
        w.loadURL('file://' + AnbData_1.AnbData.path_app_nw + 'term.htm');
        w.on('close', () => { this.win_term = null; this.closeWin(); });
        this.addTerm("<span class='inf'>" + txt + " " + AnbData_1.AnbData.getDateStr()
            + " " + ab.fn + "【" + ab.title + "】</span>\n");
    }
    addTerm(txt) {
        if (this.win_term) {
            if (this.strBuf) {
                this.win_term.webContents.send('addTrace', this.strBuf);
                this.strBuf = '';
            }
            ;
            this.win_term.webContents.send('addTrace', txt);
        }
        else
            this.strBuf += txt + '<br/>';
    }
    doNativeProcessAnt(fn, arg) {
        if (m_fs.existsSync(AnbData_1.AnbData.path_app_str + 'nobld/term3d.json'))
            m_fs.unlink(AnbData_1.AnbData.path_app_str + 'nobld/term3d.json');
        this.closeWin();
        this.addTerm("<span class='inf'>[BEGIN] ant " + arg + "</span><br/>");
        const path_scr = AnbData_1.AnbData.path_app_str + 'app7/' +
            (AnbData_1.AnbData.is_mac
                ? 'anbooks.app/Contents/Resources/app/script/ant.sh'
                : 'resources/app/script/ant.bat');
        const a = [AnbData_1.AnbData.path_unpack + fn + '/build.xml'];
        if (arg)
            a.push(arg);
        if (AnbData_1.AnbData.is_mac) {
            a.unshift(path_scr);
            this.ls = m_spawn('sh', a);
        }
        else {
            a[0] = fn;
            this.ls = m_spawn(path_scr, a);
        }
        this.ls.stdout.on('data', data => {
            this.addTerm((data.toString() + '\n')
                .replace(/ /g, "&nbsp;")
                .replace(/\t/g, "&nbsp;&nbsp;&nbsp;")
                .replace(/([^\n]+):\n/g, "<span class='lbl'>$1:</span><br/>")
                .replace(/\n/g, '<br/>')
                .replace("BUILD&nbsp;SUCCESSFUL", "<span class='suc'>BUILD SUCCESSFUL</span>")
                .replace("BUILD&nbsp;FAILED", "<span class='err'>BUILD FAILED</span>")
                .replace(this.regUserName, "Users/[xxx]/"));
        });
        this.ls.stderr.on('data', data => {
            this.addTerm("<span class='err'>" + data + "</span><br/>");
        });
        this.ls.on('close', code => {
            this.addTerm("<span class='inf'>[END] " + code + "</span><br/>");
            this.ls = null;
        });
    }
    goNoBld(pb, is_detail) {
        const a = [
            AnbData_1.AnbData.path_unpack + pb.fn + '/config.anprj',
            is_detail ? 'start_detail' : 'start'
        ];
        if (AnbData_1.AnbData.is_mac) {
            this.ls = m_spawn('/Applications/ANBooks.app/Contents/MacOS/ANBooks', a);
        }
        else {
            a[0] = pb.fn;
            this.ls = m_spawn(AnbData_1.AnbData.path_app_str
                + 'app7/resources/app/script/ans.bat', a);
        }
    }
    onMake_app(id) {
        const pb = this.hBook[id];
        if (!pb.existsCfg) {
            AnbMain.notice('config.anprj がないので生成できません', 'error');
            return;
        }
        this.addLogHead("簡易アプリ生成", pb);
        this.addTerm("<span class='lbl'>- ez_app</span><br/>");
        m_fs.mkdirsSync(AnbData_1.AnbData.path_app_str + 'template/');
        const path_ezapp_zip = AnbData_1.AnbData.path_app_str + 'template/easy_app.zip';
        const fn_nwjs_zip = 'nwjs_' + (AnbData_1.AnbData.is_mac ? 'MAC' : 'WIN') + '.zip';
        const path_nwjs_zip = AnbData_1.AnbData.path_app_str + 'template/' + fn_nwjs_zip;
        const path_nm = AnbData_1.AnbData.path_unpack + pb.fn + '/';
        const path_wk_ezapp = path_nm + 'Work/easy_app/';
        m_fs.mkdirsSync(path_wk_ezapp);
        this.dlTmp(path_ezapp_zip, () => {
            this.addTerm("- 準備ez_app<br/>");
            m_fs.emptyDirSync(path_wk_ezapp);
            AnbMain.unZip(path_ezapp_zip, path_wk_ezapp, {
                'package.json': buf => String(buf)
                    .replace('test name', pb.fn)
                    .replace('詳細', pb.detail)
                    .replace('0.1', pb.version)
                    .replace('タイトル', pb.title)
                    .replace('width": 300', 'width": ' + pb.cfg.window.width)
                    .replace('height": 300', 'height": ' + pb.cfg.window.height),
                'index_ez.htm': buf => String(buf)
                    .replace('width="1024" height="768"', 'width="' + pb.cfg.window.width
                    + '" height="' + pb.cfg.window.height + '"'),
            }, () => { });
            this.addTerm("<span class='lbl'>- " + fn_nwjs_zip + "</span><br/>");
            m_fs.copy(path_nm + 'config.anprj', path_wk_ezapp + 'config.anprj');
            const sp = pb.cfg.search;
            for (let dir in sp) {
                const path_anc = path_nm + 'Work/before_anc/' + dir;
                m_fs.copySync((m_fs.existsSync(path_anc)
                    ? path_anc
                    : path_nm + dir), path_wk_ezapp + dir);
            }
            pb.mkp(path_nm);
            m_fs.copy(path_nm + 'path.txt', path_wk_ezapp + 'path.txt');
            this.dlTmp(path_nwjs_zip, () => {
                const path_scr = AnbData_1.AnbData.path_app_nw + 'template/script/mkEazyApp6.' + (AnbData_1.AnbData.is_mac ? 'sh' : 'bat');
                const a = [pb.fn];
                if (AnbData_1.AnbData.is_mac) {
                    a.unshift(path_scr);
                    this.ls = m_spawn('sh', a);
                }
                else {
                    this.ls = m_spawn(path_scr, a);
                }
                this.ls.stderr.on('data', dat => {
                    this.addTerm("<span class='err'>" + dat + "</span><br/>");
                });
                this.ls.on('close', code => {
                    this.addTerm("<span class='inf'>[END] " + code + "</span><br/>");
                    AnbMain.notice('簡易アプリを生成しました', 'success');
                    this.ls = null;
                });
                return true;
            });
            return false;
        });
    }
    dlTmp(fn_zip, finish, dl_url = null) {
        if (m_fs.existsSync(fn_zip)) {
            finish(fn_zip);
            return;
        }
        const path_tmp = AnbData_1.AnbData.path_app_str + 'template/';
        m_fs.mkdirsSync(path_tmp);
        let fn = m_path.basename(fn_zip);
        AnbMain.dlgDL(fn + ' ダウンロード中 0.00 %', () => {
            dlTmp_close();
            finish = null;
            m_fs.unlink(fn_zip);
            AnbMain.notice('ダウンロードをキャンセルしました', 'information');
        });
        if (!dl_url)
            dl_url = 'https://raw.githubusercontent.com/famibee/AIRNovel/master/ANBooks/template/' + fn;
        const ws = m_fs.createWriteStream(fn_zip);
        ws.on('open', () => {
            m_https.get(dl_url, (res) => {
                res.pipe(ws);
                let bytesTotal = 0, bytesLoaded = 0, cnt_dsp = 0;
                res.on('data', (d) => {
                    bytesLoaded += d.length;
                    if (++cnt_dsp % 300 > 0)
                        return;
                    AnbMain.dlgDL_setText(fn + ' ダウンロード中 ' + (bytesTotal == 0
                        ? (Math.floor(bytesLoaded / 1000) + 'KB')
                        : (Number((bytesLoaded / bytesTotal) * 100).toFixed(2)
                            + ' %')));
                });
            });
        })
            .on("close", () => {
            dlTmp_close();
            if (finish)
                finish(fn_zip);
        });
        function dlTmp_close() {
            ws.close();
            AnbMain.dlgDL_close();
        }
    }
}
AnbMain.guiWin = electron_1.remote.getCurrentWindow();
AnbMain.fnprj_iphone_zip = AnbData_1.AnbData.path_app_str + 'template/iPhone.zip';
AnbMain.fnprj_ipad_zip = AnbData_1.AnbData.path_app_str + 'template/iPad.zip';
AnbMain.fnprj_and_zip = AnbData_1.AnbData.path_app_str + 'template/Android.zip';
AnbMain.fnprj_plg_zip = AnbData_1.AnbData.path_app_str + 'template/Plugin.zip';
AnbMain.notyDlgDL = null;
exports.AnbMain = AnbMain;
//# sourceMappingURL=AnbMain.js.map